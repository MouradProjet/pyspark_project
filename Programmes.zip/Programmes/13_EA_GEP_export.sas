
/***************** AVANT CO ***********************/ 

	  %LET Arrete = 2026_06_Prov ; 
      %let Ouput=CR_Q226; 
	  %let month=06;
      %let day=26;
      %let yr=2026;
      %let hms = 000000 ; 
      %let dossier=202606;
      /*%let dossier=hors GEP;*/
      %let Q_N=Q22026;
      %let Q_N1=Q32026;
      
      
      
LIBNAME &Ouput. "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
LIBNAME EA "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";

%macro EXPORT_EXCEL(DATABASE=, DATATABLE=, SHEET=, );
PROC EXPORT  	
DATA = &DATATABLE.
OUTFILE=&DATABASE. 
DBMS=csv REPLACE;
SHEET = &SHEET. ;
run;
%MEND;

   /****************************************************************************/
						/** GEP CONCATENATION**/
   /****************************************************************************/

/*data ITALY_EA_UPF ;
set EA.ITALY11_EA_UPF 
    EA.ITALY12_EA_UPF
    EA.ITALY31_EA_UPF
    EA.ITALY32_EA_UPF 
    EA.ITALY41_EA_UPF 
    EA.ITALY42_EA_UPF 
    EA.ITALY51_EA_UPF 
    EA.ITALY52_EA_UPF
    EA.ITALY61_EA_UPF 
    EA.ITALY62_EA_UPF 
    EA.ITALY71_EA_UPF 
    EA.ITALY72_EA_UPF
    EA.ITALY81_EA_UPF 
    EA.ITALY82_EA_UPF 
    EA.ITALY91_EA_UPF
    EA.ITALY92_EA_UPF
    EA.ITALY101_EA_UPF
    EA.ITALY102_EA_UPF;
run;*/


%Macro GEP_AGR(pays=, CC=,);

%IF  &pays. = DENMARK OR &pays. = GERMANY OR &pays. = GREECE OR &pays. = IRELAND OR &pays. = ITALY OR &pays. = PORTUGAL OR &pays. = SPAIN OR &pays. = TURKEY OR &pays. = UK  OR &pays. = SWITZERLAND  
     
%then %do ;

/*DATA &pays._EA_UPF ;
set  EA.&pays._EA_UPF  ;
run;*/

DATA &pays._GEP_ALL ;
set  EA.&pays._EA_BLK_2 
     EA.&pays._EA_MF 
     EA.&pays._EA_UPF
     EA.&pays._EA_MRTRANS_2 ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA &pays._GEP_ALL ;
set &pays._GEP_ALL ;
*if payfreq in ("BLK","MRTRANS") and Qtr_Period="&Q_N." then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("&Q_N1.") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END; 


%if &pays. = NORWAY OR &pays. = POLAND OR &pays. =  SWEDEN  OR &pays. =  FINLAND  OR &pays. = COLOMBIA OR &pays. = AUSTRIA OR &pays. = MEXICO OR &pays. = BELGIUM %then %do;

/*DATA &pays._EA_UPF ;
set  EA.&pays._EA_UPF  ;
run;*/

DATA &pays._GEP_ALL ;
set  EA.&pays._EA_BLK_2 EA.&pays._EA_UPF EA.&pays._EA_MRTRANS_2 ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA &pays._GEP_ALL ;
set &pays._GEP_ALL ;
*if payfreq in ("BLK","MRTRANS") and Qtr_Period="&Q_N." then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("&Q_N1.") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%if &pays. = FRANCE  %then %do;

DATA &pays._GEP_ALL ;
set  EA.&pays._EA_BLK_2 EA.&pays._EA_MF EA.&pays._EA_MRTRANS_2 ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA &pays._GEP_ALL ;
set &pays._GEP_ALL ;
*if payfreq in ("BLK","MRTRANS") and Qtr_Period="&Q_N." then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("&Q_N1.") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%if &pays. = NETHERLANDS  %then %do;

DATA &pays._GEP_ALL ;
set EA.&pays._EA_UPF  EA.&pays._EA_MRTRANS_2 ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA &pays._GEP_ALL ;
set &pays._GEP_ALL ;
*if payfreq in ("BLK","MRTRANS") and Qtr_Period="&Q_N." then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("&Q_N1.") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%if &pays. = NORTHERNIRELAND  %then %do;

DATA &pays._GEP_ALL ;
set EA.&pays._EA_UPF  EA.&pays._EA_BLK_2 ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA &pays._GEP_ALL ;
set &pays._GEP_ALL ;
*if payfreq in ("BLK","MRTRANS") and Qtr_Period="&Q_N." then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("&Q_N1.") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&CC._gep_davc_&yr.&month.&day._&hms..csv";
%EXPORT_EXCEL(DATATABLE=&pays._GEP_ALL, DATABASE=&repexp.,SHEET="Feuil1");

/*
proc datasets lib=work memtype=DATA;   delete &pays._GEP_ALL;   run;  
*/
%MEND;  

%GEP_AGR(pays = AUSTRIA , cc = at) ;
%GEP_AGR(pays = BELGIUM , cc = be) ;
%GEP_AGR(pays = COLOMBIA , cc = co) ;
%GEP_AGR(pays = DENMARK , cc = dk) ;
%GEP_AGR(pays = FINLAND , cc = fi) ;
%GEP_AGR(pays = FRANCE , cc = fr) ;
%GEP_AGR(pays = GERMANY , cc = de) ;
%GEP_AGR(pays = GREECE , cc = gr) ;
%GEP_AGR(pays = IRELAND , cc = ie) ;
%GEP_AGR(pays = ITALY , cc = it) ;
%GEP_AGR(pays = MEXICO , cc = mx) ;
%GEP_AGR(pays = NETHERLANDS , cc = nl) ;
%GEP_AGR(pays = NORTHERNIRELAND , cc = ni) ;
%GEP_AGR(pays = NORWAY , cc = no) ;
%GEP_AGR(pays = POLAND , cc = pl) ;
%GEP_AGR(pays = PORTUGAL , cc = pt) ;
%GEP_AGR(pays = SPAIN , cc = es) ;
%GEP_AGR(pays = SWEDEN , cc = se) ;
%GEP_AGR(pays = SWITZERLAND , cc = ch) ;
%GEP_AGR(pays = TURKEY , cc = tr) ;
%GEP_AGR(pays = UK , cc = uk) ; 


    proc datasets lib = EA; validate; run;

     /****************************************************************************/
						/** claims reserves file **/
	/****************************************************************************/
		
%Macro SPLIT_CR(pays=,); 

data &pays._CLMHDR_ALL ;
set &Ouput..WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
where country="&pays.";
run;

data &pays._IBNR_ALL ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp not in ("ZZ1") ;
run;

data &pays._NCC_ALL ;
set &Ouput..WPS_DAAP_NCC_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp="ZZ1" ;
run;

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&pays._CLMHDR_ALL_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=&pays._CLMHDR_ALL, DATABASE=&repexp.,SHEET="Feuil1");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&pays._IBNR_ALL_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=&pays._IBNR_ALL, DATABASE=&repexp.,SHEET="Feuil1");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&pays._NCC_ALL_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=&pays._NCC_ALL, DATABASE=&repexp.,SHEET="Feuil1");

/*
proc datasets lib=work memtype=DATA;   delete &pays._CLMHDR_ALL;   run;  
proc datasets lib=work memtype=DATA;   delete &pays._IBNR_ALL;   run;  
proc datasets lib=work memtype=DATA;   delete &pays._NCC_ALL;   run; 
*/ 


%MEND;

%SPLIT_CR(pays=DE) ;
%SPLIT_CR(pays=DK) ;
%SPLIT_CR(pays=ES) ;
%SPLIT_CR(pays=IE) ;
%SPLIT_CR(pays=IT) ;
%SPLIT_CR(pays=FI) ;
%SPLIT_CR(pays=FR) ;
%SPLIT_CR(pays=GR) ;
%SPLIT_CR(pays=NL) ;
%SPLIT_CR(pays=NI) ;
%SPLIT_CR(pays=NO) ;
%SPLIT_CR(pays=PL) ;
%SPLIT_CR(pays=PT) ;
%SPLIT_CR(pays=SE) ;
%SPLIT_CR(pays=TR) ;
%SPLIT_CR(pays=UK) ;
%SPLIT_CR(pays=AT) ;
%SPLIT_CR(pays=BE) ;
%SPLIT_CR(pays=MX) ;


/*Colombie non filtr�*/
LIBNAME CR_Colo "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/Portfolio Monitoring CO/ON-SYSTEM/CASES RESERVES/Output";

/*%let pays=CO;*/

%Macro SPLIT_CR(pays=,); 
data &pays._CLMHDR_ALL ;
set CR_Colo.WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
where country="&pays.";
run;

data &pays._IBNR_ALL ;
set CR_Colo.WPS_DAAP_IBNR_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp not in ("ZZ1") ;
*y_char = compress(put(Entity_CD,21.0));
*drop Entity_CD; *rename y_char = Entity_CD;
run;

data &pays._NCC_ALL ;
set CR_Colo.WPS_DAAP_NCC_&yr.&month.&day.;
*y_char = compress(put(Entity_CD,21.0));
*drop Entity_CD; *rename y_char = Entity_CD;
where country="&pays." AND Rsrv_Grp="ZZ1" ;
run;

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&pays._CLMHDR_ALL_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=&pays._CLMHDR_ALL, DATABASE=&repexp.,SHEET="Feuil1");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&pays._IBNR_ALL_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=&pays._IBNR_ALL, DATABASE=&repexp.,SHEET="Feuil1");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./&pays._NCC_ALL_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=&pays._NCC_ALL, DATABASE=&repexp.,SHEET="Feuil1");

%MEND;

%SPLIT_CR(pays=CO) ;
/*********************/

data WPS_DAAP_CASE_RESERVES_&yr.&month.&day.;
set &Ouput..WPS_DAAP_CASE_RESERVES_&yr.&month.&day.;
where country ne "CO";
run;
data WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
set WPS_DAAP_CASE_RESERVES_&yr.&month.&day. CO_CLMHDR_ALL;
WHERE country  ne "CH" /*and country ne "CO"*/ ;
run;

data WPS_DAAP_IBNR_&yr.&month.&day.;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
where country ne "CO";
run;
data WPS_DAAP_IBNR_&yr.&month.&day. ;
set WPS_DAAP_IBNR_&yr.&month.&day. CO_IBNR_ALL;
WHERE country Not in ("CH"/*,"CO"*/) ;
run;

data WPS_DAAP_NCC_&yr.&month.&day. ;
set WPS_DAAP_IBNR_&yr.&month.&day. CO_NCC_ALL;
where country Not in ("CH"/*,"CO"*/) and  Rsrv_Grp="ZZ1" ;
run;

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./WPS_DAAP_CASE_RESERVES_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=WPS_DAAP_CASE_RESERVES_&yr.&month.&day., DATABASE=&repexp.,SHEET="Feuil1");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./WPS_DAAP_IBNR_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=WPS_DAAP_IBNR_&yr.&month.&day., DATABASE=&repexp.,SHEET="Feuil1");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier./WPS_DAAP_NCC_&yr.&month.&day..csv";
%EXPORT_EXCEL(DATATABLE=WPS_DAAP_NCC_&yr.&month.&day., DATABASE=&repexp.,SHEET="Feuil1");

  






     
