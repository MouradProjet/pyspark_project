%LET Arrete = 2026_09_Q4; 
               
      /** Libname **/
     
LIBNAME TIA4 "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; /*A changer */
           
%let cover_1= ('RU','RR','UL','UU') ;

/*%let cover_2= ('DJ','DM','DP','DK') ;*/

%let cover_9= ('DJ','DP') ;

/*%let cover_91= ('DJ') ;*/

/*%let cover_92= ('DP') ;*/

%let cover_10= ('DM','DK') ;

%let cover_3= ('DB','IR','IG','II','IJ','IM','IN','IO','IP','IS','IY','IZ','LA','LL','LR','ME','FR','PH','IK') ;
%let cover_4= ('DZ','RA','GP','IA','FA','IF') ;
%let cover_5= ('DY') ;
%let cover_6= ('DS') ;
%let cover_7= ('DI') ;
%let cover_8= ('DA') ;

%Macro SPLIT_IT(pays=,n=,COVER=,); 
data TIA4.&pays.&n._UPF ;
SET &pays._UPF ;
where COVER_CODE in &COVER. ;
run;
%MEND;


%SPLIT_IT(pays=ITALY,n=1,COVER=&cover_1.) ;
/*%SPLIT_IT(pays=ITALY,n=2,COVER=&cover_2.) ;*/
%SPLIT_IT(pays=ITALY,n=3,COVER=&cover_3.) ;
%SPLIT_IT(pays=ITALY,n=4,COVER=&cover_4.) ;
%SPLIT_IT(pays=ITALY,n=5,COVER=&cover_5.) ;
%SPLIT_IT(pays=ITALY,n=6,COVER=&cover_6.) ;
%SPLIT_IT(pays=ITALY,n=7,COVER=&cover_7.) ;
%SPLIT_IT(pays=ITALY,n=8,COVER=&cover_8.) ;

%SPLIT_IT(pays=ITALY,n=9,COVER=&cover_9.) ; /* 9,10 equivallent des du split 2*/
%SPLIT_IT(pays=ITALY,n=10,COVER=&cover_10.) ;


DATA TIA4.ITALY11_UPF TIA4.ITALY12_UPF ;
    SET TIA4.ITALY1_UPF;
    IF _N_ <= 2500000 THEN OUTPUT TIA4.ITALY11_UPF;
    ELSE OUTPUT TIA4.ITALY12_UPF;
RUN;

DATA TIA4.ITALY31_UPF TIA4.ITALY32_UPF ;
    SET TIA4.ITALY3_UPF;
    IF _N_ <= 2500000 THEN OUTPUT TIA4.ITALY31_UPF;
    ELSE OUTPUT TIA4.ITALY32_UPF;
RUN;

DATA TIA4.ITALY41_UPF TIA4.ITALY42_UPF ;
    SET TIA4.ITALY4_UPF;
    IF _N_ <= 2500000 THEN OUTPUT TIA4.ITALY41_UPF;
    ELSE OUTPUT TIA4.ITALY42_UPF;
RUN;

DATA TIA4.ITALY51_UPF TIA4.ITALY52_UPF ;
    SET TIA4.ITALY5_UPF;
    IF _N_ <= 2200000 THEN OUTPUT TIA4.ITALY51_UPF;
    ELSE OUTPUT TIA4.ITALY52_UPF;
RUN;

DATA TIA4.ITALY61_UPF TIA4.ITALY62_UPF ;
    SET TIA4.ITALY6_UPF;
    IF _N_ <= 2200000 THEN OUTPUT TIA4.ITALY61_UPF;
    ELSE OUTPUT TIA4.ITALY62_UPF;
RUN;

DATA TIA4.ITALY71_UPF TIA4.ITALY72_UPF ;
    SET TIA4.ITALY7_UPF;
    IF _N_ <= 1700000 THEN OUTPUT TIA4.ITALY71_UPF;
    ELSE OUTPUT TIA4.ITALY72_UPF;
RUN;

DATA TIA4.ITALY81_UPF TIA4.ITALY82_UPF ;
    SET TIA4.ITALY8_UPF;
    IF _N_ <= 2300000 THEN OUTPUT TIA4.ITALY81_UPF;
    ELSE OUTPUT TIA4.ITALY82_UPF;
RUN;

DATA TIA4.ITALY91_UPF TIA4.ITALY92_UPF ;
    SET TIA4.ITALY9_UPF;
    IF _N_ <= 2100000 THEN OUTPUT TIA4.ITALY91_UPF;
    ELSE OUTPUT TIA4.ITALY92_UPF;
RUN;

DATA TIA4.ITALY101_UPF TIA4.ITALY102_UPF ;
    SET TIA4.ITALY10_UPF;
    IF _N_ <= 1500000 THEN OUTPUT TIA4.ITALY101_UPF;
    ELSE OUTPUT TIA4.ITALY102_UPF;
RUN;



/* contr�les que j'ai toute les lignes */

proc sql; create table upf as select "IT" as pays,count(COUNTRY_CD) as count from italy_upf;     quit;

proc sql; create table upf11 as select "IT" as pays,count(COUNTRY_CD) as count11 from tia4.italy11_upf;     quit;
proc sql; create table upf31 as select "IT" as pays,count(COUNTRY_CD) as count31 from tia4.italy31_upf;     quit;
proc sql; create table upf41 as select "IT" as pays,count(COUNTRY_CD) as count41 from tia4.italy41_upf;     quit;
proc sql; create table upf51 as select "IT" as pays,count(COUNTRY_CD) as count51 from tia4.italy51_upf;     quit;
proc sql; create table upf61 as select "IT" as pays,count(COUNTRY_CD) as count61 from tia4.italy61_upf;     quit;
proc sql; create table upf71 as select "IT" as pays,count(COUNTRY_CD) as count71 from tia4.italy71_upf;     quit;
proc sql; create table upf81 as select "IT" as pays,count(COUNTRY_CD) as count81 from tia4.italy81_upf;     quit;
proc sql; create table upf91 as select "IT" as pays,count(COUNTRY_CD) as count91 from tia4.italy91_upf;     quit;
proc sql; create table upf101 as select "IT" as pays,count(COUNTRY_CD) as count101 from tia4.italy101_upf;     quit;
proc sql; create table upf12 as select "IT" as pays,count(COUNTRY_CD) as count12 from tia4.italy12_upf;     quit;
proc sql; create table upf32 as select "IT" as pays,count(COUNTRY_CD) as count32 from tia4.italy32_upf;     quit;
proc sql; create table upf42 as select "IT" as pays,count(COUNTRY_CD) as count42 from tia4.italy42_upf;     quit;
proc sql; create table upf52 as select "IT" as pays,count(COUNTRY_CD) as count52 from tia4.italy52_upf;     quit;
proc sql; create table upf62 as select "IT" as pays,count(COUNTRY_CD) as count62 from tia4.italy62_upf;     quit;
proc sql; create table upf72 as select "IT" as pays,count(COUNTRY_CD) as count72 from tia4.italy72_upf;     quit;
proc sql; create table upf82 as select "IT" as pays,count(COUNTRY_CD) as count82 from tia4.italy82_upf;     quit;
proc sql; create table upf92 as select "IT" as pays,count(COUNTRY_CD) as count92 from tia4.italy92_upf;     quit;
proc sql; create table upf102 as select "IT" as pays,count(COUNTRY_CD) as count102 from tia4.italy102_upf;     quit;


data upf_all_IT;
merge upf upf11 upf31 upf41 upf51 upf61 upf71 upf81 upf91 upf101 upf12 upf32 upf42 upf52 upf62 upf72 upf82 upf92 upf102 ; 
if count = count11+count31+count41+count51+count61+count71+count81+count91+count101+count12+count32+count42+count52+count62+count72+count82+count92+count102 then test="OK";
else test="KO";
run; 

proc sql;
    create table Italy_UPF_list as
    select distinct COVER_CODE
    from Italy_UPF
    order by COVER_CODE;
quit;

proc sql;
    create table Italy_UPF_list as
    select COVER_CODE,
           count(*) as NB_LIGNES
    from Italy_UPF
    group by COVER_CODE
    order by COVER_CODE;
quit;

proc sql;
    create table Italy_UPF_PH as
    select *
    from Italy_UPF
    where COVER_CODE = 'PH';
quit;

proc sql;
    create table Italy_UPF_IK as
    select *
    from Italy_UPF
    where COVER_CODE = 'IK';
quit;







