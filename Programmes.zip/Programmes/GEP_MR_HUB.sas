      %LET DT_CAL= "31dec2026"d; 
      %LET DT_Arrete_Reel = "28AUG2026"d ; 
      %LET Arrete = 2026_09_Q4; 
      %LET Cutoffdate= "28AUG2026"d;
      %LET N = 2026 ;
      %let LReseau =  ~/NAS/X; /* Mettre le serveur appropri�  entre -> ~/NAS/X  ou -> X:/Inventprev ** */
             
      /** Libname **/
     
      LIBNAME Out_GEP "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/DAAP" ;
      LIBNAME TIA3 "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 
      LIBNAME EA "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
   
   
%macro GEP_MR (country =) ;

Proc format;
Value exp 1,2,3 = "Q1"
                4,5,6 = "Q2"
                7,8,9 = "Q3"
                10,11,12 = "Q4";
Run;

data  &country._PE_RENEWABLE_input ;
set    TIA3.&country._MRTRANS/*_2*/ ;
run;

/*adding cancel date to every row of the policy number*/

data cncl_dt (keep=policy_number cancel_date);
set  &country._PE_RENEWABLE_input;
where cancel_date ne .;
run;

data cncl_dt ;
set  cncl_dt;
rename cancel_date=cancel_date2 ;
run;

proc sort data=cncl_dt nodupkey;
by policy_number;
run;

proc sort data=&country._PE_RENEWABLE_input;
by policy_number;
run;

data &country._PE_RENEWABLE_input ;
merge &country._PE_RENEWABLE_input  (in=a ) cncl_dt(in=b);
by policy_number;
if a;
run;


      data &country._PE_RENEWABLE 
    (keep=country POLICY_NUMBER cover start_date cover_start_date cover_end_date cancel_date GL_TYPE GL_TYPE_NO PRODUCT PRODUCT_VERSION payfreq
      premium COMMISSION premium_refund total_commission_clawback term scheme DATE_DEB_TRIM UEP_TRANS_DATE NBR_MS Exp_Mois NB_RT Cohort Rule /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER */) ;
      set &country._PE_RENEWABLE_input; /* Input table � changer */
      
      where start_date lt &Cutoffdate; /* on supprime toutes les polices qui commencent apr�s la data de calcul */ 
      
      /* On renomme des variables */
      
      if PER_TRANS_PREMIUM = . then premium = 0;else Premium = PER_TRANS_PREMIUM; 
      if PER_TRANS_TOTAL_COMMISSION = . then COMMISSION = 0;else COMMISSION = PER_TRANS_TOTAL_COMMISSION;
      if PER_TRANS_PREMIUM_REFUND = . then premium_refund= 0;else premium_refund = PER_TRANS_PREMIUM_REFUND;
      if PER_TRANS_TOT_COMM_CLAWBACK = . then total_commission_clawback = 0;else total_commission_clawback = PER_TRANS_TOT_COMM_CLAWBACK;
      rename cover_code = cover ;
      rename country_cd = country ; 
      
      FORMAT DATE_DEB_TRIM DATE9. ;
      FORMAT UEP_TRANS_DATE DATE9. ;
      length payfreq $10.;
      length LEGACY_SCHEME_CODE $20.;
      length LEGACY_AGREEMENT_NUMBER $50.;
      length LEGACY_RENEWAL_NUMBER $20.;
      
      /* D�finition de plusieurs variables */
      
      term=(year(cover_end_date)-year(cover_start_date))*12 + month(cover_end_date)- month(cover_start_date);
      
      if product_version = " " then 
      scheme = compress(trim(product)||'.'||(trim(Product_line_VERSION )) );
      else scheme = compress(trim(product)||'.'||(trim(Product_VERSION )) );

      DATE_DEB_TRIM =intnx( "QTR",(start_date),1) ;
      NBR_MS =intck( "month",(start_date),DATE_DEB_TRIM) ;
      UEP_TRANS_DATE = &Cutoffdate.;
      Exp_Mois = min(month(UEP_trans_date) - month((cover_start_date))+12*year(UEP_trans_date)-12*year((cover_start_date)),term,month((cancel_date)) - month((cover_start_date))+12*year((cancel_date))-12*year((cover_start_date)));
      NB_RT =intck( "month",(cover_start_date),(cancel_date)) ;
      Cohort =year(start_date) ;
      Rule = "r12";
      payfreq="MRTRANS" ;
      if term < 0 then delete ;
      if cover_start_date=cancel_date2 then delete ;
      LEGACY_SCHEME_CODE= "";
      LEGACY_AGREEMENT_NUMBER="" ;
      LEGACY_RENEWAL_NUMBER="" ;
      run ; 
       
      /* Traitement des cas o� le term = 1 */
      
      data &country._PE_RENEWABLE_0 ; 
      set &country._PE_RENEWABLE ; 
      where term=1 ;  
      if EXP_PERIOD > UEP_TRANS_DATE then delete ;
      
      FORMAT  EXP_PERIOD MONYY7.;
      days=day(cover_start_date)/30.4167 ;
      EXP_PERIOD =  intnx('month',(cover_start_date),0,'same');
      Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));
      
       if NB_RT >= 0 then GEP=0 ; 
       else GEP=(1-days)*PREMIUM;
      /*
      if NB_RT = 0 then GEP=Premium + Premium_refund ; 
      else GEP=(1-days)*PREMIUM; */
      if NB_RT > 0 then UEP_TBT=0 ;
      else UEP_TBT=Premium-GEP ;
      run;
      
data &country._PE_RENEWABLE_1 ; 
set &country._PE_RENEWABLE ; 
where term=1 ;
if EXP_PERIOD > UEP_TRANS_DATE then delete ;

FORMAT EXP_PERIOD MONYY7.;
days=day(cover_start_date)/30.4167 ;
EXP_PERIOD =  intnx('month',(cover_end_date),0,'same');
Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));

if NB_RT >= 0 then GEP=0 ;  else GEP=(days)*PREMIUM;

/*
if NB_RT=0 then GEP=0 ; else if NB_RT=1 then GEP=(days)*PREMIUM + premium_refund ; else
GEP=(days)*PREMIUM;
*/
if NB_RT > 0 then UEP_TBT=0 ;
else UEP_TBT=Premium-GEP ;

run;

/* Traitement des cas o� le term = 0 */

data &country._PE_RENEWABLE_5 ; 
set &country._PE_RENEWABLE ; 
where term=0 ;
FORMAT EXP_PERIOD MONYY7.;
EXP_PERIOD =  intnx('month',(cover_start_date),0,'same');
GEP=PREMIUM;
Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));
if EXP_PERIOD > UEP_TRANS_DATE then delete ;
if NB_RT > 0 then UEP_TBT=0 ;
else UEP_TBT=Premium-GEP ;
run;

/* Mere des cas o� le term = 1 et 0 */

data &country._PE_RENEWABLE_2 ; 
set &country._PE_RENEWABLE_0 &country._PE_RENEWABLE_1 &country._PE_RENEWABLE_5 ; 
NBR=(year(EXP_PERIOD)-year(start_date))*12 + month(EXP_PERIOD)- month(start_date)+1;
Quart_Dev = IFN(NBR_MS>NBR, 1, int((NBR - NBR_MS)/3 + 2));
drop days NBR_MS NBR  ;
run ; 

proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_1;
run;
proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_5;
run;
proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_0;
run;
proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_Input;
run;


/* Traitement des cas o� le term <> 1 */

data &country._PE_RENEWABLE_3 ; 
set &country._PE_RENEWABLE ; 
where (term <> 1 and term <>0) ; 
FORMAT  EXP_PERIOD MONYY7. ;
      Do TERM_IN_FORCE = 0 to (EXP_MOIS) ;  /* On change i par Term_in_force directement, on �vite le rename */
          /* calcul EXT_Period : inchang� */    
            EXP_PERIOD =  intnx('month',(cover_start_date),term_in_force,'same'); 
            /* Calcul de Quart_Dev en utilisant la fonction IFN() -> meme chose que fonction SI dans Excel */
            Quart_Dev = IFN(NBR_MS>TERM_IN_FORCE, 1, int((Term_In_Force - NBR_MS)/3 + 2));
            /* Calcul de QTR_Period en une ligne gr�ce au format */
           Qtr_Period = Cats(Put(month(Exp_Period),EXP.), year(Exp_Period));
      
            /* Calcul GEP */ 
       if TERM_IN_FORCE ne NB_RT then do ; 
       
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then GEP = ((1-(Term-0.5)/Term))*Premium ; 
                  else GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
           
         end ;
        else do ; 
        
            UEP_TBT = 0 ;
            /*GEP = 0 ; */
              GEP = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium + premium_refund ; 
        
         end; 
      
      output ;       
      end ;
      drop TERM_IN_FORCE NBR_MS ;
      run;

data &country._PE_RENEWABLE_4 ; 
set &country._PE_RENEWABLE_2 &country._PE_RENEWABLE_3 ; 
FORMAT  EXP_PERIOD_2 MONYY7. ;
EXP_PERIOD_2=mdy(month(EXP_PERIOD),1,year(EXP_PERIOD)) ; 
run ; 


proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_2;
run;

proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_3;
run;

proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE;
run;

proc sql ; 
create table Out_GEP.&country._MTRANS as 
select distinct
country,
cover,
GL_TYPE,
GL_TYPE_NO,
term,
scheme,
UEP_TRANS_DATE,
Cohort,
Rule,
EXP_PERIOD_2 as EXP_PERIOD,
Qtr_Period,
Quart_Dev,
sum(GEP) as GEP,
payfreq
/*LEGACY_SCHEME_CODE,
LEGACY_AGREEMENT_NUMBER,
LEGACY_RENEWAL_NUMBER*/
from &country._PE_RENEWABLE_4 
group by country,cover,GL_TYPE,GL_TYPE_NO,term,scheme,UEP_TRANS_DATE,Cohort,Rule,EXP_PERIOD_2,Qtr_Period,Quart_Dev,payfreq /*, LEGACY_SCHEME_CODE, LEGACY_AGREEMENT_NUMBER, LEGACY_RENEWAL_NUMBER*/ ; 
quit ; 



/* Input EA SIMON  */

data &country._EA_MRTRANS ;
set &country._PE_RENEWABLE_4 ;
retain country product Product_VERSION cover start_year GL_TYPE_NO UEP_TRANS_DATE cancelled  term  Qtr_Period  Quart_Dev GEP payfreq UEP_TBT /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER*/  ;
keep country product Product_VERSION cancelled cover GL_TYPE_NO term  Qtr_Period GEP Quart_Dev start_year UEP_TRANS_DATE payfreq UEP_TBT  /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER*/ ;
if NB_RT =. then cancelled=1 ;
else cancelled=0 ;
if product_version = " " then product_version=Product_line_VERSION ;
rename 
GL_TYPE_NO=entity
Product_VERSION=product_version 
UEP_TRANS_DATE=Date_Cal ;
start_year=year(start_date);
run ;


proc sql ; 
create table EA.&country._EA_MRTRANS as 
select distinct 
country,
product,
product_version,
cover,
start_year,
entity,
Date_Cal,
cancelled,
term,
Qtr_Period,
Quart_Dev,
sum(GEP) as GEP,
sum(UEP_TBT) as UEP,
payfreq
/*LEGACY_SCHEME_CODE,
LEGACY_AGREEMENT_NUMBER,
LEGACY_RENEWAL_NUMBER*/
from &country._EA_MRTRANS 
group by country,product,product_version,cover,start_year,entity,Date_Cal,cancelled,term,Qtr_Period,Quart_Dev,payfreq/*,LEGACY_SCHEME_CODE,LEGACY_AGREEMENT_NUMBER,LEGACY_RENEWAL_NUMBER*/ ; 
quit ; 


proc datasets lib=work memtype=DATA;
delete &country._PE_RENEWABLE_4;
run;

proc datasets lib=work memtype=DATA;
delete &country._EA_MRTRANS ;
run;

%mend ; 

%GEP_MR(country = ITALY) ;
%GEP_MR(country = AUSTRIA) ; 
%GEP_MR(country = BELGIUM) ;
%GEP_MR(country = COLOMBIA) ;    
%GEP_MR(country = UK) ;
%GEP_MR(country = GREECE) ;
%GEP_MR(country = IRELAND) ;

%GEP_MR(country = LUXEMBOURG) ;
%GEP_MR(country = MEXICO) ;
%GEP_MR(country = NETHERLANDS) ;
%GEP_MR(country = PERU) ;
%GEP_MR(country = SWITZERLAND) ;

%GEP_MR(country = TURKEY) ;
%GEP_MR(country = POLAND) ;
%GEP_MR(country = GERMANY) ;
%GEP_MR(country = NORWAY) ;
%GEP_MR(country = PORTUGAL) ; 
%GEP_MR(country = DENMARK) ;
%GEP_MR(country = SPAIN) ; 
%GEP_MR(country = FRANCE) ; 
%GEP_MR(country = FINLAND) ;

%GEP_MR(country = SWEDEN) ;