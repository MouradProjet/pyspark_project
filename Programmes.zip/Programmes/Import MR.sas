
/* t�l�chargement des tables dans la policy extract */ 
%LET Arrete = 2026_04_V2; 
%LET Cutoffdate= "27MAR2026:23:59:59"dt;
%LET fin_annee=2026-03-27;
      
*DATALAKE; 
%wps_mac_connexion_db(
    nom_libname = POLICY ,
    nom_db = WPS_SHINE_BLCL ,
    nom_schema = clp_wps ,
    nom_options = readbuff=10000 schema=global_policy_extracts
    );

LIBNAME POLICY odbcold  DSN=WPS_SHINE_BLCL  authdomain="DB_WPS_SHINE_BLCL"  schema=global_policy_extracts ;

LIBNAME Pol_ext "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 




/* #####################################################################################################*/
													/* MR */
/* #####################################################################################################*/

%macro mef (country = , pays = ) ;
 

data &country._MR; 
SET POLICY.&pays._pe_renewable_header_view ;
if policy_transaction_date gt &Cutoffdate. then delete;
run; 

DATA _null_; CALL symput("startdate",put(datetime(),datetime22.)); RUN;
PROC SQL;
CREATE TABLE Pol_ext.&country._MR as
SELECT COUNTRY_CD format=$2., POLICY_LINE_NO, PRODUCT format=$4. length=4, PRODUCT_VERSION format=$10., 
PRODUCT_LINE_VERSION, POLICY_NUMBER, COVER_CODE format=$5. length=5,
datepart(START_DATE) as start_date format=ddmmyy10., datepart(END_DATE) as end_date format=ddmmyy10., 
datepart(CANCEL_DATE) as cancel_date format=ddmmyy10., GL_TYPE format=$60., INSURANCE_TERM_MONTHS,
TAR, RENTAL, ADVANCE, OUTSTANDING_BALANCE, BALLOON, ADVISED_TOTAL_PREMIUM, ADVISED_GROSS_PREMIUM, 
ADVISED_TOTAL_REFUND, ADVISED_GROSS_REFUND, PREMIUM, NON_PREMIUM,
TOTAL_COMMISSION, PREMIUM_REFUND, NON_PREMIUM_REFUND, TOTAL_COMMISSION_CLAWBACK,
PRODUCT_LINE format=$2. length=2, CANCEL_CODE, 
datepart(LAST_REINSTATEMENT_DATE) as last_reinstatement_date format=ddmmyy10., 
LAST_TRANSACTION_TYPE  format=$10., OTHER, LAST_NON_ZERO_PREM,
GL_TYPE_NO, LEGACY_SCHEME_CODE format=$20. length=20, LEGACY_AGREEMENT_NUMBER format=$50. length=50, 
LEGACY_RENEWAL_NUMBER  format=$20. length=20 
FROM &country._MR ;
QUIT;
DATA _null_; CALL symput("enddate",put(datetime(),datetime22.)); RUN;

data Pol_ext.&country._MR;
set Pol_ext.&country._MR ;
y_char = GL_TYPE_NO*1;
drop GL_TYPE_NO; rename y_char = GL_TYPE_NO;
run; 


 
%mend ; 

%mef(country = AUSTRIA , pays = AT) ;
%mef(country = BELGIUM , pays = BE) ;
%mef(country = COLOMBIA , pays = CO) ;
%mef(country = DENMARK , pays = DK) ;
%mef(country = ESTONIA , pays = EE) ;
%mef(country = FINLAND , pays = FI) ;
%mef(country = FRANCE , pays = FR) ;
%mef(country = GERMANY , pays = DE) ;
%mef(country = GREECE , pays = GR) ;
%mef(country = IRELAND , pays = IE) ; 
%mef(country = ITALY , pays = IT) ;
%mef(country = LATVIA , pays = LV) ;
%mef(country = LITHUANIA , pays = LT) ;
%mef(country = LUXEMBOURG , pays = LU) ;
%mef(country = MEXICO , pays = MX) ;
%mef(country = NETHERLANDS , pays = NL) ;
%mef(country = NORTHERNIRELAND , pays = NI) ;
%mef(country = NORWAY , pays = NO) ;
%mef(country = PERU , pays = PE) ;
%mef(country = POLAND , pays = PL) ;
%mef(country = PORTUGAL , pays = PT) ;
%mef(country = SPAIN , pays = ES) ;
%mef(country = SWEDEN , pays = SE) ;
%mef(country = SWITZERLAND , pays = CH) ;
%mef(country = TURKEY , pays = TR) ;
%mef(country = UK , pays = UK) ; 
