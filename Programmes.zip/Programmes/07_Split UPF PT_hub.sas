 %LET Arrete = 2026_09_Q4;  
            
      /** Libname **/
     
      LIBNAME TIA4 "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 
           
%let cover_1= ('CF','CM','DB','DM','DY','DZ','FA','FR','GP','IA','IC','IE','IF','IG','II','IJ','IK','IM','IN','IO','IS','IY','IZ','LA','LR') ;
%let cover_2= ('DA') ;
%let cover_3= ('DI','DJ') ;
%let cover_4= ('DS') ;
%let cover_5= ('PE','RU','UL','UR','UU') ;




%Macro SPLIT (pays=,n=,COVER=,); 

data TIA4.&pays.&n._UPF ;
SET &pays._UPF ;
where COVER_CODE in &COVER. ;
run;


%MEND;

%SPLIT(pays=PORTUGAL,n=1,COVER=&cover_1.) ;
%SPLIT(pays=PORTUGAL,n=2,COVER=&cover_2.) ;
%SPLIT(pays=PORTUGAL,n=3,COVER=&cover_3.) ;
%SPLIT(pays=PORTUGAL,n=4,COVER=&cover_4.) ;
%SPLIT(pays=PORTUGAL,n=5,COVER=&cover_5.) ;


DATA TIA4.PORTUGAL31_UPF TIA4.PORTUGAL32_UPF ;
    SET TIA4.PORTUGAL3_UPF;
    IF _N_ <= 2150000 THEN OUTPUT TIA4.PORTUGAL31_UPF;
    ELSE OUTPUT TIA4.PORTUGAL32_UPF;
RUN;

DATA TIA4.PORTUGAL51_UPF TIA4.PORTUGAL52_UPF ;
    SET TIA4.PORTUGAL5_UPF;
    IF _N_ <= 1500000 THEN OUTPUT TIA4.PORTUGAL51_UPF;
    ELSE OUTPUT TIA4.PORTUGAL52_UPF;
RUN;



/* contr�les que j'ai toute les lignes */

proc sql; create table upf as select "PT" as pays,count(COUNTRY_CD) as count from portugal_upf;     quit;

proc sql; create table upf1 as select "PT" as pays,count(COUNTRY_CD) as count1 from tia4.portugal1_upf;     quit;
proc sql; create table upf2 as select "PT" as pays,count(COUNTRY_CD) as count2 from tia4.portugal2_upf;     quit;
proc sql; create table upf31 as select "PT" as pays,count(COUNTRY_CD) as count31 from tia4.portugal31_upf;     quit;
proc sql; create table upf32 as select "PT" as pays,count(COUNTRY_CD) as count32 from tia4.portugal32_upf;     quit;
proc sql; create table upf4 as select "PT" as pays,count(COUNTRY_CD) as count4 from tia4.portugal4_upf;     quit;
proc sql; create table upf51 as select "PT" as pays,count(COUNTRY_CD) as count51 from tia4.portugal51_upf;     quit;
proc sql; create table upf52 as select "PT" as pays,count(COUNTRY_CD) as count52 from tia4.portugal52_upf;     quit;

data upf_all_PT;
merge upf upf1 upf2 upf31 upf32 upf4 upf51 upf52; 
if count = count1+count2+count31+count32+count4+count51+count52 then test="OK";
run; 










