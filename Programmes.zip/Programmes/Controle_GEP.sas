%MACRO IMPORT_EXCEL(DATAFILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &DATAFILE.
OUT= &OUT. 
DBMS=csv REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;	  
	  	  
*mois_ann�e des fichier EA files � importer;
      %let ea_imp=Mar_24; 		  
     
*macro pour le trimestre actuel;
      %let Arrete1 = 2024_06_Prov ; 
      %let Qa=Q22024;
      %let month1=06;
      %let day1=28;
      %let yr1=2024;
      %let hms1 = 000000 ; 
      %let dossier1=202406 ;
      
*macro pour le trimestre pr�c�dent;
      %let Arrete2 = 2024_04_V2 ; 
      %let Qp=Q12024;
      %let month2=03;
      %let day2=29;
      %let yr2=2024;
      %let hms2 = 000000 ;
      %let dossier2=202403 ;
      
*libname;  
LIBNAME CHECK "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete1./02_Elements_techniques/TIA/Arrete reel/GEP/Controle/GEP DAAP vs PM/Output";
  

*Import des GEP par pays; 

%Macro GEP_AGR(pays=, CC=,);

%let rep=~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete1./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier1.;
%let nom=&CC._GEP_DAVC_&yr1.&month1.&day1._&hms1..csv; *Nom de la derni�re scheme database webxl;
%IMPORT_EXCEL(DATAFILE="&rep./&nom.",OUT=&pays._GEP_ALL1,ONGLET='Feuil1')

%let rep=~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete2./02_Elements_Techniques/TIA/Arrete reel/PM Export/&dossier2.;
%let nom=&CC._GEP_DAVC_&yr2.&month2.&day2._&hms2..csv; *Nom de la derni�re scheme database webxl;
%IMPORT_EXCEL(DATAFILE="&rep./&nom.",OUT=&pays._GEP_ALL2,ONGLET='Feuil1')

%MEND;  

%GEP_AGR(pays = SWITZERLAND , cc = CH) ;
%GEP_AGR(pays = GERMANY , cc = DE) ;
%GEP_AGR(pays = DENMARK , cc = DK) ;
%GEP_AGR(pays = SPAIN , cc = ES) ;
%GEP_AGR(pays = FINLAND , cc = FI) ;
%GEP_AGR(pays = FRANCE , cc = FR) ;
%GEP_AGR(pays = GREECE , cc = GR) ;
%GEP_AGR(pays = IRELAND , cc = IE) ; 
%GEP_AGR(pays = ITALY , cc = IT) ;
%GEP_AGR(pays = NETHERLANDS , cc = NL) ;
%GEP_AGR(pays = NORWAY , cc = NO) ;
%GEP_AGR(pays = POLAND , cc = PL) ;
%GEP_AGR(pays = PORTUGAL , cc = PT) ;
%GEP_AGR(pays = SWEDEN , cc = SE) ;
%GEP_AGR(pays = TURKEY , cc = TR) ;
%GEP_AGR(pays = UK , cc = UK) ; 


    /****************************************************************************/
						/** Check des GEP / GEP DAAP vs PM **/
	/****************************************************************************/
	
	%Macro CHECK_GEP_AMT(pays=,cc=,);
	
	/************************************************************/
	  /*  Import GEP PM - Mise en forme  */
	/************************************************************/
	
/*	%let pays=IRELAND ;*/
/*	%let cc=IE ;*/
	
	
		
%let Import_01="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete1./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/IBNR/Inputs/EA &Qa./&pays._Upf_MF_MRT_Blk_&ea_imp..xlsx" ; 	
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=GEP_PM_Input_&pays._1,ONGLET="FINAL_FILE");
	
data GEP_PM_Input_&pays._1;
set GEP_PM_Input_&pays._1;
if payfreq="Upf" then payfreq="UPF" ;
if payfreq="Blk" then payfreq="BLK" ;
run;
	
data GEP_PM_Input_&pays._2;
set GEP_PM_Input_&pays._1;
gross_earned_prem1 = input(gross_earned_prem,8.);
drop gross_earned_prem;
rename gross_earned_prem1 = gross_earned_prem;
RUN;
	
PROC SQL;
create table GEP_PM_&pays. as
SELECT DISTINCT Country_cd as country,
                COVER_CODE,
                scheme ,
                paccyear as paccyear,
                payfreq,
                sum(gross_earned_prem) as GEP_PM_&Qp.                                    
FROM GEP_PM_Input_&pays._2
group by Country, COVER_CODE,scheme,paccyear,payfreq; 
quit;
	
	
	
    /************************************************************/
	  /*   GEP DAAP - Mise en forme  */
	/************************************************************/
	
DATA GEP_DAAP_&pays._&Qa. ;
	length COVER_CODE $4.;
	keep country scheme COVER_CODE  paccyear GEP payfreq ;
	set &pays._GEP_ALL1 ;
	scheme = compress(trim(PRODUCT)||'.'||(trim(PRODUCT_VERSION)) );
	Exp_month=substr(Qtr_Period,2,1) ;
    Exp_yr=substr(Qtr_Period,3,4);
    if GEP=. then GEP=0 ;
    if Exp_yr < 2002 then delete ;
    if Exp_yr = 2002 and Exp_month < 12 then delete ;
	   
    if cover in ("DA", "DS") then COVER_CODE="DD";
    else if COVER in ("DY", "DZ") then COVER_CODE="DX";
    else if COVER in ("DI", "DJ") then COVER_CODE="DH";
    else if COVER in ("DF", "DG") then COVER_CODE="DFG";
    else if COVER in ("IA", "IS") then COVER_CODE="ID";
    else if COVER in ("II", "IJ") then COVER_CODE="IH";
    else if COVER in ("IY", "IZ") then COVER_CODE="IX";
    else if COVER in ("IG", "IF") then COVER_CODE="IFG";
    else if COVER in ("EL", "EW") then COVER_CODE="ELW";
    else COVER_CODE=COVER;
    
    if Exp_month="1"    THEN paccyear=cats(Exp_yr,"01","01");
    if Exp_month="2"    THEN paccyear=cats(Exp_yr,"04","01");
    if Exp_month="3"    THEN paccyear=cats(Exp_yr,"07","01");
    if Exp_month="4"    THEN paccyear=cats(Exp_yr,"10","01");
 	run;
	
	data GEP_DAAP_&pays._&Qa. ;
	set GEP_DAAP_&pays._&Qa. ;
	paccyear2=paccyear*1 ;
	run;
	
	
	DATA GEP_DAAP_&pays._&Qp. ;
	length COVER_CODE $4.;
	keep country scheme COVER_CODE  paccyear GEP payfreq;
	set &pays._GEP_ALL2 ;
	scheme = compress(trim(PRODUCT)||'.'||(trim(PRODUCT_VERSION)) );
	Exp_month=substr(Qtr_Period,2,1) ;
    Exp_yr=substr(Qtr_Period,3,4);
    if GEP=. then GEP=0 ;
    if Exp_yr < 2002 then delete ;
    if Exp_yr = 2002 and Exp_month < 12 then delete ;
   
    if cover in ("DA", "DS") then COVER_CODE="DD";
    else if COVER in ("DY", "DZ") then COVER_CODE="DX";
    else if COVER in ("DI", "DJ") then COVER_CODE="DH";
    else if COVER in ("DF", "DG") then COVER_CODE="DFG";
    else if COVER in ("IA", "IS") then COVER_CODE="ID";
    else if COVER in ("II", "IJ") then COVER_CODE="IH";
    else if COVER in ("IY", "IZ") then COVER_CODE="IX";
    else if COVER in ("IG", "IF") then COVER_CODE="IFG";
    else if COVER in ("EL", "EW") then COVER_CODE="ELW";
    else COVER_CODE=COVER;
    
    if Exp_month="1"    THEN paccyear=cats(Exp_yr,"01","01");
    if Exp_month="2"    THEN paccyear=cats(Exp_yr,"04","01");
    if Exp_month="3"    THEN paccyear=cats(Exp_yr,"07","01");
    if Exp_month="4"    THEN paccyear=cats(Exp_yr,"10","01");
 	run;
	
	data GEP_DAAP_&pays._&Qp. ;
	set GEP_DAAP_&pays._&Qp. ;
	paccyear2=paccyear*1 ;
	run;
	
	
	
	PROC SQL;
      create table GEP_DAAP_&pays._&Qp. as
             SELECT DISTINCT country,
                    COVER_CODE as COVER_CODE,
                    scheme ,
                    paccyear2 as paccyear,
                    payfreq,
                    sum(GEP) as GEP_DAAP_&Qp.                                                 
     FROM    GEP_DAAP_&pays._&Qp.
     group by Country, COVER_CODE,scheme,paccyear2
      ; 
     quit;
	
	PROC SQL;
      create table GEP_DAAP_&pays._&Qa. as
             SELECT DISTINCT country,
                    COVER_CODE as COVER_CODE,
                    scheme ,
                    paccyear2 as paccyear,
                    payfreq,
                    sum(GEP) as GEP_DAAP_&Qa.                                                 
     FROM    GEP_DAAP_&pays._&Qa.
     group by Country, COVER_CODE,scheme,paccyear2
      ; 
     quit;
	
    proc sort data=GEP_DAAP_&pays._&Qp.  ;  by      COVER_CODE scheme paccyear payfreq     ; run;
    proc sort data=GEP_DAAP_&pays._&Qa.  ;  by      COVER_CODE scheme paccyear payfreq    ; run;
    proc sort data=GEP_PM_&pays.         ;  by      COVER_CODE scheme paccyear payfreq   ; run;

    data CHECK_GEP_&pays._2;
    retain Country COVER_CODE scheme paccyear GEP_DAAP_&Qp.  GEP_PM_&Qp. GEP_DAAP_&Qa. payfreq    ;
    Keep   Country COVER_CODE scheme paccyear GEP_DAAP_&Qp.  GEP_PM_&Qp. GEP_DAAP_&Qa.  payfreq  ;
    merge GEP_DAAP_&pays._&Qp.  (in=a) GEP_PM_&pays.(in=b) GEP_DAAP_&pays._&Qa. (in=c);
    by  COVER_CODE scheme paccyear    ;
    if a or b or c ;
    if GEP_PM_&Qp.=.   then GEP_PM_&Qp.=0 ;
    if GEP_DAAP_&Qp.=. then GEP_DAAP_&Qp.=0 ;
    if GEP_DAAP_&Qa.=. then GEP_DAAP_&Qa.=0 ;
    run;
	
	
	PROC SQL;
      create table CHECK.CHECK_GEP_&pays. as
             SELECT DISTINCT country,
                    COVER_CODE as COVER_CODE,
                    scheme ,
                    payfreq,
                    paccyear as paccyear,
                    sum(GEP_DAAP_&Qa.) as  GEP_DAAP_&Qa.,
                    sum(GEP_DAAP_&Qp.) as  GEP_DAAP_&Qp.,
                    sum(GEP_PM_&Qp.) as    GEP_PM_&Qp.
                    
                                                                   
     FROM    CHECK_GEP_&pays._2 
     group by Country, COVER_CODE,scheme,paccyear,payfreq
      ; 
     quit;
 

 data CHECK.CHECK_GEP_&pays. ;
 set CHECK.CHECK_GEP_&pays.  ;
 where  paccyear not in (20240401,20240701,20241001) ; 
 LAG_PM_DAAP&Qa.= GEP_DAAP_&Qa. -GEP_PM_&Qp. ;
 LAG_DAAP_DAAP&Qa.= GEP_DAAP_&Qa.-GEP_DAAP_&Q1 ;
 LAG_PM_DAAP&Qp.= GEP_DAAP_&Qp.-GEP_PM_&Qp. ;
 run ;
 
 
 PROC SQL;
      create table CHECK_GEP_&pays. as
             SELECT DISTINCT country,
                    payfreq,
                    paccyear as paccyear,
                    sum(GEP_DAAP_&Qa.) as  GEP_DAAP_&Qa.,
                    sum(GEP_DAAP_&Qp.) as  GEP_DAAP_&Qp.,
                    sum(GEP_PM_&Qp.) as    GEP_PM_&Qp.,
                    sum(LAG_PM_DAAP&Qa.) as  LAG_PM_DAAP&Qa.,
                    sum(LAG_DAAP_DAAP&Qa.) as  LAG_DAAP_DAAP&Qa.,
                    sum(LAG_PM_DAAP&Qp.) as    LAG_PM_DAAP&Qp.
                                                                   
     FROM    CHECK.CHECK_GEP_&pays. 
     group by Country,payfreq,paccyear
      ; 
     quit;
     


PROC EXPORT DATA= CHECK_GEP_&pays.
            OUTFILE= "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete1./02_Elements_techniques/TIA/Arrete reel/GEP/Controle/GEP DAAP vs PM/Reporting/GEP Q1 2024 Movement  by country0.xlsx" 
            DBMS=xlsx REPLACE;
     SHEET="&cc.";
RUN; 

/*proc datasets lib=work memtype=DATA;   delete CHECK_GEP_&pays.;   run;
proc datasets lib=work memtype=DATA;   delete CHECK_GEP_&pays._2;   run;
proc datasets lib=work memtype=DATA;   delete GEP_PM_Input_&pays._1;   run;
proc datasets lib=work memtype=DATA;   delete GEP_PM_&pays.;   run;
proc datasets lib=work memtype=DATA;   delete GEP_DAAP_&pays._&Qp.;   run;
proc datasets lib=work memtype=DATA;   delete GEP_DAAP_&pays._&Qa.;   run;*/


%MEND; 

%CHECK_GEP_AMT(pays=SWITZERLAND,cc=CH) ;
%CHECK_GEP_AMT(pays=GERMANY,cc=DE) ;
%CHECK_GEP_AMT(pays=DENMARK,cc=DK) ;
%CHECK_GEP_AMT(pays=SPAIN,cc=ES) ;
%CHECK_GEP_AMT(pays=FRANCE,cc=FR) ;
%CHECK_GEP_AMT(pays=FINLAND,cc=FI) ;
%CHECK_GEP_AMT(pays=GREECE,cc=GR) ;
%CHECK_GEP_AMT(pays=IRELAND,cc=IE) ;
%CHECK_GEP_AMT(pays=ITALY,cc=IT) ;
%CHECK_GEP_AMT(pays=NETHERLANDS,cc=NL) ;
%CHECK_GEP_AMT(pays=NORWAY,cc=NO) ;
%CHECK_GEP_AMT(pays=POLAND,cc=PL) ;
%CHECK_GEP_AMT(pays=PORTUGAL,cc=PT) ;
%CHECK_GEP_AMT(pays=SWEDEN,cc=SE) ;
%CHECK_GEP_AMT(pays=TURKEY,cc=TR) ;
%CHECK_GEP_AMT(pays=UK,cc=UK) ;



   /*****************/
  /*LANCER JUSQUE L�/
 /*** MERCI ^!^ ***/    
/*****************/


LIBNAME EA "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
LIBNAME TIA1 "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete1./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 
LIBNAME TIA2 "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete2./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 



DATA BASE_Q422;
set TIA2.ITALY_BLK;
where PRODUCT IN ("X3J") and PRODUCT_VERSION in ("1") and COVER_CODE in ("LR");
rename start_date=start_date2 
       end_date=end_date2
       cancel_date=cancel_date2
;  
run ;

DATA BASE_Q322;
set TIA1.GERMANY_BLK;
where PRODUCT IN ("W3J") and PRODUCT_VERSION in ("1") and COVER_CODE in ("LR");

run ;

proc sort data = BASE_Q422 ; by POLICY_NUMBER ;run;
proc sort data = BASE_Q322; by POLICY_NUMBER ;run;

Data TEST;
merge  BASE_Q422(in=a) BASE_Q322(in=b);
if a ; by POLICY_NUMBER;
term=(year(start_date)-year(start_date2))*12 + month(start_date)- month(start_date2) ;
TRANS_YR=year(policy_transaction_date) ;
run;

DATA check3;
set TEST  ;
where flag ne "OLD" ;
RUN ;

PROC EXPORT DATA= BASE_Q321
            OUTFILE= "X:/Inventprev/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/GEP/Controle/GEP DAAP vs PM/Reporting" 
            DBMS=xlsx REPLACE;
     SHEET="Q3";
RUN; 



DATA check4;
set TEST  ;
where term <> 0 ;
RUN ;


DATA _GEP_ALL ;
set EA.GERMANY_EA_MRTRANS_2 ;
where PRODUCT IN ("3I") and PRODUCT_VERSION in ("4");
run ;

DATA _GEP_ALL2 ;
set GEP2.ITALY_GEP_ALL ;
where PRODUCT IN ("BN3") and cover in ("DS","DA");
run ;






PROC SQL;
	CREATE TABLE check  as 
	SELECT distinct
			h.*,
			s.start_date as start_date2,
			s.cover_start_date as cover_start_date2,
			s.cover_end_date as cover_end_date2,
			s.cancel_date as scancel_date2
		    FROM BASE_Q121 h
	left JOIN BASE_Q420 s ON (h.POLICY_NUMBER=s.POLICY_NUMBER)
	group h.POLICY_NUMBER
	;
QUIT;

PROC SQL;
	CREATE TABLE check2  as 
	SELECT distinct
			h.*
			
		    FROM check h
	
	group h.POLICY_NUMBER
	;
QUIT;

DATA check2;
set check ;
term=(year(start_date)-year(start_date2))*12 + month(start_date)- month(start_date2) ;
term2=(year(end_date)-year(end_date2))*12 + month(end_date)- month(end_date2) ;
term3=(year(cancel_date)-year(scancel_date2))*12 + month(cancel_date)- month(scancel_date2) ;
run ;

DATA check3;
set check2 ;
where term3 not in (.,0) ;
RUN ;



data IRELAND_Test;
set GEP2.IRELAND_GEP_ALL;
where PRODUCT = "7C" and product_version = "1" and cover in ("DA","DS");
run;

