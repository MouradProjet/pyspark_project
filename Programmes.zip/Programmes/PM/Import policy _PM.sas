
/* t�l�chargement des tables dans la policy extract */ 
%LET Arrete = 2025_09_Q4; 
%LET Cutoffdate= "26SEP2025:23:59:59"dt;
%LET fin_annee=2025-09-26;
      
*DATALAKE; 
%wps_mac_connexion_db(
    nom_libname = POLICY ,
    nom_db = WPS_SHINE_BLCL ,
    nom_schema = clp_wps ,
    nom_options = readbuff=10000 schema=global_policy_extracts
    );

LIBNAME Pol_ext "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 




/* #####################################################################################################*/
													/* BLK ET MF */
/* #####################################################################################################*/

%macro mef (country = , pays = ) ;
 
/* BLK */ 
data &country._BLK; 
SET POLICY.&pays._pe_bulk_header_view ;
if policy_transaction_date gt &Cutoffdate. then delete;
run; 

DATA _null_; CALL symput("startdate",put(datetime(),datetime22.)); RUN;
PROC SQL;
CREATE TABLE Pol_ext.&country._BLK_2 as
SELECT COUNTRY_CD format=$2., POLICY_LINE_NO, PRODUCT format=$4. length=4, PRODUCT_VERSION format=$10., 
PRODUCT_LINE_VERSION, POLICY_NUMBER, COVER_CODE format=$5. length=5,
datepart(START_DATE) as start_date format=ddmmyy10., datepart(END_DATE) as end_date format=ddmmyy10., 
datepart(CANCEL_DATE) as cancel_date format=ddmmyy10., GL_TYPE format=$60., INSURANCE_TERM_MONTHS,
TAR, RENTAL, ADVANCE, OUTSTANDING_BALANCE, BALLOON, ADVISED_TOTAL_PREMIUM, ADVISED_GROSS_PREMIUM, 
ADVISED_TOTAL_REFUND, ADVISED_GROSS_REFUND, PREMIUM, NON_PREMIUM,
TOTAL_COMMISSION, PREMIUM_REFUND, NON_PREMIUM_REFUND, TOTAL_COMMISSION_CLAWBACK,
PRODUCT_LINE format=$2. length=2, CANCEL_CODE, 
datepart(LAST_REINSTATEMENT_DATE) as last_reinstatement_date format=ddmmyy10., 
LAST_TRANSACTION_TYPE  format=$10., OTHER, LAST_NON_ZERO_PREM,
GL_TYPE_NO, LEGACY_SCHEME_CODE format=$20. length=20, LEGACY_AGREEMENT_NUMBER format=$50. length=50, 
LEGACY_RENEWAL_NUMBER  format=$20. length=20 
FROM &country._BLK ;
QUIT;
DATA _null_; CALL symput("enddate",put(datetime(),datetime22.)); RUN;

data Pol_ext.&country._BLK_2 ;
set Pol_ext.&country._BLK_2 ;
y_char = GL_TYPE_NO*1;
drop GL_TYPE_NO; rename y_char = GL_TYPE_NO;
run; 

/* MF */ 

/*DATA _null_; CALL symput("startdate",put(datetime(),datetime22.)); RUN;
PROC SQL;
CREATE TABLE Pol_ext.&country._MF  as
SELECT COUNTRY_CD format=$2., POLICY_LINE_NO, PRODUCT format=$4. length=4, PRODUCT_VERSION format=$10., 
PRODUCT_LINE_VERSION, POLICY_NUMBER, COVER_CODE format=$5. length=5,
datepart(START_DATE) as start_date format=ddmmyy10., datepart(END_DATE) as end_date format=ddmmyy10., 
datepart(CANCEL_DATE) as cancel_date format=ddmmyy10., GL_TYPE format=$60., INSURANCE_TERM_MONTHS,
TAR, RENTAL, ADVANCE, OUTSTANDING_BALANCE, BALLOON, ADVISED_TOTAL_PREMIUM, ADVISED_GROSS_PREMIUM, 
ADVISED_TOTAL_REFUND, ADVISED_GROSS_REFUND, PREMIUM, NON_PREMIUM,
TOTAL_COMMISSION, PREMIUM_REFUND, NON_PREMIUM_REFUND, TOTAL_COMMISSION_CLAWBACK,
PRODUCT_LINE format=$2. length=2, CANCEL_CODE, 
datepart(LAST_REINSTATEMENT_DATE) as last_reinstatement_date format=ddmmyy10., 
LAST_TRANSACTION_TYPE  format=$10., OTHER, LAST_NON_ZERO_PREM,
GL_TYPE_NO, LEGACY_SCHEME_CODE format=$20. length=20, LEGACY_AGREEMENT_NUMBER format=$50. length=50, 
LEGACY_RENEWAL_NUMBER  format=$20. length=20,
policy_transaction_date
FROM POLICY.&pays._pe_fixed_term_header_view;
QUIT;
DATA _null_; CALL symput("enddate",put(datetime(),datetime22.)); RUN;

data Pol_ext.&country._MF (drop= policy_transaction_date) ;
set Pol_ext.&country._MF;
if policy_transaction_date gt &Cutoffdate. then delete;
y_char = GL_TYPE_NO*1;
drop GL_TYPE_NO; rename y_char = GL_TYPE_NO;
run; */
 
%mend ; 

%mef(country = AUSTRIA , pays = AT) ;
%mef(country = BELGIUM , pays = BE) ;
%mef(country = COLOMBIA , pays = CO) ;
%mef(country = DENMARK , pays = DK) ;
%mef(country = ESTONIA , pays = EE) ;
%mef(country = FINLAND , pays = FI) ;
%mef(country = FRANCE , pays = FR) ;
%mef(country = GERMANY , pays = DE) ;
%mef(country = GREECE , pays = GR) ;
%mef(country = IRELAND , pays = IE) ; 
%mef(country = ITALY , pays = IT) ;
%mef(country = LATVIA , pays = LV) ;
%mef(country = LITHUANIA , pays = LT) ;
%mef(country = LUXEMBOURG , pays = LU) ;
%mef(country = MEXICO , pays = MX) ;
%mef(country = NETHERLANDS , pays = NL) ;
%mef(country = NORTHERNIRELAND , pays = NI) ;
%mef(country = NORWAY , pays = NO) ;
%mef(country = PERU , pays = PE) ;
%mef(country = POLAND , pays = PL) ;
%mef(country = PORTUGAL , pays = PT) ;
%mef(country = SPAIN , pays = ES) ;
%mef(country = SWEDEN , pays = SE) ;
%mef(country = SWITZERLAND , pays = CH) ;
%mef(country = TURKEY , pays = TR) ;
%mef(country = UK , pays = UK);  

/* #####################################################################################################*/





/* #####################################################################################################*/
													/* UPF */
/* #####################################################################################################*/

%macro mef (country = , pays = ) ;
proc sql;
    %wps_mac_connexion_db(
        nom_connexion = CNX ,
        nom_db = WPS_SHINE_BLCL ,
        nom_schema = clp_wps ,
        nom_options = readbuff=30000 schema=global_policy_extracts
        ); 
    select distinct  policy_transaction_date into : liste_annee separated by ' ' from  connection to cnx
    (
        SELECT year(policy_transaction_date) as  policy_transaction_date     
        FROM global_policy_extracts.&pays._pe_upfront_header_view
        where to_date(policy_transaction_date) < to_date("&fin_annee.")
        order by policy_transaction_date
    );
        disconnect from cnx;
quit;
 
%put >>> &liste_annee;
 
%for(annee, in=(&liste_annee.), do=%nrstr(
 
        proc sql;
        %wps_mac_connexion_db(
            nom_connexion = CNX ,
            nom_db = WPS_SHINE_BLCL ,
            nom_schema = clp_wps ,
            nom_options = readbuff=30000 schema=global_policy_extracts
        );
 
           create table policy_transaction_date_&annee. as  
           SELECT COUNTRY_CD format=$2., POLICY_LINE_NO, PRODUCT format=$4. length=4, PRODUCT_VERSION format=$10., 
            PRODUCT_LINE_VERSION, POLICY_NUMBER, COVER_CODE format=$5. length=5, CANCEL_CODE,
            datepart(START_DATE) as start_date format=ddmmyy10., datepart(END_DATE) as end_date format=ddmmyy10., 
            datepart(CANCEL_DATE) as cancel_date format=ddmmyy10.,  GL_TYPE format=$60., INSURANCE_TERM_MONTHS,
            TAR, RENTAL, ADVANCE, OUTSTANDING_BALANCE, BALLOON, ADVISED_TOTAL_PREMIUM, ADVISED_GROSS_PREMIUM, 
            ADVISED_TOTAL_REFUND, ADVISED_GROSS_REFUND, INSURED_GENDER format=$10., 
            datepart(INSURED_DOB) as insured_dob format=ddmmyy10., 
            datepart(POLICY_TRANSACTION_DATE) as policy_transaction_date format=ddmmyy10., 
            datepart(CANCEL_TRANSACTION_DATE) as cancel_transaction_date format=ddmmyy10.,
            PREMIUM, NON_PREMIUM,
            TOTAL_COMMISSION, PREMIUM_REFUND, NON_PREMIUM_REFUND, TOTAL_COMMISSION_CLAWBACK, 
            GL_TYPE_NO, NO_MONTHS_IN_FORCE, INSURED_CLASS format=$1.,
            LEGACY_SCHEME_CODE format=$20. length=20, LEGACY_AGREEMENT_NUMBER format=$50. length=50, 
            LEGACY_RENEWAL_NUMBER  format=$20. length=20,
            policy_transaction_date
            from  connection to cnx
            (
            SELECT COUNTRY_CD , POLICY_LINE_NO, PRODUCT , PRODUCT_VERSION , 
            PRODUCT_LINE_VERSION, POLICY_NUMBER, COVER_CODE , CANCEL_CODE,
            START_DATE, END_DATE , 
            CANCEL_DATE,  GL_TYPE , INSURANCE_TERM_MONTHS,
            TAR, RENTAL, ADVANCE, OUTSTANDING_BALANCE, BALLOON, ADVISED_TOTAL_PREMIUM, ADVISED_GROSS_PREMIUM, 
            ADVISED_TOTAL_REFUND, ADVISED_GROSS_REFUND, INSURED_GENDER , 
            INSURED_DOB , 
            POLICY_TRANSACTION_DATE, 
            CANCEL_TRANSACTION_DATE,
            PREMIUM, NON_PREMIUM,
            TOTAL_COMMISSION, PREMIUM_REFUND, NON_PREMIUM_REFUND, TOTAL_COMMISSION_CLAWBACK, 
            GL_TYPE_NO, NO_MONTHS_IN_FORCE, INSURED_CLASS ,
            LEGACY_SCHEME_CODE , LEGACY_AGREEMENT_NUMBER , 
            LEGACY_RENEWAL_NUMBER  
            FROM global_policy_extracts.&pays._pe_upfront_header_view
            where to_date(policy_transaction_date) < to_date("&fin_annee.") and year(to_date(policy_transaction_date)) = &annee.
         );
            disconnect from cnx;
        quit; 
));



/* Concat�nation des tables de la work */

data Pol_ext.&country._upf;
set policy_transaction_date_:;
run;

%for(annee, in=(&liste_annee.), do=%nrstr(
proc datasets lib=work memtype=DATA;   delete policy_transaction_date_&annee.;   run; 
));


%mend; 

%mef(country = AUSTRIA , pays = AT) ;
%mef(country = BELGIUM , pays = BE) ;
%mef(country = COLOMBIA , pays = CO) ;
%mef(country = DENMARK , pays = DK) ;
%mef(country = ESTONIA , pays = EE) ;
%mef(country = FINLAND , pays = FI) ;
%mef(country = FRANCE , pays = FR) ;
%mef(country = GERMANY , pays = DE) ;
%mef(country = GREECE , pays = GR) ;
%mef(country = IRELAND , pays = IE) ; 
%mef(country = ITALY , pays = IT) ;
%mef(country = LATVIA , pays = LV) ;
%mef(country = LITHUANIA , pays = LT) ;
%mef(country = LUXEMBOURG , pays = LU) ;
%mef(country = MEXICO , pays = MX) ;
%mef(country = NETHERLANDS , pays = NL) ; 
%mef(country = NORTHERNIRELAND , pays = NI) ;
%mef(country = NORWAY , pays = NO) ;
%mef(country = PERU , pays = PE) ;
%mef(country = POLAND , pays = PL) ;
%mef(country = PORTUGAL , pays = PT) ;
%mef(country = SPAIN , pays = ES) ;
%mef(country = SWEDEN , pays = SE) ;
%mef(country = SWITZERLAND , pays = CH) ;
%mef(country = TURKEY , pays = TR) ;
%mef(country = UK , pays = UK) ; 

/* #####################################################################################################*/




/* #####################################################################################################*/
													/* MR */
/* #####################################################################################################*/
%macro mef (country = , pays = ) ;

/*    %let country = ESTONIA ; %let pays = EE ;    */

proc sql;
    %wps_mac_connexion_db(
        nom_connexion = CNX ,
        nom_db = WPS_SHINE_BLCL ,
        nom_schema = clp_wps ,
        nom_options = readbuff=30000 schema=global_policy_extracts
        ); 
    select distinct TRANSACTION_DATE into : liste_annee separated by ' ' from  connection to cnx
    (
        SELECT year(TRANSACTION_DATE) as  TRANSACTION_DATE     
        FROM global_policy_extracts.&pays._pe_renewable_details_view
        where to_date(TRANSACTION_DATE) < to_date("&fin_annee.")
        order by TRANSACTION_DATE
    );
        disconnect from cnx;
quit;
 
%put >>> &liste_annee;
 
%for(annee, in=(&liste_annee.), do=%nrstr(
 
        proc sql;
        %wps_mac_connexion_db(
            nom_connexion = CNX ,
            nom_db = WPS_SHINE_BLCL ,
            nom_schema = clp_wps ,
            nom_options = readbuff=30000 schema=global_policy_extracts
        );
 
           create table policy_TRANSACTION_DATE_&annee. as  
           SELECT 
COUNTRY_CD,           
PRODUCT format=$4. length=4, 
PRODUCT_VERSION format=$10., 
PRODUCT_LINE format=$2. length=2,  
PRODUCT_LINE_VERSION, 
POLICY_NUMBER, 
COVER_CODE format=$5. length=5,
datepart(START_DATE) as start_date format=ddmmyy10., 
datepart(COVER_START_DATE) as cover_start_date format=ddmmyy10., 
datepart(cover_end_DATE) as cover_end_date format=ddmmyy10., 
datepart(EXPIRY_DATE) as expiry_date format=ddmmyy10., 
datepart(cancel_DATE) as cancel_date format=ddmmyy10., 
datepart(transaction_DATE) as transaction_date format=ddmmyy10., 
GL_TYPE format=$60., 
GL_TYPE_NO, 
PER_TRANS_PREMIUM, 
PER_TRANS_NON_PREMIUM,
PER_TRANS_TOTAL_COMMISSION, 
PER_TRANS_PREMIUM_REFUND, 
PER_TRANS_NON_PREMIUM_REFUND, 
PER_TRANS_TOT_COMM_CLAWBACK,
NO_INSUREDS_ON_COVER, TRANS_ID,
SC_CODE format=$6. length=6,
TRANSACTION_TYPE format=$2. length=2          
        
          
            from  connection to cnx
            (
            SELECT  
"&pays." as COUNTRY_CD,           
PRODUCT,
PRODUCT_VERSION, 
PRODUCT_LINE,  
PRODUCT_LINE_VERSION, 
POLICY_NUMBER, 
COVER_CODE,
start_date, 
cover_start_date, 
cover_end_date, 
expiry_date, 
cancel_date, 
transaction_date, 
GL_TYPE, 
GL_TYPE_NO, 
PER_TRANS_PREMIUM, 
PER_TRANS_NON_PREMIUM,
PER_TRANS_TOTAL_COMMISSION, 
PER_TRANS_PREMIUM_REFUND, 
PER_TRANS_NON_PREMIUM_REFUND, 
PER_TRANS_TOT_COMM_CLAWBACK,
NO_INSUREDS_ON_COVER, 
TRANS_ID,
SC_CODE,
TRANSACTION_TYPE          
           
                     
            FROM global_policy_extracts.&pays._pe_renewable_details_view
            where to_date(TRANSACTION_DATE) < to_date("&fin_annee.") and year(to_date(TRANSACTION_DATE)) = &annee.
         );
            disconnect from cnx;
        quit;
 
));


/* Concat�nation des tables de la work */
data Pol_ext.&country._mrtrans/*_2*/;
    set policy_transaction_date_:;
run;


%for(annee, in=(&liste_annee.), do=%nrstr(
proc datasets lib=work memtype=DATA;   delete policy_transaction_date_&annee.;   run; 
));


%mend; 

%mef(country = AUSTRIA , pays = AT) ;
%mef(country = BELGIUM , pays = BE) ;
%mef(country = COLOMBIA , pays = CO) ;
%mef(country = DENMARK , pays = DK) ;
%mef(country = FINLAND , pays = FI) ;
%mef(country = FRANCE , pays = FR) ;
%mef(country = GERMANY , pays = DE) ;
%mef(country = GREECE , pays = GR) ;
%mef(country = IRELAND , pays = IE) ; 
%mef(country = ITALY , pays = IT) ;
%mef(country = MEXICO , pays = MX) ;
%mef(country = NETHERLANDS , pays = NL) ;
%mef(country = NORWAY , pays = NO) ;
%mef(country = POLAND , pays = PL) ;
%mef(country = PORTUGAL , pays = PT) ;
%mef(country = SPAIN , pays = ES) ;
%mef(country = SWEDEN , pays = SE) ;
%mef(country = SWITZERLAND , pays = CH) ;
%mef(country = TURKEY , pays = TR) ;
%mef(country = UK , pays = UK) ; 

*%mef(country = ESTONIA , pays = EE) ; *la table est vide ok si ca fonctionne pas;
*%mef(country = PERU , pays = PE) ; *la table est vide ok si ca fonctionne pas;
*%mef(country = LATVIA , pays = LV) ; *la table est vide ok si ca fonctionne pas;
*%mef(country = LUXEMBOURG , pays = LU) ; *la table est vide ok si ca fonctionne pas;
*%mef(country = NORTHERNIRELAND , pays = NI) ; *la table est vide ok si ca fonctionne pas;
*%mef(country = LITHUANIA , pays = LT) ; *la table est vide ok si ca fonctionne pas;

/* #####################################################################################################*/
