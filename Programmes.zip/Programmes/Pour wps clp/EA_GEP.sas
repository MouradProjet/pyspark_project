
/***************** AVANT CO ***********************/ 

      %LET Arrete = 2025_04_V2 ; 
      %LET N = 2025 ;
      %let Ouput=CR_Q125; 
	  %let month=03;
      %let day=28;
      %let yr=2025;
      
LIBNAME &Ouput. "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
LIBNAME EA "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
LIBNAME GEP "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/All";

*LIBNAME GEP "F:/WPSDATA/Portfolio Monitoring/Experience Analysis/GEP Outputs/GEP DAAP/&Arrete2.";
*LIBNAME CR "F:/WPSDATA/Portfolio Monitoring/Experience Analysis/Claims Reserves Outputs/&Arrete2." ;

   /****************************************************************************/
						/** GEP CONCATENATION**/
	/****************************************************************************/
	

%Macro GEP_AGR(pays=, CC=,);

/* %let pays=AUSTRIA; %let CC =AT; */

%IF  &pays. = DENMARK OR &pays. = GERMANY OR &pays. = GREECE OR &pays. = IRELAND OR &pays. = ITALY OR &pays. = PORTUGAL OR &pays. = SPAIN OR &pays. = TURKEY OR &pays. = UK  OR &pays. = SWITZERLAND  
     
%then %do ;

DATA &pays._GEP_ALL ;
set  EA.&pays._EA_BLK/*_2*/ EA.&pays._EA_MF EA.&pays._EA_UPF EA.&pays._EA_MRTRANS/*_2*/ ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA GEP.&pays._GEP_ALL ;
set &pays._GEP_ALL ;
if payfreq in ("BLK","MRTRANS") and Qtr_Period="Q12025" then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("Q22025") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END; 


%if &pays. = NORWAY OR &pays. = POLAND OR &pays. =  SWEDEN  OR &pays. =  FINLAND  OR &pays. = COLOMBIA OR &pays. = AUSTRIA OR &pays. = MEXICO OR &pays. = BELGIUM %then %do;

DATA &pays._GEP_ALL ;
set  EA.&pays._EA_BLK/*_2*/ EA.&pays._EA_UPF EA.&pays._EA_MRTRANS/*_2*/ ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA GEP.&pays._GEP_ALL ;
set &pays._GEP_ALL ;
if payfreq in ("BLK","MRTRANS") and Qtr_Period="Q12025" then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("Q22025") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%if &pays. = FRANCE  %then %do;

DATA &pays._GEP_ALL ;
set  EA.&pays._EA_BLK/*_2*/ EA.&pays._EA_MF EA.&pays._EA_MRTRANS/*_2*/ ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA GEP.&pays._GEP_ALL ;
set &pays._GEP_ALL ;
if payfreq in ("BLK","MRTRANS") and Qtr_Period="Q12025" then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("Q22025") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%if &pays. = NETHERLANDS  %then %do;

DATA &pays._GEP_ALL ;
set EA.&pays._EA_UPF  EA.&pays._EA_MRTRANS/*_2*/ ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA GEP.&pays._GEP_ALL ;
set &pays._GEP_ALL ;
if payfreq in ("BLK","MRTRANS") and Qtr_Period="Q12025" then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("Q22025") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;

%if &pays. = NORTHERNIRELAND  %then %do;

DATA &pays._GEP_ALL ;
set EA.&pays._EA_UPF  EA.&pays._EA_BLK/*_2*/ ;
drop LEGACY_SCHEME_CODE  LEGACY_AGREEMENT_NUMBER   LEGACY_RENEWAL_NUMBER;
run;

DATA GEP.&pays._GEP_ALL ;
set &pays._GEP_ALL ;
if payfreq in ("BLK","MRTRANS") and Qtr_Period="Q12025" then GEP=1.5*GEP ; /*enl�ve quand je relance MR et BLK*/
IF Qtr_Period IN ("Q22025") then delete ; /*il faut enlev� le trimestre d'apr�s T+1*/
run;

%END;
%MEND;  

%GEP_AGR(pays = AUSTRIA , cc = AT) ;
%GEP_AGR(pays = BELGIUM , cc = BE) ;
%GEP_AGR(pays = COLOMBIA , cc = CO) ;
%GEP_AGR(pays = DENMARK , cc = DK) ;
%GEP_AGR(pays = FINLAND , cc = FI) ;
%GEP_AGR(pays = FRANCE , cc = FR) ;
%GEP_AGR(pays = GERMANY , cc = DE) ;
%GEP_AGR(pays = GREECE , cc = GR) ;
%GEP_AGR(pays = IRELAND , cc = IE) ; 
%GEP_AGR(pays = ITALY , cc = IT) ; *pas lanc�;
%GEP_AGR(pays = MEXICO , cc = MX) ;
%GEP_AGR(pays = NETHERLANDS , cc = NL) ;
%GEP_AGR(pays = NORTHERNIRELAND , cc = NI) ;
%GEP_AGR(pays = NORWAY , cc = NO) ;
%GEP_AGR(pays = POLAND , cc = PL) ;
%GEP_AGR(pays = PORTUGAL , cc = PT) ;
%GEP_AGR(pays = SPAIN , cc = ES) ;
%GEP_AGR(pays = SWEDEN , cc = SE) ;
%GEP_AGR(pays = SWITZERLAND , cc = CH) ;
%GEP_AGR(pays = TURKEY , cc = TR) ;
%GEP_AGR(pays = UK , cc = UK) ; 


data GEP.WPS_DAAP_GEP_&yr.&month.&day. ;
SET GEP.AUSTRIA_GEP_ALL GEP.BELGIUM_GEP_ALL GEP.COLOMBIA_GEP_ALL GEP.DENMARK_GEP_ALL GEP.FINLAND_GEP_ALL GEP.FRANCE_GEP_ALL GEP.GERMANY_GEP_ALL GEP.GREECE_GEP_ALL GEP.IRELAND_GEP_ALL GEP.ITALY_GEP_ALL GEP.NETHERLANDS_GEP_ALL GEP.NORTHERNIRELAND_GEP_ALL GEP.NORWAY_GEP_ALL GEP.POLAND_GEP_ALL GEP.PORTUGAL_GEP_ALL GEP.SPAIN_GEP_ALL GEP.SWEDEN_GEP_ALL  GEP.TURKEY_GEP_ALL GEP.UK_GEP_ALL;;
run;

    


     /****************************************************************************/
						/** claims reserves file **/
	/****************************************************************************/
		
%Macro SPLIT_CR(pays=,); 

data CR.&pays._CLMHDR_ALL ;
set &Ouput..WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
where country="&pays.";
run;

data CR.&pays._IBNR_ALL ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp not in ("ZZ1") ;
run;

data CR.&pays._NCC_ALL ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp="ZZ1" ;
run;

%MEND;

%SPLIT_CR(pays=DE) ;
%SPLIT_CR(pays=DK) ;
%SPLIT_CR(pays=ES) ;
%SPLIT_CR(pays=IE) ;
%SPLIT_CR(pays=IT) ;
%SPLIT_CR(pays=FI) ;
%SPLIT_CR(pays=FR) ;
%SPLIT_CR(pays=GR) ;
%SPLIT_CR(pays=NL) ;
%SPLIT_CR(pays=NI) ;
%SPLIT_CR(pays=NO) ;
%SPLIT_CR(pays=PL) ;
%SPLIT_CR(pays=PT) ;
%SPLIT_CR(pays=SE) ;
%SPLIT_CR(pays=TR) ;
%SPLIT_CR(pays=UK) ;
%SPLIT_CR(pays=AT) ;
%SPLIT_CR(pays=BE) ;
%SPLIT_CR(pays=MX) ;



/*Colombie non filtr�*/
LIBNAME CR_Colo "X:/Inventprev/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/Portfolio Monitoring CO/ON-SYSTEM/CASES RESERVES/Output";

%Macro SPLIT_CR(pays=,); 
data CR.&pays._CLMHDR_ALL ;
set CR_Colo.WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
where country="&pays.";
run;

data CR.&pays._IBNR_ALL ;
set CR_Colo.WPS_DAAP_IBNR_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp not in ("ZZ1") ;
run;

data CR.&pays._NCC_ALL ;
set CR_Colo.WPS_DAAP_NCC_&yr.&month.&day.;
where country="&pays." AND Rsrv_Grp="ZZ1" ;
run;
%MEND;

%SPLIT_CR(pays=CO) ;
/*********************/

data WPS_DAAP_CASE_RESERVES_&yr.&month.&day.;
set &Ouput..WPS_DAAP_CASE_RESERVES_&yr.&month.&day.;
where country ne "CO";
run;
data CR.WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
set WPS_DAAP_CASE_RESERVES_&yr.&month.&day. CR.CO_CLMHDR_ALL;
WHERE country  ne "CH" /*and country ne "CO"*/ ;
run;

data WPS_DAAP_IBNR_&yr.&month.&day.;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
where country ne "CO";
run;
data CR.WPS_DAAP_IBNR_&yr.&month.&day. ;
set WPS_DAAP_IBNR_&yr.&month.&day. CR.CO_IBNR_ALL;
WHERE country Not in ("CH"/*,"CO"*/) ;
run;
data CR.WPS_DAAP_NCC_&yr.&month.&day. ;
set WPS_DAAP_IBNR_&yr.&month.&day. CR.CO_NCC_ALL;
where country Not in ("CH"/*,"CO"*/) and  Rsrv_Grp="ZZ1" ;
run;
  






     
