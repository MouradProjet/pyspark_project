/*####################################################*/
/*################### INVENTAIRE TIA #################*/
/*####################################################*/
%macro EXPORT_EXCEL(DATABASE=, DATATABLE=, SHEET=, );PROC EXPORT DATA = &DATATABLE. OUTFILE=&DATABASE. DBMS=XLS REPLACE ;SHEET = &SHEET.;run;%MEND;
%macro EXPORT_EXCELX(DATABASE=, DATATABLE=, SHEET=, );PROC EXPORT DATA = &DATATABLE. OUTFILE=&DATABASE. DBMS=XLSX REPLACE ;SHEET = &SHEET. ;run;%MEND;

/****************************************************************************/
                                   /** Programmede calcul des GEP / UEP **/
                                   
/****************************************************************************/
      
      /********************************************/
                  /* A compl�ter par le user */
      /********************************************/  
      
      
      
      %let LReseau =  ~/NAS/X; /* Mettre le serveur appropri�  entre -> ~/NAS/X  ou -> X:/Inventprev ** */
      %LET DT_CAL= "31dec2026"d; 
      %LET DT_Arrete_Reel = "28AUG2026"d ; 
      %LET Arrete = 2026_09_Q4; 
      %LET Cutoffdate= "28AUG2026"d;
      %LET N = 2026 ;
       
      /** Libname **/
     
      LIBNAME Out_GEP "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/DAAP" ;
      LIBNAME TIA3 "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ;      
      LIBNAME EA "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
      LIBNAME TIA4 "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 
      libname Out_GEP2 "/mutu/FW/users/METIER/DTA/Reserve TIA";
             
      options mprint symbolgen mlogic sastrace=",,,sda";
      
      /************************************************************/
        /* Macro Import Table Datalake - Ruling */
      /************************************************************/

%let Import_01="&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Ruling/Ruling_Q32026.xlsx" ; 
      
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;


%IMPORT_EXCEL(FILE=&Import_01.,OUT=Ruling_F,ONGLET="Forecast");
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Ruling_P,ONGLET="PS");
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Ruling,ONGLET="Replacement");
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Max_term_FI,ONGLET="Max_term_FI");

%let Import_07="&LReseau./08.Progammes/Etablissements Financiers/PROJETS TRANSVERSAUX/Genworth/TOM Reserving/Table de reserving/Donnees/FY16/Data EXCEL/R/PROCESS RESERVING CLP/ON-SYSTEM/REPORTING/Stock Cloture Q418/FX.xlsx";
%IMPORT_EXCEL(FILE=&Import_07.,OUT=Currency_Mapping,ONGLET=Feuil1);

%let Import_02="&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Reassurance.xlsx";
%IMPORT_EXCEL(FILE=&Import_02.,OUT=Parametres_Reas,ONGLET=Parametres_Reas);

%let Import_05="&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Cartographie_Reassurance.xlsx";
%IMPORT_EXCEL(FILE=&Import_05.,OUT=Entity_Mappingsv2,ONGLET=Export_SAS);

data Currency_Mapping;set Currency_Mapping;rename Country=country;run;

data Parametres_Reas; set Parametres_Reas;gl_type_no = Original_underwritter *1; rename COUNTRY = country; run;
Data Entity_Mappingsv2 (keep = country SCHEME2 cover entity_cd entity GL_TYPE_NO);
set Entity_Mappingsv2;if DIM04 in ("101","121","181") then  entity="FICL";
else if DIM04 in ("102","122","182") then  entity="FACL"; 
else entity="N/A";
GL_TYPE_NO = entity_cd * 1;
rename SCHEME = SCHEME2;
run;  


      
      /************************************************************/
        /* Macro Import Table Datalake - Policy Extract Upfront */
      /************************************************************/

%macro Prepa_Table(country=) ; 
      /****************************************************************************************************************************************************************/
 
     %IF &country.=FINLAND %THEN %DO; 
     
      data TIA4.&country._UPF ;
      set TIA3.&country._UPF ;
      CLE = compress(product||cover_code) ;
      run;
      
      proc sql;
      create table WORK.POLICY_&country. as select DISTINCT
      a.*,
      b.Max_of_Term as Max_of_Term
      from TIA4.&country._UPF A left join MAX_TERM_FI B on a.CLE = b.Scheme ;                                    
      quit ;
      
      data POLICY_&country. ;
      set POLICY_&country. ;
      term=(year(end_date)-year(start_date))*12 + month(end_date)- month(start_date) ;
      if Max_of_Term=. then Max_of_Term=term ;
      IF term > Max_of_Term  and GL_TYPE="FICL" then term=Max_of_Term ;
      else term=term ;
      run;
      
      data TIA4.Policy_&country. ; 
      set POLICY_&country.; 
      rename cover_code = cover ;
      rename country_cd = country ; 
      FORMAT DATE_DEB_TRIM DATE9. ;
      FORMAT UEP_TRANS_DATE DATE9. ;
      FORMAT start_date2 DATE9. ;
      length payfreq $10.;
      DATE_DEB_TRIM =intnx( "QTR",(start_date),1) ;
      NBR_MS =intck( "month",(start_date),DATE_DEB_TRIM) ;
      UEP_TRANS_DATE = &DT_CAL.;
      NB_RT =intck( "month",(start_date),(cancel_date)) ;
      Cohort= year(start_date) ;
      CLE = compress(product||cover_code) ;  
      start_date2=(start_date) ; 
      scheme = compress(trim(PRODUCT)||'.'||(trim(product_version )) );
      payfreq="UPF" ;
      IF PREMIUM=. THEN PREMIUM=0;
      IF PREMIUM_REFUND=. THEN PREMIUM_REFUND=0;
      if term < 0 then delete ;
      Exp_Mois = min(month(UEP_trans_date) - month((start_date))+12*year(UEP_trans_date)-12*year((start_date)),term,month((cancel_date)) - month((start_date))+12*year((cancel_date))-12*year((start_date)));
      run ;
      
       data TIA4.Policy_&country. ; 
       set TIA4.Policy_&country. ; 
       gl_type_no2 = gl_type_no*1;
       drop gl_type_no;
       rename gl_type_no2=gl_type_no;
       run;
      
      %END;
      
      %ELSE %DO;
     
/*%LET country = PORTUGAL1 ;*/

      
      data TIA4.Policy_&country. ; 
      set TIA3.&country._UPF; 
      rename cover_code = cover ;
      rename country_cd = country ;  
      FORMAT DATE_DEB_TRIM DATE9. ;
      FORMAT UEP_TRANS_DATE DATE9. ;
      FORMAT start_date2 DATE9. ;
      length payfreq $10.;
      DATE_DEB_TRIM =intnx( "QTR",(start_date),1) ;
      NBR_MS =intck( "month",(start_date),DATE_DEB_TRIM) ;
      UEP_TRANS_DATE = &DT_CAL.;
      NB_RT =intck( "month",(start_date),(cancel_date)) ;
      Cohort= year(start_date) ;
      CLE = compress(product||cover_code) ; 
      start_date2=(start_date) ; 
      scheme = compress(trim(PRODUCT)||'.'||(trim(product_version )) );
      payfreq="UPF" ;
      IF PREMIUM=. THEN PREMIUM=0;
      IF PREMIUM_REFUND=. THEN PREMIUM_REFUND=0;
      term=(year(end_date)-year(start_date))*12 + month(end_date)- month(start_date); 
      if term < 0 then delete ;
      Exp_Mois = min(month(UEP_trans_date) - month((start_date))+12*year(UEP_trans_date)-12*year((start_date)),term,month((cancel_date)) - month((start_date))+12*year((cancel_date))-12*year((start_date)));
      run ;
      
       data TIA4.Policy_&country. ; 
       set TIA4.Policy_&country. ; 
       gl_type_no2 = gl_type_no*1;
       drop gl_type_no;
       rename gl_type_no2=gl_type_no;
       run;
      
      %END;
      
      /* ETAPE 1 : On s�lectionne la r�gle que l'on veut pour chaque police */ 
     
      proc sql;
      create table Policy_Rule_&country. as select DISTINCT
      a.*,
      b.DIM08 as Rule,
      b.DIM07 as V ,
      c.Rule as Rule_Default,
      C.V as V_default,
      d.DIM08 as Rule_P,
      d.DIM07 as V_P
      from TIA4.Policy_&country. A
      left join Ruling_F B on a.CLE = b.DIM01 and a.country=b.country and a.gl_type_no=b.DIM11 and a.product_version=b.DIM02 and a.start_date2 between b.DIM19 and b.DIM20 
      left join Ruling C on a.country=c.country and a.cover=c.cover and a.start_date2 between c.start_date and c.end_date 
      left join Ruling_P D on a.CLE = d.DIM01 and a.country=d.country and a.gl_type_no=d.DIM11 and a.product_version=d.DIM02 and a.start_date2 between d.DIM19 and d.DIM20     ;
      quit ;
      
      data Policy_Rule_&country. ; 
      set Policy_Rule_&country. ;  
            if Rule in ('factor', "" ,'r_model_uep' ,'r_uep_gaap' ,'r_rep_gaap') then do ; 
            Rule=Rule_Default ;
            V=V_default ;
            end ; 

            if Rule_P in ("") then do ; 
                        Rule_P=Rule ;
                        V_P=V ;
                        end ; 
                        else if Rule_P in ('factor', 'r_model_uep' ,'r_uep_gaap' ,'R_PPM', 'r_rep_gaap',"") then do ; 
                              Rule_P = Rule_Default ; 
                              V_P = V_default ; 
                              end ;  
      
      run ; 
      

      %mend ; 
      
      /****************************************************************************************************************************************************************/
      
      /*           ETAPE 2 : Calcul des GEPs/UEPs. Nous appliquerons une m�thode de dupplication des lignes, et construite
          un compteur = term_in_force */
       /*%LET country= POLAND; */     
      
      %macro GEP_Calc (country =,country_code=,) ;
      
      /* Dupliquer les lignes au moyen de la variable EXP_MOIS et Cr�ation d'un compteur
      Cette m�thode de duplication cr�e automatiquement un compteur i*/
      
      
/* %LET country= PORTUGAL1; */
/* %LET country_code = PT; */
       
      Proc format;
      Value exp 1,2,3 = "Q1"
                4,5,6 = "Q2"
                7,8,9 = "Q3"
                10,11,12 ="Q4";
      Run;
      
      Data Out_GEP2.Policy_Rule_&country._2 (compress = no /*drop=F_Exp_Period*/);
      set  Policy_Rule_&country. ;
      Length QTR_Period $6.;
      FORMAT  EXP_PERIOD MONYY7. ;

      Do TERM_IN_FORCE = 0 to (EXP_MOIS) ;  /* On change i par Term_in_force directement, on �vite le rename */
          /* calcul EXT_Period : inchang� */    
            EXP_PERIOD =  intnx('month',(start_date),term_in_force,'same'); 
            /* Calcul de Quart_Dev en utilisant la fonction IFN() -> meme chose que fonction SI dans Excel */
            Quart_Dev = IFN(NBR_MS>TERM_IN_FORCE, 1, int((Term_In_Force - NBR_MS)/3 + 2));
            /* Calcul de QTR_Period en une ligne gr�ce au format */
           Qtr_Period = Cats(Put(month(Exp_Period),EXP.), year(Exp_Period));
      
            /* Calcul GEP */ 
       if TERM_IN_FORCE ne NB_RT then do ; 
       
           If (Rule = 'r12' and Rule_P='r12') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ; 
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ; 
            end ; 

           If (Rule = 'r12' and Rule_P='r78') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 

           If (Rule = 'r12' and Rule_P='V') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ;
	                  GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 
            
            If (Rule = 'r12' and Rule_P='r78m') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 
             
            If (Rule = 'r12' and Rule_P='r45m') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 
                     
           If (Rule = 'r78' and Rule_P='r12') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ;
	                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                      GEP_P = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 

           If (Rule = 'r78' and Rule_P='r78') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
		              GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                      GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 

           If (Rule = 'r78' and Rule_P='V') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ; 
	                  GEP_P = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                      GEP_P = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 

           If (Rule = 'r78' and Rule_P='r78m') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ; 
	                  GEP_P = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
           end ;
           
           If (Rule = 'r78' and Rule_P='r45m') then do ; 
                  UEP_TBT = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ; 
	                  GEP_P = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
           end ;  
       
           If (Rule = 'V' and Rule_P='r12') then do ; 
                  UEP_TBT = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
	                  GEP_P = ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                      GEP_P = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 

           If (Rule = 'V' and Rule_P='r78') then do ; 
                  UEP_TBT = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
	                  GEP_P = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                      GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 

           If (Rule = 'V' and Rule_P='V') then do ; 
                  UEP_TBT = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                      GEP_P = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 
            
           If (Rule = 'V' and Rule_P='r78m') then do ; 
                  UEP_TBT = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
           end ;
           
           If (Rule = 'V' and Rule_P='r45m') then do ; 
                  UEP_TBT = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  UEP_TBT_P = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ; 
	                  GEP_P = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
	                  GEP_P = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
           end ;         
          
          
           If (Rule = 'r78m' and Rule_P='r12') then do ; 
                  UEP_TBT = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ; 
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ; 
            end ; 

           If (Rule = 'r78m' and Rule_P='r78') then do ; 
                  UEP_TBT = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 

           If (Rule = 'r78m' and Rule_P='V') then do ; 
                  UEP_TBT = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 
            
            If (Rule = 'r78m' and Rule_P='r78m') then do ; 
                  UEP_TBT = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ;   
            
            If (Rule = 'r78m' and Rule_P='r45m') then do ; 
                  UEP_TBT = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
             end ;   
 
           If (Rule = 'r45m' and Rule_P='r12') then do ; 
                  UEP_TBT = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ; 
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ; 
            end ; 

           If (Rule = 'r45m' and Rule_P='r78') then do ; 
                  UEP_TBT = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ; 

           If (Rule = 'r45m' and Rule_P='V') then do ; 
                  UEP_TBT = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = V*(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)*Premium + (1-V)*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = V*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium + (1-V)* ((1-(Term-0.5)/Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = V*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium+(1-V)*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
                  end ;
            end ; 
            
            If (Rule = 'r45m' and Rule_P='r78m') then do ; 
                  UEP_TBT = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = 2*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = 2*((1-(Term-0.5)/Term))*Premium - (1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = 2*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
            end ;   
            
            If (Rule = 'r45m' and Rule_P='r45m') then do ; 
                  UEP_TBT = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  UEP_TBT_P = 1.5*max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium - 0.5*max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0)*Premium ;
                  
                  if TERM_IN_FORCE=0 then do ; 
	                  GEP = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
	                  GEP_P = 1.5*((1-(Term-0.5)/Term))*Premium - 0.5*(1-(Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term))*Premium ;
                  end ; 
                  else do ; 
	                  GEP = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
	                  GEP_P = 1.5*(((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium -0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)-max(((Term-TERM_IN_FORCE)*(Term-TERM_IN_FORCE)/((Term+1)*Term)),0))*Premium ;
                  end ;
             end ;                       

            end ; 

        else do ; 
        
         If (Rule = 'r12' and Rule_P='r12') then do ; 
            UEP_TBT = 0 ;
            GEP = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
            UEP_TBT_P = 0 ;
            GEP_P = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end; 
          
         Else if (Rule = 'r78' and Rule_P='r12') then do ; 
                  UEP_TBT = 0;
                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
                  UEP_TBT_P = 0 ;
                      GEP_P = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;
         
         Else if (Rule = 'V' and Rule_P='r12') then do ;
               UEP_TBT = 0 ;
               GEP = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
               UEP_TBT_P = 0 ;
                  GEP_P = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;
         
         
          Else if (Rule = 'r78m' and Rule_P='r12') then do ;
               UEP_TBT = 0 ;
               GEP = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
               UEP_TBT_P = 0 ;
               GEP_P = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;
         
         Else if (Rule = 'r45m' and Rule_P='r12') then do ;
               UEP_TBT = 0 ;
               GEP = 1.5*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
               UEP_TBT_P = 0 ;
               GEP_P = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;


         Else If (Rule = 'r12' and Rule_P='r78') then do ; 
            UEP_TBT = 0 ;
            GEP = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
            UEP_TBT_P = 0 ;
            GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
         end; 
          
         Else if (Rule = 'r78' and Rule_P='r78') then do ; 
                  UEP_TBT = 0;
                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
                  UEP_TBT_P = 0 ;
                  GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
         end;
         
         Else if (Rule = 'V' and Rule_P='r78') then do ;
               UEP_TBT = 0 ;
               GEP = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
               UEP_TBT_P = 0 ;
               GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
         end;
        
         Else if (Rule = 'r78m' and Rule_P='r78') then do ;
               UEP_TBT = 0 ;
               GEP = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
               UEP_TBT_P = 0 ;
               GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
         end;
         
         Else if (Rule = 'r45m' and Rule_P='r78') then do ;
               UEP_TBT = 0 ;
               GEP = 1.5*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
               UEP_TBT_P = 0 ;
               GEP_P = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
         end;
                 
         Else If (Rule = 'r12' and Rule_P='V') then do ; 
            UEP_TBT = 0 ;
            GEP = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
            UEP_TBT_P = 0 ;
            GEP_P = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end; 
          
         Else if (Rule = 'r78' and Rule_P='V') then do ; 
                  UEP_TBT = 0;
                  GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
                  UEP_TBT_P = 0 ;
                  GEP_P = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;
         
         Else if (Rule = 'V' and Rule_P='V') then do ;
               UEP_TBT = 0 ;
               GEP = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
               UEP_TBT_P = 0 ;
               GEP_P = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;
         
          Else if (Rule = 'r78m' and Rule_P='V') then do ;
               UEP_TBT = 0 ;
               GEP = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
               UEP_TBT_P = 0 ;
               GEP_P = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;
         
         Else if (Rule = 'r45m' and Rule_P='V') then do ;
               UEP_TBT = 0 ;
               GEP = 1.5*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
               UEP_TBT_P = 0 ;
               GEP_P = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
         end;        
                  
         If (Rule = 'r12' and Rule_P='r78m') then do ; 
            UEP_TBT = 0 ;
            GEP = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
            UEP_TBT_P = 0 ;
            GEP_P = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
         end; 
         
         If (Rule = 'r78' and Rule_P='r78m') then do ; 
            UEP_TBT = 0 ;
            GEP = ((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;
            UEP_TBT_P = 0 ;
            GEP_P = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;       
         end; 
         
         If (Rule = 'V' and Rule_P='r78m') then do ; 
            UEP_TBT = 0 ;
            GEP = V*(Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term)*Premium + (1-V)*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+premium_refund ;
            UEP_TBT_P = 0 ;
            GEP_P = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;       
         end; 
         
         If (Rule = 'r78m' and Rule_P='r78m') then do ; 
            UEP_TBT = 0 ;
            GEP = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
            UEP_TBT_P = 0 ;
            GEP_P = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
         end;
          
         If (Rule = 'r45m' and Rule_P='r78m') then do ; 
            UEP_TBT = 0 ;
            GEP = 1.5*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+0.5*((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
            UEP_TBT_P = 0 ;
            GEP_P = 2*((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium+((Term-(TERM_IN_FORCE-1))*(Term-(TERM_IN_FORCE-1))/((Term+1)*Term))*Premium +premium_refund ;         
         end;          
      end; 
      
      output ;       
      end ;
      run;
      
        
        
      
    proc sort data= Out_GEP2.Policy_Rule_&country._2 nodupkey out=Out_GEP2.Policy_Rule_&country._2; 
    by country POLICY_LINE_NO PRODUCT PRODUCT_VERSION PRODUCT_LINE_VERSION POLICY_NUMBER cover CANCEL_CODE start_date 
    end_date cancel_date GL_TYPE term TAR RENTAL ADVANCE OUTSTANDING_BALANCE BALLOON 
    ADVISED_TOTAL_PREMIUM  ADVISED_TOTAL_REFUND ADVISED_GROSS_REFUND INSURED_GENDER insured_dob policy_transaction_date cancel_transaction_date PREMIUM NON_PREMIUM TOTAL_COMMISSION PREMIUM_REFUND
    NON_PREMIUM_REFUND TOTAL_COMMISSION_CLAWBACK GL_TYPE_NO NO_MONTHS_IN_FORCE INSURED_CLASS DATE_DEB_TRIM UEP_TRANS_DATE start_date2
    payfreq NBR_MS Exp_Mois NB_RT Cohort CLE scheme Rule V Rule_Default V_default Rule_P V_P QTR_Period EXP_PERIOD TERM_IN_FORCE Quart_Dev LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER 
     ; 
    run;
      
     /* data Out_GEP2.Policy_Rule_&country._2;
      set Policy_Rule_&country._2;
      run;*/ 
      
      proc datasets lib=work memtype=DATA;   delete Policy_Rule_&country.;   run;
      
     
      proc sql ; 
      create table Out_GEP.&country._UPF as 
      select 
      country,
      scheme,
      cover,
      Cohort,
      Term,
      gl_type_no,
      UEP_TRANS_DATE,
      Rule,
      EXP_PERIOD,
      Quart_Dev,
      Qtr_Period,
      sum(GEP) as GEP,
      payfreq
      /*LEGACY_SCHEME_CODE,
      LEGACY_AGREEMENT_NUMBER,
      LEGACY_RENEWAL_NUMBER*/
      from Out_GEP2.Policy_Rule_&country._2
      where EXP_PERIOD <= &DT_Arrete_Reel. 
      group by country,scheme,cover,Cohort,Term,gl_type_no,UEP_TRANS_DATE,Rule,EXP_PERIOD,Quart_Dev,Qtr_Period,payfreq /*,LEGACY_SCHEME_CODE,LEGACY_AGREEMENT_NUMBER, LEGACY_RENEWAL_NUMBER */;     
      quit ; 
	     
      
/********************************************************************************************************************************************/
/******************************************************     Input EA   **************************************************************/ 
/********************************************************************************************************************************************/
  
data &country._EA_UPF ;
set Out_GEP2.Policy_Rule_&country._2 ;
where EXP_PERIOD <= &DT_Arrete_Reel. ;
retain country product Product_VERSION cover start_year Date_Cal GL_TYPE_NO cancelled  term  Qtr_Period  Quart_Dev GEP payfreq UEP_TBT LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER  ;
keep country product Product_VERSION cancelled cover GL_TYPE_NO term  Qtr_Period GEP Quart_Dev start_year Date_Cal payfreq UEP_TBT LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER;
if NB_RT =. then cancelled=1 ;
else cancelled=0 ;
FORMAT Date_Cal DATE9. ; 
Date_Cal = &DT_Arrete_Reel.;
start_year=year(start_date);
rename 
GL_TYPE_NO=entity
Product_VERSION=product_version;
IF term=. then delete ;
run ;

proc sql ; 
create table EA.&country._EA_UPF as 
select distinct
country,
product,
product_version,
cover,
start_year,
entity,
Date_Cal,
cancelled,
term,
Qtr_Period,
Quart_Dev,
sum(GEP) as GEP,
sum(UEP_TBT) as UEP,
payfreq,
LEGACY_SCHEME_CODE,
LEGACY_AGREEMENT_NUMBER,
LEGACY_RENEWAL_NUMBER
from &country._EA_UPF 
group by country,product,product_version,cover,start_year,entity,Date_Cal,cancelled,term,Qtr_Period,Quart_Dev,payfreq,LEGACY_SCHEME_CODE,LEGACY_AGREEMENT_NUMBER, LEGACY_RENEWAL_NUMBER ; 
quit ; 

proc datasets lib=work memtype=DATA;   delete &country._EA_UPF;      run;    


/********************************************************************************************************************************************/
/******************************************************    UEP BGD FORMAT --> Reel **********************************************************/ 
/********************************************************************************************************************************************/

proc SQL;
create table OUT_GEP.POLICY_RULE_&country._BGD AS
select country, cover, PRODUCT, PRODUCT_VERSION, cancel_date, EXP_PERIOD, POLICY_LINE_NO, GL_TYPE_NO, start_date, 
sum(TOTAL_COMMISSION) AS TOTAL_COMMISSION,  sum(UEP_TBT) AS UEP_TBT, sum(premium) AS premium
from OUT_GEP2.POLICY_RULE_&country._2
group by  country, cover, PRODUCT, PRODUCT_VERSION, cancel_date, EXP_PERIOD, POLICY_LINE_NO, GL_TYPE_NO, start_date;
quit ; 

proc datasets lib=work memtype=DATA;   delete Policy_Rule_&country._2;   run;  
proc datasets lib=OUT_GEP2 memtype=DATA;   delete Policy_Rule_&country._2;   run;  

%mend ; 
    
      %Prepa_Table(country = NETHERLANDS) ;
      %GEP_Calc(country = NETHERLANDS,country_code = NL) ;
            
      %Prepa_Table(country =POLAND ) ;
      %GEP_Calc(country = POLAND ,country_code = PL) ;       
 
      %Prepa_Table(country = NORTHERNIRELAND) ; 
      %GEP_Calc(country = NORTHERNIRELAND,country_code = NI) ;
           
      %Prepa_Table(country = NORWAY) ; 
      %GEP_Calc(country = NORWAY, country_code = NO) ;  
             
      %Prepa_Table(country = FINLAND) ; 
      %GEP_Calc(country = FINLAND, country_code = FI) ;
  
      %Prepa_Table(country = ESTONIA) ; 
      %GEP_Calc(country = ESTONIA, country_code = EE) ; 
          
      %Prepa_Table(country = COLOMBIA) ; 
      %GEP_Calc(country = COLOMBIA, country_code = CO) ; 
      
      %Prepa_Table(country = PERU) ; 
      %GEP_Calc(country = PERU ) ;
      
      %Prepa_Table(country = LATVIA) ; 
      %GEP_Calc(country = LATVIA ) ;
     
      %Prepa_Table(country = LITHUANIA) ; 
      %GEP_Calc(country = LITHUANIA ) ; 
      
      %Prepa_Table(country = MEXICO) ; 
      %GEP_Calc(country = MEXICO, country_code = MX ) ; 
            
      %Prepa_Table(country = GREECE) ;
      %GEP_Calc(country = GREECE, country_code = GR) ;  
             
      %Prepa_Table(country = GERMANY) ;
      %GEP_Calc(country = GERMANY, country_code = DE) ;      
      
      %Prepa_Table(country = SPAIN) ; 
      %GEP_Calc(country = SPAIN, country_code = ES) ;    
     
	  %Prepa_Table(country = DENMARK) ;
      %GEP_Calc(country = DENMARK, country_code = DK) ;
                    
      %Prepa_Table(country = TURKEY) ; 
      %GEP_Calc(country = TURKEY ,country_code = TR) ;
      
      %Prepa_Table(country = SWEDEN) ;
      %GEP_Calc(country = SWEDEN, country_code = SE) ;
      
      %Prepa_Table(country =UK) ;  
      %GEP_Calc(country = UK ,country_code = UK) ;
            
      %Prepa_Table(country = SWITZERLAND) ; 
      %GEP_Calc(country = SWITZERLAND,country_code = CH) ;   
     
      %Prepa_Table(country = IRELAND) ; 
      %GEP_Calc(country = IRELAND ,country_code = IE) ; 
     
      %Prepa_Table(country = AUSTRIA) ; 
      %GEP_Calc(country = AUSTRIA, country_code = AT) ;
      
      %Prepa_Table(country = BELGIUM) ; 
      %GEP_Calc(country = BELGIUM, country_code = BE) ; 
      
         
            
      %Prepa_Table(country = ITALY11) ;
      %GEP_Calc(country = ITALY11, country_code = IT) ;      
      
      %Prepa_Table(country = ITALY12) ;
      %GEP_Calc(country = ITALY12,country_code = IT) ; 
      
      %Prepa_Table(country = ITALY31) ;
      %GEP_Calc(country = ITALY31,country_code = IT) ; 
      
      %Prepa_Table(country = ITALY32) ;
      %GEP_Calc(country = ITALY32,country_code = IT) ;
            
      %Prepa_Table(country = ITALY41) ;
      %GEP_Calc(country = ITALY41,country_code = IT) ; 
      
      %Prepa_Table(country = ITALY42) ;
      %GEP_Calc(country = ITALY42,country_code = IT) ; 
      
      %Prepa_Table(country = ITALY51) ;
      %GEP_Calc(country = ITALY51,country_code = IT) ;
      
      %Prepa_Table(country = ITALY52) ;
      %GEP_Calc(country = ITALY52,country_code = IT) ;
      
      %Prepa_Table(country = ITALY61) ;
      %GEP_Calc(country = ITALY61,country_code = IT) ;	
 
      %Prepa_Table(country = ITALY62) ;
      %GEP_Calc(country = ITALY62,country_code = IT) ;		  

      %Prepa_Table(country = ITALY71) ;
      %GEP_Calc(country = ITALY71,country_code = IT) ;	

      %Prepa_Table(country = ITALY72) ;
      %GEP_Calc(country = ITALY72,country_code = IT) ;		  
 
      %Prepa_Table(country = ITALY81) ;
      %GEP_Calc(country = ITALY81,country_code = IT) ;	

      %Prepa_Table(country = ITALY82) ;
      %GEP_Calc(country = ITALY82,country_code = IT) ;	

      %Prepa_Table(country = ITALY91) ;
      %GEP_Calc(country = ITALY91,country_code = IT) ;	

      %Prepa_Table(country = ITALY92) ;
      %GEP_Calc(country = ITALY92,country_code = IT) ;	

      %Prepa_Table(country = ITALY101) ;
      %GEP_Calc(country = ITALY101,country_code = IT) ;	

      %Prepa_Table(country = ITALY102) ;
      %GEP_Calc(country = ITALY102,country_code = IT) ;



      %Prepa_Table(country = PORTUGAL1) ;
      %GEP_Calc(country = PORTUGAL1,country_code = PT) ;	

      %Prepa_Table(country = PORTUGAL2) ;
      %GEP_Calc(country = PORTUGAL2,country_code = PT) ;

      %Prepa_Table(country = PORTUGAL31) ;
      %GEP_Calc(country = PORTUGAL31,country_code = PT) ;

      %Prepa_Table(country = PORTUGAL32) ;
      %GEP_Calc(country = PORTUGAL32,country_code = PT) ;

      %Prepa_Table(country = PORTUGAL4) ;
      %GEP_Calc(country = PORTUGAL4,country_code = PT) ;	

      %Prepa_Table(country = PORTUGAL51) ;
      %GEP_Calc(country = PORTUGAL51,country_code = PT) ;	

      %Prepa_Table(country = PORTUGAL52) ;
      %GEP_Calc(country = PORTUGAL52,country_code = PT) ;
	  

	  
 
        
        
      /*  systask command "du -sh /mutu/FW/users/METIER/DTA" shell wait ;  */
	  
	  
	  
      