/*####################################################*/
/*################### INVENTAIRE TIA #################*/
/*####################################################*/

/*#########################################################################*/
/*################### 2�me Etape: Extraction des donn�es  #################*/
/*#########################################################################*/


%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete = 2026_04_V2;
/*********************************************************************************/

LIBNAME TIA "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/TIA";

/*------------------------------------------------------------------*/
*==Nouveau libname � condition d'�tre dans le groupe Unix gg_sas_db_clp ==;
/*----------------------------------------------------------------*/
/**** MODOP acc�s au datalake CLP via WPS AXA France ****/ 
/*---------------------------------------------------------------*/
* 1/ V�rifier que vous �tes bien connect� au hub :
- WPS > Hub > Connexion
- Mettre son matricule Sxxxxxx 
- Mettre son mdp habituel de connexion � WPS ;

* 2/ Lanc� la nouvelle libname ci-dessous :
- nom_libname => � changer selon le nom de la libname souhait�
- nom_db => ne pas changer 
- nom_schema => ne pas changer 
- nom_options => ne pas changer ;

/**************************************************************/


/******* data lake CLP*********/
    %wps_mac_connexion_db(
    nom_libname = clp_wps ,
    nom_db = WPS_SHINE_BLCL ,
    nom_schema = clp_wps ,
    nom_options = readbuff=10000 schema=clp_wps
    );

LIBNAME clp_wps odbcold  DSN=WPS_SHINE_BLCL  authdomain="DB_WPS_SHINE_BLCL"  schema=clp_wps ;    
    
    
data TIA.Daap_level_1_dueonly ;
set  CLP_WPS.daap_level_1_dueonly;
run ;


data TIA.idcf_fr_ugip_cl;
set CLP_WPS.idcf_fr_ugip_cl ;
run ;

