/****************************************** Param�trage ***********************************************/

%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%let Arrete = 2026_06_Prov;
%let quarter = 2026Q2;
%let month_reserving=06 ;
%let day_reserving=26 ;
%let yr_reserving=2026 ;
%let Ouput=CR_Q226;
%let month=06;
%let day=26;
%let yr=2026;
%let DT_Arrete_Reel = "26JUN2026"d ; 


/* Quarter � chang� � chaque arr�t� : 8 derniers */



%let Q1= _2024Q3_Res;
%let Q2= _2024Q4_Res;
%let Q3= _2025Q1_Res;
%let Q4= _2025Q2_Res;
%let Q5= _2025Q3_Res;
%let Q6= _2025Q4_Res;
%let Q7= _2026Q1_Res;
%let Q8= _2026Q2_Res;

%let S1= _2024Q3;
%let S2= _2024Q4;
%let S3= _2025Q1;
%let S4= _2025Q2;
%let S5= _2025Q3;
%let S6= _2025Q4;
%let S7= _2026Q1;
%let S8= _2026Q2;

/**************************************************************************************************/

LIBNAME &Ouput."~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
LIBNAME Out_GEP "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/GEP/Output/DAAP" ;


%let Import_01="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/NON-CORE-COVER/Parametre/cover_params.xlsx";
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=all_params,ONGLET=param_all);
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Greece_params,ONGLET=param_GR);
%IMPORT_EXCEL(FILE=&Import_01.,OUT=cover_dev,ONGLET=Cover_code);


%let Import_01="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/2021_11_Q4/02_Elements_Techniques/TIA/Extraction Donnees/20210408 List TIA scheme exclusion - C and TPA.xlsx" ;
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT
DATAFILE= &FILE.
OUT= &OUT.
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=flag_double,ONGLET="Sheet1");
data FLAG_DOUBLE;
set FLAG_DOUBLE;
RUN;


%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx" ;      
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=flag_legacy,ONGLET="flag_legacy");

/**************************************************************************************************/

%macro NON_CORE(CC=,);
/*%let CC =SE;*/

data &CC._DATA_0 ;
keep country scheme cover Entity_CD Quarter COVER_CODE Quarter2 REP GEP Claim_Paid Agent Product year QTR Key;
set OUT_GEP.HISTO_FLUX_&CC.;
where Rsrv_Grp="ZZ1" ;
year=substr(Quarter,3,4);
QTR=substr(Quarter,1,2);
Quarter2=cats(year,QTR);
if country="DK" and scheme in ("1F.1","1G.1") then delete ;
length Key $100.;
Key=cats(country,Agent,Product,cover,Entity_CD);
run;


/*Exclusion des schemes de macao et la categorie C existante dans WEB*/
proc sql ;
create table &CC._DATA_0  as
select
t1.*,
t7.RI_inwards_cash_matching AS flag_web
from &CC._DATA_0  t1
left join flag_double t7 on (t1.country=t7.Country_CD AND t1.scheme=t7.contract_id_version);
quit ;

DATA &CC._DATA_0;
set &CC._DATA_0 ;
if flag_web="" then LEGACY_WEBXL_BOOK="TIA";
if flag_web ne "" then LEGACY_WEBXL_BOOK="WEBXL";
run ;

DATA &CC._DATA_0 ;
set &CC._DATA_0;
where LEGACY_WEBXL_BOOK="TIA";
drop LEGACY_WEBXL_BOOK flag_web;
Run;

proc sql ; 
create table &CC._DATA_0 as 
select 
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao as Flag_Macao 
from &CC._DATA_0  t1 
left join FLAG_LEGACY t8 on (t1.country=t8.country AND t1.scheme=t8.scheme and t1.cover=t8.Cover);
quit ; 

DATA &CC._DATA_0  ;
set &CC._DATA_0  ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","")  then LEGACY_SCHEME_BOOK="TIA";
drop informer_type RPP Flag_Macao;
run ;

data &CC._DATA_0;
set &CC._DATA_0;
where LEGACY_SCHEME_BOOK="TIA";
drop LEGACY_SCHEME_BOOK;
run;

/* Fin de l'exclusion*/


*On garde les 8 derniers quarters d�fini; 
PROC SQL;
create table &CC._DATA_1 as
SELECT DISTINCT cover,
                scheme,
                Entity_CD as GL_TYPE_NO, 
                sum(REP) as Risk_earned_prem,
                sum(Claim_Paid) as Claim_Paid,
                country as COUNTRY_CD,
                Product,
                Agent,
                Quarter2 as Quarter
FROM &CC._DATA_0
where Quarter2 = substr("&S1.",2,6) or Quarter2 = substr("&S2.",2,6)  or Quarter2 = substr("&S3.",2,6)
or Quarter2 = substr("&S4.",2,6)  or Quarter2 = substr("&S5.",2,6)  or Quarter2 = substr("&S6.",2,6)  
or Quarter2 = substr("&S7.",2,6)  or Quarter2 = substr("&S8.",2,6)  
group by country, scheme,Agent, Product, cover,Entity_CD,Quarter2,Key; 
quit;

PROC SQL;
create table &CC._DATA_AGG as
SELECT DISTINCT country,
                Agent,
                Product,
                cover,
                Entity_CD as GL_TYPE_NO,
                Quarter2 as Quarter,
                Key, 
                sum(GEP) as GEP,
                sum(REP) as REP,
                sum(Claim_Paid) as clms_pd
FROM &CC._DATA_0
where Quarter2 = substr("&S1.",2,6) or Quarter2 = substr("&S2.",2,6)  or Quarter2 = substr("&S3.",2,6)
or Quarter2 = substr("&S4.",2,6)  or Quarter2 = substr("&S5.",2,6)  or Quarter2 = substr("&S6.",2,6)  
or Quarter2 = substr("&S7.",2,6)  or Quarter2 = substr("&S8.",2,6)  
group by country, Agent, Product, cover,Entity_CD,Quarter2,Key; 
quit;

PROC SQL;
create table &CC._DATA_AGG0 as
SELECT DISTINCT t1.cover,
                t1.Quarter,
                t1.Key,
                sum(t1.REP) as REP,
                sum(t1.clms_pd) as clms_pd,
                t2.Group
FROM &CC._DATA_AGG t1
left join WORK.COVER_DEV t2 on (t1.cover=t2.Cover_Code)
group by Quarter,Key; 
quit;

DATA &CC._DATA_AGG00;
set &CC._DATA_AGG0;
Ultimate_Liability_Factor = 0.8;
REP1 = REP * Ultimate_Liability_Factor;
drop REP Ultimate_Liability_Factor;
Rename REP1=REP;
run;


*Le taux de dev est ramen�; 
%IF &CC. = GR %THEN %DO;
PROC SQL;
create table &CC._DATA_AGG1 as
SELECT t1.*,
       t3.taux_dev                                                                       
FROM &CC._DATA_AGG00 t1
left join WORK.GREECE_PARAMS t3 on (t1.Quarter=t3.quarter and t1.Group=t3.Cover)
group by Quarter,Key; 
quit;
%END;

%ELSE %DO;
PROC SQL;
create table &CC._DATA_AGG1 as
SELECT t1.*,
       t3.taux_dev
FROM &CC._DATA_AGG00 t1
left join WORK.ALL_PARAMS t3 on (t1.Quarter=t3.quarter and t1.Group=t3.Cover)
group by Quarter,Key;
quit;
%END;

data &CC._DATA_AGG1;
set &CC._DATA_AGG1;
if taux_dev=. then delete;
run;

*taux de dev appliqu� manuellement pour 2 cl�s ;
data &CC._DATA_AGG1;
set &CC._DATA_AGG1;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S1.",2,6) then taux_dev = 0.96;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S1.",2,6) then taux_dev = 0.96;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S2.",2,6) then taux_dev = 0.9;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S2.",2,6) then taux_dev = 0.9;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S3.",2,6) then taux_dev = 0.84;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S3.",2,6) then taux_dev = 0.84;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S4.",2,6) then taux_dev = 0.78;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S4.",2,6) then taux_dev = 0.78;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S5.",2,6) then taux_dev = 0.72;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S5.",2,6) then taux_dev = 0.72;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S6.",2,6) then taux_dev = 0.54;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S6.",2,6) then taux_dev = 0.54;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S7.",2,6) then taux_dev = 0.36;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S7.",2,6) then taux_dev = 0.36;
if Key = "DKIKANO BANKCredit CardRL101" and Quarter = substr("&S8.",2,6) then taux_dev = 0.18;
if Key = "DKIKANO BANKPersonal LoanDM102" and Quarter = substr("&S8.",2,6) then taux_dev = 0.18;
RUN;


PROC SQL;
create table &CC._DATA_AGG2 
as SELECT * , taux_dev*REP  as Expected_claims , REP-Expected_claims as Expected_Reserve
FROM &CC._DATA_AGG1
group by Quarter,Key; 
quit;


PROC SQL;
create table &CC._DATA_AGG3 as
SELECT distinct key,cover,
                sum(Expected_claims) as Expected_claims ,
                sum(Expected_Reserve) as Expected_Reserve,
                sum(clms_pd) as clms_pd                                                 
FROM &CC._DATA_AGG2
group by key;
quit;

/* quelques checks */
proc sort data=&CC._DATA_AGG2; by Quarter Key ; run;
proc summary data=&CC._DATA_AGG2 noprint sum;
by  Quarter Key ;
var REP clms_pd;
output out=&CC._check sum()=;
run;

data &CC._check1;
set &CC._check;
if clms_pd+REP=0 then Number_quarter=0;
else Number_quarter = 1 ;
run;

proc sql;
create table &CC._data_check as 
select key,
sum(Number_quarter) as Number_quarter
from &CC._check1
group by Key;
QUIT;


proc sql;
create table &CC._data_check1 as 
select key,
Number_quarter*0.0375*3 as Credib_act_exp
from &CC._data_check
group by Key;
QUIT;

data &CC._data_check1 ; 
set &CC._data_check1 ;
if key = "NOSEB Kort ABPersonal AccidentIP101" then Credib_act_exp=0.1;
run;
/* fin des checks */


proc  sql;
create table &CC._Actual_exp as 
select key,
       sum(REP) as REP,
       sum(Expected_Reserve) as Expected_Reserve,
       sum(Expected_claims) as Expected_claims,
       sum(clms_pd) as clms_pd
from &CC._DATA_AGG2
group by Key;
QUIT;

proc  sql;
create table &CC._Actual_exp as 
select key,
       Expected_Reserve,
       clms_pd/Expected_claims as Acc_exp,
       Acc_exp*Expected_Reserve as resv_acc_act
from &CC._Actual_exp
group by Key;
QUIT;

data &CC._final_record;
merge &CC._Actual_exp &CC._data_check1;
by key;
run;

proc  sql;
create table RESERVES_NC_&CC. as 
select key, 
       Expected_Reserve,
       (resv_acc_act*Credib_act_exp)+Expected_Reserve*(1-Credib_act_exp) as Res
from &CC._final_record
group by Key;
QUIT;

proc  sql;
create table &CC._Acc_year_split as 
select key, 
       Quarter,
       Expected_Reserve,
       sum(Expected_Reserve) as total_exp_res,
       Expected_Reserve/total_exp_res as year_split
from &CC._DATA_AGG2
group by Key;
QUIT;

proc transpose data=&CC._Acc_year_split OUT = &CC._transpos;
var year_split;
By Key;
ID Quarter;
run;


data test(keep = Key &S1.  &S2. &S3. &S4. &S5. &S6. &S7. &S8.);
set  &CC._transpos;
run;



/* Split par scheme */

PROC SQL;
CREATE TABLE &CC._Data2 as 
SELECT Distinct COUNTRY_CD as country, Agent, Product, scheme, cover, GL_TYPE_NO as Entity_CD,sum(Risk_earned_prem) as REP
from &CC._Data_1
GROUP BY Agent, Product, Scheme, cover, Entity_CD;
QUIT;

PROC SQL;
CREATE TABLE &CC._Data3 as 
SELECT Distinct country, Agent, Product, scheme, cover, Entity_CD,REP, REP/sum(REP) as Scheme_Premium_Proportion 
from &CC._Data2 
GROUP BY Agent, Product, cover, Entity_CD;
QUIT;

data &CC._Data3 ;
set &CC._Data3 ;
if Scheme_Premium_Proportion=. then Scheme_Premium_Proportion=0 ;
run ;

data reserves_nc_&CC. ;
set  RESERVES_NC_&CC.;
Res2=Res*1  ;
run ;

data reserves_nc1_&CC.;
merge reserves_nc_&CC. &CC._transpos ;
by Key;
run;

data reserves_nc1_&CC.;
set reserves_nc1_&CC.;
if Key in (
"SEZensumExpense ProtectionIA101" ,
"SEZensumExpense ProtectionIS101" ,
"SEZensumExpense ProtectionUR101" ,
"SEFreedom FinanceExpense ProtectionFL102",
"SEFreedom FinanceExpense ProtectionIA101",
"SEFreedom FinanceExpense ProtectionIS101",
"SEFreedom FinanceExpense ProtectionUR101",
"SEZmartaExpense ProtectionFL102", 
"SEZmartaExpense ProtectionIA101", 
"SEZmartaExpense ProtectionIS101", 
"SEZmartaExpense ProtectionUR101", 
"SEZmartaExpense ProtectionIA102", 
"SEZmartaExpense ProtectionIM101", 
"SEZmartaExpense ProtectionIM102", 
"SEZmartaExpense ProtectionIS102", 
"SEZmartaExpense ProtectionUU101") 
then Res2=Res2*0.5 ;
run;

proc sql;
create table RESERVES_NCC_&CC. as
select distinct t1.*, t2.Agent,t2.Product,t2.cover,t2.GL_TYPE_NO
from RESERVES_NC1_&CC. t1
left join &CC._DATA_AGG t2 on (t1.Key=t2.Key); 
quit;

PROC SQL;
CREATE TABLE &CC._reserves0 as 
SELECT Distinct p.country as Country, p.Agent, p.Product, p.scheme as Scheme, p.cover as Cover, p.Entity_CD as UWCO, p.Scheme_Premium_Proportion*q.Res2 as Reserve,
q.*
from &CC._Data3 p
LEFT JOIN  reserves_ncc_&CC. q on (p.Agent=q.Agent and p.Product=q.Product and p.cover=q.Cover and p.Entity_CD=q.GL_TYPE_NO);
QUIT;


data &CC._reserves0;
set  &CC._reserves0;
if Reserve = 0 or Reserve = . then delete;
run;

data &CC._reserves0(drop=_NAME_ GL_TYPE_NO);
set  &CC._reserves0;
run;

data &CC._RESERVES1;
set &CC._RESERVES0;
&Q1.=Reserve*&S1.;
&Q2.= Reserve*&S2.;
&Q3.= Reserve*&S3.; 
&Q4.= Reserve*&S4.; 
&Q5.= Reserve*&S5.; 
&Q6.= Reserve*&S6.; 
&Q7.= Reserve*&S7.; 
&Q8.= Reserve*&S8.;
run;



data &CC._RESERVES1;
set &CC._RESERVES1;
drop &S1. &S2. &S3. &S4. &S5. &S6. &S7. &S8.; 
run;


proc sort data=&CC._RESERVES1 ;
  by Country Agent Product Scheme Cover UWCO;
run ;

proc transpose data=&CC._RESERVES1 out=&CC._RESERVES2(rename=(_NAME_=Quarter COL1=Reserve_bis )) ;
  by Country Agent Product Scheme Cover UWCO ;
  var &Q1. &Q2. &Q3. &Q4. &Q5. &Q6. &Q7. &Q8.;
run ;


DATA &CC._reserves_final(keep=Country Scheme Cover UWCO Reserve Acc_Qtr  Acc_Yr );
set &CC._RESERVES2;


if Quarter = "&Q1." then Quarter = substr("&Q1.",2,6);
if Quarter = "&Q2." then Quarter = substr("&Q2.",2,6);
if Quarter = "&Q3." then Quarter = substr("&Q3.",2,6);
if Quarter = "&Q4." then Quarter = substr("&Q4.",2,6);
if Quarter = "&Q5." then Quarter = substr("&Q5.",2,6);
if Quarter = "&Q6." then Quarter = substr("&Q6.",2,6);
if Quarter = "&Q7." then Quarter = substr("&Q7.",2,6);
if Quarter = "&Q8." then Quarter = substr("&Q8.",2,6);
if Reserve_bis = . then delete;
Acc_Yr = substr(Quarter,1,4);
rename Quarter=Acc_Qtr;

rename Reserve_bis=Reserve;
run;


%macro EXPORT_EXCEL(DATABASE=,);

%let Import="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/NON-CORE-COVER/Reporting/&quarter./Accident Quarter Splits";

PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Import.
DBMS=xlsx REPLACE ;
SHEET = &DATABASE. ;
run;
%MEND;

%EXPORT_EXCEL(DATABASE=&CC._reserves_final);

%mend;


%NON_CORE(CC=PT);
%NON_CORE(CC=CH);
%NON_CORE(CC=FR);
%NON_CORE(CC=DE);
%NON_CORE(CC=DK);
%NON_CORE(CC=IE);
%NON_CORE(CC=GR);

/********Debut traitement de la Gr�ce*************/
data GR_RESERVES_FINAL;
    set GR_RESERVES_FINAL;
    if Country = "GR" and Scheme in ("BP3.3", "BP3.4", "BP5.3", "BP5.4", "BP7.3", "BP7.4") then Reserve= 0;
run;
%EXPORT_EXCEL(DATABASE=gr_reserves_final);
/*********Fin traitement de le Gr�ce************/

%NON_CORE(CC=PL);
%NON_CORE(CC=TR);
%NON_CORE(CC=ES);
%NON_CORE(CC=NO);
%NON_CORE(CC=SE);
%NON_CORE(CC=FI);
%NON_CORE(CC=NL);
%NON_CORE(CC=IT);
%NON_CORE(CC=UK);

/********Debut traitement de UK sur le sinistre en litige sur UK : Ce sera statu� en octobre 2026*************/
/*data UK_OBS;
    Country = "UK";
    Scheme = "YAD.4";
    Cover = "IE";
    UWCO = 101;
    Acc_Qtr = "2016Q2";
    Reserve = 450000;
    Acc_Yr = "2016";
run;

data UK_RESERVES_FINAL_TEST;
    set UK_RESERVES_FINAL;
run;

data UK_RESERVES_FINAL;
    set UK_RESERVES_FINAL_TEST UK_OBS;
run;

%EXPORT_EXCEL(DATABASE=UK_reserves_final);*/

/*********Fin traitement de UK************/

%NON_CORE(CC=CO);
%NON_CORE(CC=AT);
%NON_CORE(CC=MX);
%NON_CORE(CC=BE);


/*data UK_RESERVES_FINAL;
    set UK_RESERVES_FINAL_TEST;
run;*/

%Macro NC_SPLIT(pays=,);
/*%let pays=GR;*/

data Non_Core_cover_&pays._In ;
length Scheme2 $40.;
Retain Country Rsrv_Grp Scheme Scheme2 Acc_Yr Acc_Yr2 Cover UWCO  Incident_Quarter Rsrv_Typ Reserve   ;
keep   Country Rsrv_Grp Scheme Scheme2 Acc_Yr Acc_Yr2 Cover UWCO Reserve Incident_Quarter Rsrv_Typ  ;
set &pays._reserves_final ;
rename UWCO = Entity_CD ;
Acc_Yr=substr(Acc_Qtr,1,4)*1;
Qtr=substr(Acc_Qtr,5,2) ;
Incident_Quarter=cats(Acc_Yr,Qtr);
Rsrv_Grp="ZZ1";
Rsrv_Typ="IBNR";
Scheme2=Scheme;
Acc_Yr2=Acc_Yr*1;
run;	

PROC SQL;
create table Non_Core_cover_&pays._0 as
SELECT distinct country,
                Rsrv_Grp,
                Scheme2 as Scheme,
                Cover,
                Entity_CD,
                Acc_Yr2 as SURV,
                Incident_Quarter, 
                Rsrv_Typ,
                sum(Reserve) AS Reserve
FROM Non_Core_cover_&pays._In
group by country,Rsrv_Grp,Scheme2,Cover,Entity_CD,Incident_Quarter,Rsrv_Typ;
quit;

DATA NC_withplyr_&pays.;
Keep Country Cvr_Typ Schm Undrwrtng_Cmpny Entity_CD Cohort Acc_Yr Totl_Amnt_Pd  ;
set &Ouput..CLMHDR_ALL_&pays. ;
WHERE country="&pays." and Rsrv_Grp in ("ZZ1")  ;
Cohort=year(Incptn_Dt);
rename 
Cvr_Typ=Cover

Schm=Scheme
;
Entity_CD=Undrwrtng_Cmpny*1;
run;

Proc sort data=NC_withplyr_&pays. nodupkey out=NC_withplyr_&pays.; by Scheme Cover Entity_CD  Acc_Yr Cohort   ; run; 

PROC SQL;
      create table SUM_NC_1_&pays. as
             SELECT country,
             Scheme,
             Cover,
             Entity_CD,
             Cohort,
             Acc_yr AS SURV,            
             sum(Totl_Amnt_Pd) AS MONTANT
     FROM    NC_withplyr_&pays.
     
     group by Scheme,Cover,Entity_CD,Cohort,Acc_yr;
     
 quit;

PROC SQL;
      create table SUM_NC_2_&pays. as
             SELECT DISTINCT country,
             Scheme,
             Cover,
             Entity_CD,
             Acc_yr AS SURV,             
             sum(Totl_Amnt_Pd) AS MONTANT2
     FROM    NC_withplyr_&pays.
     
     group by Scheme,Cover,Entity_CD,Acc_yr;
     
 quit;

proc sql ; 
create table SUM_NC_3_&pays. as
select 
t1.*,
t2.MONTANT2 as MONTANT2
from SUM_NC_1_&pays./*_ALL*/ t1 
left join SUM_NC_2_&pays. t2 on (t1.Scheme=t2.Scheme and t1.Cover=t2.Cover and t1.Entity_CD=t2.Entity_CD and t1.SURV=t2.SURV) ;

quit ; 

DATA SUM_NC_4_&pays. ;
set SUM_NC_3_&pays. ;
weight=MONTANT/MONTANT2 ;
DROP MONTANT MONTANT2 ;
IF weight=. then delete ;
run;

proc sql ; 
create table NON_CORE_COVER_&pays._1 as
select 
t1.*,
t2.Cohort,
t2.weight as weight
from Non_Core_cover_&pays._0/*_ALL*/ t1 
left join SUM_NC_4_&pays. t2 on (t1.Scheme=t2.Scheme and t1.Cover=t2.Cover and t1.Entity_CD=t2.Entity_CD and t1.SURV=t2.SURV) ;

quit ;


DATA NON_CORE_COVER_&pays. ;
retain Country Rsrv_Grp Scheme Cohort Cover  Entity_CD Incident_Quarter Date_of_reserving  Rsrv_Typ Rsrv_Amt ;
keep Country Rsrv_Grp Scheme Cover Entity_CD Incident_Quarter  Cohort Rsrv_Amt Rsrv_Typ Date_of_reserving ;
set NON_CORE_COVER_&pays._1 ;
if Cohort=. then Cohort=SURV;
if weight=. then weight=1 ;
Rsrv_Amt=weight*Reserve ;
Date_of_reserving="&quarter.";
Rename Cohort=Vintage_year;
run;
 


PROC SQL;
      create table NON_CORE_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Vintage_year,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Date_of_reserving,
                    Rsrv_Typ,
                    sum(Rsrv_Amt) as Rsrv_Amt                                      
     FROM    NON_CORE_COVER_&pays.
     group by country, Scheme,Rsrv_Grp, cover,Vintage_year,Entity_CD,Incident_Quarter,Date_of_reserving,Rsrv_Typ
      ; 
 quit;
 
DATA RESERVES_NC_&pays. ;
set  NON_CORE_&pays.  ;
run;
 
%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Entity_Mappings.xlsx";

%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Reassurance.xlsx";


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=Entity_Mappings,ONGLET=Entity_Mappings);
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Parametres_Reas,ONGLET=Parametres_Reas);

DATA Parametres_Reas ;
set Parametres_Reas ;
run;

data CLMHDR_ALL_&pays. ;
set &Ouput..CLMHDR_ALL_&pays. ;
Entity_CD=Undrwrtng_Cmpny*1 ;
run ;

data PARAMETRES_REAS ;
set PARAMETRES_REAS ;
Entity_CD=Original_underwritter*1 ;
run ;


proc sql ; 
create table RESERVES_NC_&pays. as
select distinct
t1.*,
t8.QP_rei_CLAIM AS QP_rei_CLAIM,
t3.Legal_Entity as Entity
from RESERVES_NC_&pays.  t1 
left join Parametres_Reas t8 on (t1.country=t8.country AND t1.scheme=t8.scheme AND t1.cover=t8.cover AND t1.Entity_CD=t8.Entity_CD) 
left join CLMHDR_ALL_&pays. t3 on (t1.country=t3.country AND t1.Scheme=t3.Schm AND t1.Cover=t3.Cvr_Typ AND t1.Entity_CD=t3.Entity_CD) 
 
 ;
quit ; 

data RESERVES_NC_&pays.;
set RESERVES_NC_&pays. ;
if QP_rei_CLAIM=. then Type_Insurance=0 ;
if QP_rei_CLAIM NOT IN (.) then Type_Insurance=4 ;
rename Rsrv_Amt=Rsrv_Amt_Gross ;
if Type_Insurance=0 then QP_rei_CLAIM=1; 

run;

data RESERVES_NC_&pays.;
RETAIN country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD Entity  Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
keep country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
set RESERVES_NC_&pays.;
Rsrv_Amt_Net= Rsrv_Amt_Gross*QP_rei_CLAIM;
run;

Proc sort data=RESERVES_NC_&pays. nodupkey out=&Ouput..RESERVES_NC_&pays.; by country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD Entity  Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ   ; run; 

proc datasets lib=work memtype=DATA;   delete CLMHDR_ALL_&pays. ;         run;
proc datasets lib=work memtype=DATA;   delete PARAMETRES_REAS ;           run;
proc datasets lib=work memtype=DATA;   delete NON_CORE_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete NON_CORE_COVER_&pays. ;     run;
proc datasets lib=work memtype=DATA;   delete NON_CORE_COVER_&pays._1 ;   run;
proc datasets lib=work memtype=DATA;   delete SUM_NC_4_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete SUM_NC_3_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete SUM_NC_4_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete SUM_NC_3_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete SUM_NC_2_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete SUM_NC_1_&pays. ;           run;
proc datasets lib=work memtype=DATA;   delete NC_withplyr_&pays. ;        run;
proc datasets lib=work memtype=DATA;   delete Non_Core_cover_&pays._0 ;   run;
proc datasets lib=work memtype=DATA;   delete Non_Core_cover_&pays._In ;  run;
proc datasets lib=work memtype=DATA;   delete RESERVES_NC_&pays. ;        run;

%MEND;

%NC_SPLIT(pays=DE) ;
%NC_SPLIT(pays=DK) ;
%NC_SPLIT(pays=IE) ;
%NC_SPLIT(pays=IT) ;
%NC_SPLIT(pays=FI) ;
%NC_SPLIT(pays=FR) ;
%NC_SPLIT(pays=GR) ;
%NC_SPLIT(pays=ES) ;
%NC_SPLIT(pays=NO) ;
%NC_SPLIT(pays=PL) ;
%NC_SPLIT(pays=PT) ;
%NC_SPLIT(pays=SE) ;
%NC_SPLIT(pays=TR) ;
%NC_SPLIT(pays=UK) ;

/********Debut traitement de UK sur le sinistre en litige sur UK : Ce sera statu� en octobre 2026*************/
/*data UK_OBSERVATION;
    country="UK";
    Rsrv_Grp="ZZ1";
    Scheme="YAD.4";
    Type_Insurance=0;
    Cover="IE";
    Entity_CD=101;
    Entity="FICL";
    Incident_Quarter="2016Q2";
    Vintage_year=2016;
    Date_of_reserving="2025Q3";
    Rsrv_Typ="IBNR";
    Rsrv_Amt_Gross=450000;
    Rsrv_Amt_Net=450000;  
run;*/

/*data &Ouput..RESERVES_NC_UK;
    set &Ouput..RESERVES_NC_UK UK_OBSERVATION ;
run;*/

/*********Fin traitement de UK************/

%NC_SPLIT(pays=CH) ;
%NC_SPLIT(pays=CO) ;
%NC_SPLIT(pays=AT) ;

data RESERVES_NC_ALL;
retain  country  Scheme Rsrv_Grp Type_Insurance Cover Entity_CD Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net ;
set 
	&Ouput..RESERVES_NC_PT
    &Ouput..RESERVES_NC_DE
    &Ouput..RESERVES_NC_DK
    &Ouput..RESERVES_NC_ES
    &Ouput..RESERVES_NC_IE
    &Ouput..RESERVES_NC_FI
    &Ouput..RESERVES_NC_FR
    &Ouput..RESERVES_NC_GR
    &Ouput..RESERVES_NC_IT
    &Ouput..RESERVES_NC_NO
    &Ouput..RESERVES_NC_PL
    &Ouput..RESERVES_NC_SE
    &Ouput..RESERVES_NC_TR
    &Ouput..RESERVES_NC_UK
    &Ouput..RESERVES_NC_CH
    &Ouput..RESERVES_NC_CO
    &Ouput..RESERVES_NC_AT
;
IF Entity_CD IN (862) and cover in ("RU","DS") then Entity="FICL" ;
if country="FI" and Entity_CD IN (802) and Entity="" then Entity="FACL" ;
if country="ES" and Entity_CD IN (821,861,901,911) and Entity in ("","N/A") then Entity="FICL" ;
if country="ES" and Entity_CD IN (902) and Entity in ("","N/A") then Entity="FACL" ;
if country="SE" and Entity_CD IN (952,902) and Entity in ("","N/A") then Entity="FACL" ;
if country="SE" and Entity_CD IN (912) and Entity in ("","N/A") then Entity="TPA" ;
if country="SE" and Entity_CD IN (911,951,901) and Entity in ("","N/A") then Entity="FICL" ;
if country="TR" and Entity_CD IN (701) and Entity in ("","N/A") then Entity="FICL" ;
if country="NO" and Entity_CD IN (951,952,912) and Entity in ("","N/A") then Entity="TPA" ;
if country="NO" and Entity_CD IN (911) and Entity in ("","N/A") then Entity="FICL" ;
if country="ES" and Entity_CD IN (912) and Entity in ("","N/A") then Entity="FACL" ;
if country="PL" and Entity_CD IN (931,911) and Entity in ("","N/A") then Entity="FICL" ;
if country="PL" and Entity_CD IN (912) and Entity in ("","N/A") then Entity="FACL" ;
if country="PT" and Entity_CD IN (921,951,911,851) and Entity in ("","N/A") then Entity="FICL" ;
if country="PT" and Entity_CD IN (912) and Entity in ("","N/A") then Entity="FACL" ;
if country="FR" and Entity_CD IN (502) and Entity in ("","N/A") then Entity="TPA" ;
if country="TR" and Entity_CD IN (502,501) and Entity in ("","N/A") then Entity="TPA" ;
if country="UK" and Entity_CD IN (821,831,872) and Entity in ("","N/A") then Entity="TPA" ;
if country="UK" and Entity_CD IN (911,901,131,141,971) and Entity in ("","N/A") then Entity="FICL" ;
if country="UK" and Entity_CD IN ("132","912","902","982","972") and Entity in ("","N/A") then Entity="FACL" ;
if country="DE" and Entity_CD IN (502,501) and Entity in ("","N/A") then Entity="TPA" ;
if country="CH" and Entity_CD IN (911) and Entity in ("","N/A") then Entity="FICL" ;
if Type_Insurance in (0,11) and Entity_CD IN ("101","121","181") and Entity in ("","N/A") then Entity="FICL" ;
if Type_Insurance in (0,11) and Entity_CD IN ("102","122","182") and Entity in ("","N/A") then Entity="FACL" ;
if country="DK" and Entity_CD IN (952) and Entity="" then Entity="FACL" ;
if country="DK" and Entity_CD IN (951) and Entity="" then Entity="FICL" ;
if country="GR" and Entity_CD IN (811,841) and Entity="" then Entity="FICL" ;
if country="IT" and Entity_CD IN (821,791,931) and Entity="" then Entity="FICL" ;
if country="PT" and Entity_CD IN (931,831,991) and Entity="" then Entity="FICL" ;
if country="TR" and Entity_CD IN (982) and Entity="" then Entity="FACL" ;
if country="TR" and Entity_CD IN (811,831) and Entity="" then Entity="FICL" ;
run;

Data &Ouput..WPS_DAAP_NCC_&yr.&month.&day. ;
set  RESERVES_NC_ALL ;
if Entity_CD IN (911,951,851,801,861,871,671,811,881,981) and Entity="" then Entity="FICL" ;
if Entity_CD IN (812,842,872,932,992) and Entity="" then Entity="FACL" ;
if country = "CO" and Entity="" then Entity="FICL";
run;

proc datasets lib=work memtype=DATA;   delete RESERVES_NC_ALL ;      run;
