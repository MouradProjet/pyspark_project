/*#########################################################################################################################
######################################### Reserve Mouvement ###############################################################
##########################################################################################################################*/


/* Macro variable: ( � renseigner avant le lancement) */

%let LReseau = X;
%LET Arrete1 = 2026_04_V2 ;
%let Arrete2 =2026_06_Prov ;
%let exer1 = Q126;
%let exer2 = Q226;

*%let pays = BE;

LIBNAME Output1 "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete1./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
LIBNAME Output2 "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete2./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";

/* Import de la SDB */

%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete2./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx" ; 
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE
;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=SDB,ONGLET="SDB");




%Macro Rsrv_Mvt(pays=,exer1=,exer2=,);

/*############################################# Mise en Forme des donn�es  #################################################*/
/* #######################################################################################################################*/

/* - Import et mise en forme des donn�es : 
* - Ajout de PMP_Sales_Name et Agent_Name 
* - Ajout Flag (New Claim / Stock )*/

Proc sql; Create Table CLMHDR_ALL_&pays._&exer1. As
Select Distinct a.Date_of_reserving,
				a.Country,
				a.Rsrv_Typ,
				a.Cover ,
				a.Legal_Entity,	
				a.Cvr_Typ,
				a.Rsrv_Grp ,
				a.Schm,
				a.Clm_Nmbr,
				a.Accdnt_Dt,
				a.Rgstrtn_Dt,
				a.Cls_Dt,
				a.Status,
				a.Otstndng_Balnc,
				a.Probablty_Otstndng,
				a.Totl_Bnfts_Amnt_Pd,
				a.Frst_Bnft_Pd_Yr,
				a.Frst_Bnft_Pd_Mnth,
				a.Latst_Bnft_Pd_Yr,
				a.Latst_Bnft_Pd_Mnth,
				a.Mnthly_Bnft,
				a.Nmbr_Mnths_Pndng,
				a.Nmbr_Bnfts_Pd,
				a.Nmbr_Bnfts_Otstndng,
				a.Rsrv_Amt,
				a.Legal_Entity,
				a.LEGACY_SCHEME_BOOK,		
				b.Agent_Name,
				b.PMP_Sales_Name
From Output1.CLMHDR_ALL_&pays. as a
left join SDB as b on (a.Country = b.Country and a.Schm = b.Scheme)
Where a.Rsrv_Grp not in ("ZZ1","ZZ2") and LEGACY_SCHEME_BOOK ="TIA"  ;
quit ;
/* verifier si la colonne LEGACY_SCHEME_BOOK existe dans la table input CLMHDR*/

Data CLMHDR_ALL_&pays._&exer1.;
set CLMHDR_ALL_&pays._&exer1. ;
rename 
Rsrv_Typ = Rsrv_Typ_&exer1.  
Status = Status_&exer1.
Otstndng_Balnc  = Otstndng_Balnc_&exer1.
Probablty_Otstndng = Probablty_Otstndng_&exer1.
Totl_Bnfts_Amnt_Pd = Totl_Bnfts_Amnt_Pd_&exer1.
Mnthly_Bnft = Mnthly_Bnft_&exer1.
Nmbr_Mnths_Pndng = Nmbr_Mnths_Pndng_&exer1.
Nmbr_Bnfts_Pd = Nmbr_Bnfts_Pd_&exer1.
Nmbr_Bnfts_Otstndng = Nmbr_Bnfts_Otstndng_&exer1.
Rsrv_Amt = Rsrv_Amt_&exer1.;
run ; 



Proc sql; Create Table CLMHDR_ALL_&pays._&exer2. As
Select Distinct a.Date_of_reserving,
				a.Country,
				a.Rsrv_Typ,
				a.Cover ,
				a.Cvr_Typ,
				a.Rsrv_Grp ,
				a.Schm,
				a.Clm_Nmbr,
				a.Accdnt_Dt,
				a.Rgstrtn_Dt,
				a.Cls_Dt,
				a.Status,
				a.Otstndng_Balnc,
				a.Probablty_Otstndng,
				a.Totl_Bnfts_Amnt_Pd,
				a.Frst_Bnft_Pd_Yr,
				a.Frst_Bnft_Pd_Mnth,
				a.Latst_Bnft_Pd_Yr,
				a.Latst_Bnft_Pd_Mnth,
				a.Mnthly_Bnft,
				a.Nmbr_Mnths_Pndng,
				a.Nmbr_Bnfts_Pd,
				a.Nmbr_Bnfts_Otstndng,
				a.Rsrv_Amt,
				a.Legal_Entity,			
				b.Agent_Name,
				b.PMP_Sales_Name
From  Output2.CLMHDR_ALL_&pays. as a
left join SDB as b on (a.Country = b.Country and a.Schm = b.Scheme)
Where Rsrv_Grp not in ("ZZ1","ZZ2") and LEGACY_SCHEME_BOOK ="TIA" ;
quit ;

Data CLMHDR_ALL_&pays._&exer2.;
set CLMHDR_ALL_&pays._&exer2. ;
rename 
Rsrv_Typ = Rsrv_Typ_&exer2.
Status = Status_&exer2.
Otstndng_Balnc  = Otstndng_Balnc_&exer2.
Probablty_Otstndng = Probablty_Otstndng_&exer2.
Totl_Bnfts_Amnt_Pd = Totl_Bnfts_Amnt_Pd_&exer2.
Mnthly_Bnft = Mnthly_Bnft_&exer2.
Nmbr_Mnths_Pndng = Nmbr_Mnths_Pndng_&exer2.
Nmbr_Bnfts_Pd = Nmbr_Bnfts_Pd_&exer2.
Nmbr_Bnfts_Otstndng = Nmbr_Bnfts_Otstndng_&exer2.
Rsrv_Amt = Rsrv_Amt_&exer2.;
run ; 

/* Ajout Flag (New Claim- Stock) */

proc sql;
    create table CLMHDR_ALL_flag as
    select Distinct a.*,
           case when b.Clm_Nmbr is not null then 'Stock'
                else 'New Claim'
           end as Flag
    from CLMHDR_ALL_&pays._&exer2. as a
    left join CLMHDR_ALL_&pays._&exer1. as b
    on a.Clm_Nmbr = b.Clm_Nmbr ;
quit;


/*##########################################  Granularity level : Country x Rsrv_Typ ##############################################
*########################################################################################################################### */

/* exer1 Vs exer2 at the granularity  Country x Rsrv_Typ */

Proc sql ; Create table Rsrv_Amt_&exer1. as 
select Distinct Country ,
				Rsrv_Typ_&exer1. as Rsrv_Typ ,
				Sum(Rsrv_Amt_&exer1.) as Rsrv_Amt_&exer1 
From CLMHDR_ALL_&pays._&exer1.
Where Rsrv_Typ_&exer1. in ("ICOP","RBNP") 
Group by Country , Rsrv_Typ_&exer1. ;
quit
;

Proc sql ; Create table Rsrv_Amt_&exer2. as 

select Distinct Country ,
				Rsrv_Typ_&exer2. as Rsrv_Typ,
				Sum(Rsrv_Amt_&exer2.) as Rsrv_Amt_&exer2.
From CLMHDR_all_&pays._&exer2.
Where Rsrv_Typ_&exer2. in ("ICOP","RBNP") 
Group by Country , Rsrv_Typ_&exer2. ;
quit
;


proc sort data = Rsrv_Amt_&exer1.  ; by country  Rsrv_typ ; run;
proc sort data = Rsrv_Amt_&exer2. ; by country  Rsrv_typ ; run;
 
data Rsrv_Mvt_tot ;
	merge Rsrv_Amt_&exer1. (in=a) Rsrv_Amt_&exer2.(in=b);
	if a or b ;
	by Country Rsrv_typ ;
	&exer2._vs_&exer1. = coalesce(Rsrv_Amt_&exer2.,0) - coalesce(Rsrv_Amt_&exer1.,0);
run;



/*##########################################  Granularity level : Country x Rsrv_Typ x flag   ##############################################
*########################################################################################################################### */


proc sql ; Create Table Rsrv_Mvt_flag As
select  Distinct Country ,
				 Rsrv_Typ_&exer2. ,
				 flag,
				 sum(Rsrv_Amt_&exer2.) as Rsrv_Amt_&exer2.
From CLMHDR_ALL_flag as  a
Where Rsrv_Typ_&exer2. in ("ICOP","RBNP")
group by Country ,Rsrv_Typ_&exer2.,flag   ;
quit ;

proc sql ; Create Table Rsrv_Mvt_cvr As
select  Distinct Country ,
				 Rsrv_Typ_&exer2.,
				 flag,
				 Legal_Entity,
				 cvr_Typ,
				 sum(Rsrv_Amt_&exer2.) as Rsrv_Amt_&exer2.
From CLMHDR_ALL_flag as  a
Where Rsrv_Typ_&exer2. in ("ICOP","RBNP")
group by Country ,Rsrv_Typ_&exer2.,flag , Legal_Entity , Cvr_Typ ;
quit ;
/*##########################################  Granularity level : Country x Rsrv_Typ x Legal_Entity  ##############################################
*########################################################################################################################### */

proc sql; create Table Rsrv_Mvt_&exer1._LE AS
Select Distinct Country,
				Rsrv_Typ_&exer1. as Rsrv_Typ,
				Legal_Entity,
				sum(Rsrv_Amt_&exer1.) As Rsrv_Amt_&exer1.
From CLMHDR_ALL_&pays._&exer1. As a
Where Rsrv_Typ_&exer1. in ("ICOP","RBNP") 
Group by Country , Rsrv_Typ_&exer1. ,Legal_Entity ;

proc sql; create Table Rsrv_Mvt_&exer2._LE AS
Select Distinct Country,
				Rsrv_Typ_&exer2. as Rsrv_Typ,
				Legal_Entity,
				sum(Rsrv_Amt_&exer2.) As Rsrv_Amt_&exer2.
From CLMHDR_ALL_flag As a
Where Rsrv_Typ_&exer2. in ("ICOP","RBNP") 
Group by Country , Rsrv_Typ_&exer2. ,Legal_Entity;
quit ;

proc sort data = Rsrv_Mvt_&exer1._LE  ; by Rsrv_typ Legal_Entity ; run;
proc sort data = Rsrv_Mvt_&exer2._LE ; by Rsrv_typ Legal_Entity; run;
 
data Rsrv_Mvt_LE;
	merge Rsrv_Mvt_&exer1._LE (in=a) Rsrv_Mvt_&exer2._LE(in=b);
	if a or b ;
	by Rsrv_typ Legal_Entity ;
	&exer2._vs_&exer1. = coalesce(Rsrv_Amt_&exer2.,0) - coalesce(Rsrv_Amt_&exer1.,0);
run;

/*##########################################  Granularity level : Country x Rsrv_Typ x Legal_Entity x Cover type  ##############################################
*########################################################################################################################### */

proc sql; create Table Rsrv_Mvt_&exer1._Cvr AS
Select Distinct Country,
				Rsrv_Typ_&exer1. as Rsrv_Typ ,
				Legal_Entity,
				Cvr_Typ,
				sum(Rsrv_Amt_&exer1.) As Rsrv_Amt_&exer1.
From CLMHDR_ALL_&pays._&exer1. As a
Where Rsrv_Typ_&exer1. in ("ICOP","RBNP") 
Group by Country , Rsrv_Typ_&exer1. ,Legal_Entity, Cvr_Typ ;


proc sql; create Table Rsrv_Mvt_&exer2._Cvr AS
Select Distinct Country,
				Rsrv_Typ_&exer2. as Rsrv_Typ ,
				Legal_Entity,
				Cvr_Typ ,
				sum(Rsrv_Amt_&exer2.) As Rsrv_Amt_&exer2.
From CLMHDR_ALL_flag As a
Where Rsrv_Typ_&exer2. in ("ICOP","RBNP") 
Group by Country , Rsrv_Typ_&exer2. ,Legal_Entity, Cvr_Typ;
quit ;

proc sort data = Rsrv_Mvt_&exer1._Cvr ; by Rsrv_typ Legal_Entity Cvr_Typ ; run;
proc sort data = Rsrv_Mvt_&exer2._Cvr ; by Rsrv_typ Legal_Entity Cvr_Typ ; run;
 
data Rsrv_Mvt_Cvr ;
	merge Rsrv_Mvt_&exer1._Cvr (in=a) Rsrv_Mvt_&exer2._Cvr (in=b);
	if a or b ;
	by Rsrv_typ Legal_Entity Cvr_Typ ;
	&exer2._vs_&exer1.= coalesce(Rsrv_Amt_&exer2.,0) - coalesce(Rsrv_Amt_&exer1.,0);
run;

/*###############################################   New_claims_ICOP  #################################################################
*########################################################################################################################### */

proc sql ; create Table New_Claims_ICOP  as 
Select Distinct Country,
				Date_of_reserving,
				Flag,
				Cvr_Typ,
				Legal_Entity,
				Rsrv_Typ_&exer2.,
				Agent_Name,
				Schm,
				Clm_Nmbr,
				Rgstrtn_Dt,
				Cls_Dt,
				status_&exer2.,
				Totl_Bnfts_Amnt_Pd_&exer2.,
				Mnthly_Bnft_&exer2.,
				Nmbr_Bnfts_Pd_&exer2.,
				Nmbr_Bnfts_Otstndng_&exer2.,
				Rsrv_Amt_&exer2.	
From CLMHDR_ALL_flag as a 
Where Flag = "New Claim" and Rsrv_Typ_&exer2. = "ICOP" 
group by Country, Date_of_reserving, Flag,Rsrv_Typ_&exer2.,Legal_Entity, Cvr_Typ, Agent_Name ;
quit;

/*###############################################   New_claims_RBNP  #################################################################
*########################################################################################################################### */

proc sql ; create Table New_Claims_RBNP  as 
Select Distinct Country,
				Date_of_reserving,
				Flag,
				Cvr_Typ,
				Legal_Entity,
				Rsrv_Typ_&exer2.,
				Agent_Name,
				Schm,
				Clm_Nmbr,
				Rgstrtn_Dt,
				Cls_Dt,
				status_&exer2.,
				Nmbr_Mnths_Pndng_&exer2.,
				Totl_Bnfts_Amnt_Pd_&exer2.,
				Mnthly_Bnft_&exer2.,
				Nmbr_Bnfts_Pd_&exer2.,
				Nmbr_Bnfts_Otstndng_&exer2.,
				Otstndng_Balnc_&exer2.,
				Probablty_Otstndng_&exer2.,
				Rsrv_Amt_&exer2.	
From CLMHDR_ALL_flag as a 
Where Flag = "New Claim" and Rsrv_Typ_&exer2. = "RBNP" 
group by Country, Date_of_reserving, Flag,Rsrv_Typ_&exer2.,Legal_Entity, Cvr_Typ, Agent_Name ;
quit;



/*############################################### Stock_ICOP#################################################### */
/*###############################################################################################################*/


proc sql ; Create table Stock_ICOP_0 as
select Distinct Country,
				Date_of_reserving,
				Flag,
				Clm_Nmbr,
				Rsrv_Typ_&exer2.,
				Legal_Entity,
				Cover,
				Cvr_Typ,
				Agent_Name,
				Schm,
				Clm_Nmbr,
				status_&exer2.,
				cls_Dt,
				Rgstrtn_Dt,
				Totl_Bnfts_Amnt_Pd_&exer2.,
				Mnthly_Bnft_&exer2.,
				Nmbr_Mnths_Pndng_&exer2.,
				Nmbr_Bnfts_Pd_&exer2.,
				Nmbr_Bnfts_Otstndng_&exer2.,
				Rsrv_Amt_&exer2.	
From CLMHDR_ALL_flag
Where Flag = "Stock" And Rsrv_Typ_&exer2. ="ICOP"
Group by Country, Date_of_reserving, flag ,Rsrv_Typ_&exer2., Legal_Entity, Cvr_Typ, Agent_Name, Schm ;
quit ;

Proc sql; Create Table Stock_ICOP As
Select Distinct a.Country ,
				a.Date_of_reserving,
				a.Legal_Entity,
				a.Clm_Nmbr,
				a.cover ,
				a.Cvr_Typ,
				a.Agent_Name,
				a.Schm,
				a.Rsrv_Typ_&exer2. ,
				b.Rsrv_Typ_&exer1. ,
				a.Totl_Bnfts_Amnt_Pd_&exer2.,
				a.Mnthly_Bnft_&exer2.,
				b.Mnthly_Bnft_&exer1.,
				a.Nmbr_Bnfts_Otstndng_&exer2., 
				b.Nmbr_Bnfts_Otstndng_&exer1.,
				a.Rsrv_Amt_&exer2.,
				b.Rsrv_Amt_&exer1.
From Stock_ICOP_0 As a 
left join CLMHDR_ALL_&pays._&exer1.  As b
On (a.Country = b.Country)  and(a.Legal_Entity = b.Legal_Entity)and (a.Agent_Name = b.Agent_Name) and (a.Schm = b.Schm) and (a.Clm_Nmbr = b.Clm_Nmbr)
group by a.Country, a.Date_of_reserving ,a.Rsrv_Typ_&exer2., Legal_Entity,a.Cover , a.Cvr_Typ, a.Agent_Name,a.Schm ;
quit;  


Data Mvt_ICOP;
set Stock_ICOP;
if Rsrv_Typ_&exer1. ="ICOP" then do;
 Amt= sum(Rsrv_Amt_&exer2.) ; Stock_ICOP_&exer2. = "ICOP -->ICOP" ;end;
if  Rsrv_Typ_&exer1. ="RBNP" then do; 
Amt= sum(Rsrv_Amt_&exer2.) ; Stock_ICOP_&exer2. = "RBNP -->ICOP" ;end;
if  Rsrv_Typ_&exer1. ="CLOSE" then do;
 Amt= sum(Rsrv_Amt_&exer2.) ; Stock_ICOP_&exer2. = "CLOSE-->ICOP" ;end;
if Missing (Rsrv_Typ_&exer1 ) then do;
 Amt= sum(Rsrv_Amt_&exer2.)  ; Stock_ICOP_&exer2. = "Empty -->ICOP" ;end;
run ;

proc sql; create table Mvt_ICOP as 
select a.Stock_ICOP_&exer2.,
	   sum(Amt) as Amount
From Mvt_ICOP a
group by Stock_ICOP_&exer2.;
quit;



/*############################################### Stock_RBNP #################################################### */
/*###############################################################################################################*/

proc sql ; Create table Stock_RBNP_0 as
select Distinct Country,
				Date_of_reserving,
				Flag,
				Clm_Nmbr,
				Rsrv_Typ_&exer2.,
				Legal_Entity,
				Cover,
				Cvr_Typ,
				Agent_Name,
				Schm,
				Clm_Nmbr,
				status_&exer2.,
				cls_Dt,
				Rgstrtn_Dt,
				Totl_Bnfts_Amnt_Pd_&exer2.,
				Mnthly_Bnft_&exer2.,
				Nmbr_Mnths_Pndng_&exer2.,
				Nmbr_Bnfts_Pd_&exer2.,
				Nmbr_Bnfts_Otstndng_&exer2.,
				Rsrv_Amt_&exer2.	
From CLMHDR_ALL_flag
Where Flag = "Stock" And Rsrv_Typ_&exer2. ="RBNP"
Group by Country, Date_of_reserving, flag ,Rsrv_Typ_&exer2., Legal_Entity, Cvr_Typ, Agent_Name, Schm ;
quit ;



Proc sql; Create Table Stock_RBNP As
Select Distinct a.Country ,
				a.Date_of_reserving,
				a.Legal_Entity,
				a.Clm_Nmbr,
				a.cover ,
				a.Cvr_Typ,
				a.Agent_Name,
				a.Schm,
				a.Rsrv_Typ_&exer2.,
				b.Rsrv_Typ_&exer1.,
				a.Totl_Bnfts_Amnt_Pd_&exer2.,
				a.Mnthly_Bnft_&exer2.,
				b.Mnthly_Bnft_&exer1.,
				a.Nmbr_Bnfts_Otstndng_&exer2.,
				b.Nmbr_Bnfts_Otstndng_&exer1.,
				a.Rsrv_Amt_&exer2.,
				b.Rsrv_Amt_&exer1.
From Stock_RBNP_0 As a 
left join CLMHDR_ALL_&pays._&exer1.  As b
On (a.Country = b.Country)  and(a.Legal_Entity = b.Legal_Entity)and (a.Agent_Name = b.Agent_Name) and (a.Schm = b.Schm) and (a.Clm_Nmbr = b.Clm_Nmbr)
group by a.Country, a.Date_of_reserving ,a.Rsrv_Typ_&exer2., Legal_Entity,a.Cover , a.Cvr_Typ, a.Agent_Name,a.Schm ;
quit;  

Data Mvt_RBNP;
set Stock_RBNP;
if Rsrv_Typ_&exer1. ="ICOP" then do;
 Amt= sum(Rsrv_Amt_&exer2.) ; Stock_RBNP_&exer2. = "ICOP -->RBNP" ;end;
if  Rsrv_Typ_&exer1. ="RBNP" then do; 
Amt= sum(Rsrv_Amt_&exer2.) ; Stock_RBNP_&exer2. = "RBNP -->RBNP" ;end;
if  Rsrv_Typ_&exer1. ="CLOSE" then do;
 Amt= sum(Rsrv_Amt_&exer2.) ; Stock_RBNP_&exer2. = "CLOSE-->RBNP" ;end;
if Missing (Rsrv_Typ_&exer1 ) then do;
 Amt= sum(Rsrv_Amt_&exer2.)  ; Stock_RBNP_&exer2. = "Empty -->ICOP" ;end;
run ;

proc sql; create table  Mvt_RBNP as 
select a.Stock_RBNP_&exer2.,
	   sum(Amt) as Amount 
From Mvt_RBNP a
group by Stock_RBNP_&exer2.;
quit;
/*################################################### Close Claims_ICOP ###############################################
/*################################################################################################################*/

proc sql; create table Close_Claims_ICOP As
select distinct b.Country ,
				b.Date_of_reserving,
				b.flag,
				a.Legal_Entity,
				a.cover ,
				a.Cvr_Typ,
				a.Agent_Name,
				a.Schm,
				a.Rsrv_Typ_&exer1.,
				b.Rsrv_Typ_&exer2.,
				a.Totl_Bnfts_Amnt_Pd_&exer1.,
				b.Totl_Bnfts_Amnt_Pd_&exer2.,
				a.Mnthly_Bnft_&exer1.,
				b.Mnthly_Bnft_&exer2.,
				a.Nmbr_Bnfts_Otstndng_&exer1.,
				b.Nmbr_Bnfts_Otstndng_&exer2.,
				a.Rsrv_Amt_&exer1.,
				b.Rsrv_Amt_&exer2.,
				a.Clm_Nmbr
from CLMHDR_ALL_&pays._&exer1. a 
left join CLMHDR_ALL_flag b
on (a.Schm = b.Schm) and (a.Legal_Entity = b.Legal_Entity) and (a.Clm_Nmbr = b.Clm_Nmbr) and (a.Cvr_Typ= b.Cvr_Typ)
Where  a.Rsrv_Typ_&exer1.= "ICOP" and b.Rsrv_Typ_&exer2. = "CLOSE"  ;
quit;


/*################################################### Close Claims_RBNP ###############################################
/*################################################################################################################*/


proc sql; create table Close_Claims_RBNP As
select Distinct b.Country ,
				b.Date_of_reserving,
				b.flag,
				a.Legal_Entity,
				a.cover ,
				a.PMP_Sales_Name,
				a.Schm,
				a.Rsrv_Typ_&exer1.,
				b.Rsrv_Typ_&exer2.,
				b.status_&exer2.,
				a.Totl_Bnfts_Amnt_Pd_&exer1.,
				b.Totl_Bnfts_Amnt_Pd_&exer2.,
				a.Mnthly_Bnft_&exer1.,
				b.Mnthly_Bnft_&exer2.,
				a.Nmbr_Bnfts_Otstndng_&exer1.,
				b.Nmbr_Bnfts_Otstndng_&exer2.,
				a.Otstndng_Balnc_&exer1.,
				b.Otstndng_Balnc_&exer2.,
				a.Probablty_Otstndng_&exer1,
				b.Probablty_Otstndng_&exer2,
				a.Rsrv_Amt_&exer1.,
				b.Rsrv_Amt_&exer2.,
				a.Clm_Nmbr
from CLMHDR_ALL_&pays._&exer1. a 
left join CLMHDR_ALL_flag b
on (a.Schm = b.Schm) and (a.Legal_Entity = b.Legal_Entity) and (a.Clm_Nmbr = b.Clm_Nmbr) and (a.Cover = b.cover)
Where  a.Rsrv_Typ_&exer1. = "RBNP"  and b.Rsrv_Typ_&exer2. = "CLOSE"  and b.status_&exer2. in("CL","DC")  ;
quit;

/*######################################### Export ##################################################"*/


%macro EXPORT_EXCEL1(DATABASE=,);
%let Chemin = "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete2./02_Elements_Techniques/TIA/Arrete reel/RESERVES/REPORTING/Controles/CR/Output/Clms_Ctrl_&pays._&exer1._&exer2..xlsx";
PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET = &DATABASE;
run;
%MEND;


%EXPORT_EXCEL1(DATABASE=CLMHDR_ALL_flag);
%EXPORT_EXCEL1(DATABASE=Close_Claims_ICOP);
%EXPORT_EXCEL1(DATABASE=Close_Claims_RBNP);
%EXPORT_EXCEL1(DATABASE=Stock_ICOP);
%EXPORT_EXCEL1(DATABASE=Stock_RBNP);
%EXPORT_EXCEL1(DATABASE=New_Claims_ICOP);
%EXPORT_EXCEL1(DATABASE=New_Claims_RBNP);
%EXPORT_EXCEL1(DATABASE=Rsrv_Mvt_tot);
%EXPORT_EXCEL1(DATABASE=Rsrv_Mvt_flag);
%EXPORT_EXCEL1(DATABASE=Rsrv_Mvt_LE );
%EXPORT_EXCEL1(DATABASE=Rsrv_Mvt_cvr );
%EXPORT_EXCEL1(DATABASE=Mvt_ICOP);
%EXPORT_EXCEL1(DATABASE=Mvt_RBNP);

%MEND;

/* #################################################### Lancement des programmes ###################################################*/

%Rsrv_Mvt(pays=BE,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=CH,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=DE,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=DK,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=ES,exer1=&exer1.,exer2=&exer2.); 
%Rsrv_Mvt(pays=FI,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=FR,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=GR,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=IE,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=IT,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=MX,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=NI,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=NL,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=NO,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=PT,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=SE,exer1=&exer1.,exer2=&exer2.);

*%Rsrv_Mvt(pays=SK,exer1=&exer1.,exer2=&exer2.);

%Rsrv_Mvt(pays=TR,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=UK,exer1=&exer1.,exer2=&exer2.);
%Rsrv_Mvt(pays=CO,exer1=&exer1.,exer2=&exer2.);




