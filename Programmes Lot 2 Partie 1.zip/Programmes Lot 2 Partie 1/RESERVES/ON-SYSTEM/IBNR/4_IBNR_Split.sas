%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete = 2026_06_Prov ;

LIBNAME input "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Input";
LIBNAME CR_Q226 "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";


%LET Balancedate = '26/06/2026';
%LET Balancequarter = Q22026;
%LET quarter = 2026Q2;
%let Ouput=CR_Q226;
%let month=06;
%let day=26;
%let yr=2026;


%Macro Dataprep(Balancedate);

*M3: 1 Set up Year-month grid;

DATA YRMNTH_GRID;

	do i = 0 to 95;
	YR = year(intnx('month',input(&Balancedate.,ddmmyy10.),-i));
	MNTH = month(intnx('month',input(&Balancedate.,ddmmyy10.),-i));
	output;
	end;
	drop i;
RUN;
DATA DEVMONTH;

	do i = 1 to 60;
	DEVMONTH = i;
	output;
	end;
	drop i;
RUN;

PROC SQL;
	CREATE TABLE YRMNTHDEV as
	SELECT DISTINCT YR, MNTH, DEVMONTH
	FROM YRMNTH_GRID, DEVMONTH;
QUIT;

%Mend;

%Dataprep(&Balancedate.);

%MACRO IBNR_SPLIT(c=,Rsrv_Typ=,);


*DOWNLOAD Development factor and IBNR data FROM EXCEL;
/*%let C=FR;*/
/*%let Rsrv_Typ=GD1;*/
%let Chemin = "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/IBNR/Outputs/&quarter./&C./IBNR - &C. &Rsrv_Typ..xlsx";


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
range = "A6:C66";
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Chemin.,OUT=IBNR_DVLPMNT_FCTRS,ONGLET=RUNOFF);

%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
range = "A6:D102";
RUN;
%MEND;


%IMPORT_EXCEL(FILE=&Chemin.,OUT=IBNR_RSRV_BY_YRMNTH,ONGLET=IBNRRES);



*M7: ALLOCATE IBNR BETWEEN SUB-GROUPS;
*M7: IBNR 1 Calculate Claims Incurred to date for each Ibnr sub-group;
*Q DEFINE ROLLING YR 0;
*Filter to remove claims with null underwriting code added by DP 24/7/2012;

PROC SQL;
		CREATE TABLE DEFINE_ROLLING_YR_0 as 
		SELECT UNIQUE Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ
		FROM &Ouput..CLMHDR_ALL_&c. 
		WHERE Rsrv_Grp="&Rsrv_Typ."  and Undrwrtng_Cmpny is not null and LEGACY_SCHEME_BOOK="TIA"
		GROUP BY Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ
		;
QUIT;

*What is the Roll_yr!?? Does that make any sense!?;

PROC SQL;
	CREATE TABLE DEFINE_ROLLING_YR as
	SELECT DISTINCT Rsrv_Grp, Yr as Acc_Yr, Mnth as Acc_Mnth, Schm, Undrwrtng_Cmpny, Cvr_Typ,
	year(input(&Balancedate.,ddmmyy10.))*12+month(input(&Balancedate.,ddmmyy10.))-Yr*12-Mnth+1 as Dev_Mnth,
	case when Mnth<=Month(input(&Balancedate.,ddmmyy10.)) then Yr else Yr+1 end as Roll_Yr
	FROM YRMNTH_GRID, DEFINE_ROLLING_YR_0;
QUIT;

*Q MAKE CLMNS INCRD BY SUB GRP

*NEED TO PUT WHERE UNDERWRITING COMPANY IS NOT NULL IN HERE??;

DATA CLMHDR_ALL_&c._&Rsrv_Typ.;
set &Ouput..CLMHDR_ALL_&c.;
where Rsrv_Grp="&Rsrv_Typ." and LEGACY_SCHEME_BOOK="TIA";
run;


PROC SQL;
	CREATE TABLE CLMNS_INCRD_BY_SUB_GRP as
	SELECT DISTINCT d.Rsrv_Grp, d.Acc_Yr, d.Acc_Mnth, d.Dev_Mnth, d.Roll_Yr, d.Schm, d.Undrwrtng_Cmpny, d.Cvr_Typ,
	sum(case when Totl_Amnt_Pd+Rsrv_Amt Is Null then 0 else Totl_Amnt_Pd+Rsrv_Amt end) as Clms_Incrd
	FROM CLMHDR_ALL_&c._&Rsrv_Typ. h
	RIGHT JOIN DEFINE_ROLLING_YR d ON (h.Rsrv_Grp = d.Rsrv_Grp
	and h.Acc_Yr = d.Acc_Yr
	and h.Acc_Mnth = d.Acc_Mnth
	and h.Schm = d.Schm
	and h.Undrwrtng_Cmpny = d.Undrwrtng_Cmpny
	and h.Cvr_Typ = d.Cvr_Typ)
	GROUP BY d.Rsrv_Grp, d.Acc_Yr, d.Acc_Mnth, d.Dev_Mnth, d.Roll_Yr, d.Schm, d.Undrwrtng_Cmpny, d.Cvr_Typ;
QUIT;

*M7: IBNR 2 Calculate IBNR  for each Ibnr sub-group;

*Q CHN LDDR IBNR BY SUB GRP;

PROC SQL;
	CREATE TABLE CHN_LDDR_IBNR_BY_SUB_GRP as
	SELECT DISTINCT c.Rsrv_Grp, c.Acc_Yr, c.Acc_Mnth, c.Schm, c.Undrwrtng_Cmpny, c.Cvr_Typ, c.Clms_Incrd, c.Dev_Mnth,
	c.Roll_Yr, i.Cum_Per_Rgstrd,
	case when i.Cum_Per_Rgstrd = .  then 0 else case when i.Cum_Per_Rgstrd<0.33 then 0 
	else (c.Clms_Incrd/i.Cum_Per_Rgstrd)*(1-i.Cum_Per_Rgstrd) end end as CLIbnr_SubGrp
	FROM CLMNS_INCRD_BY_SUB_GRP c
	LEFT JOIN IBNR_DVLPMNT_FCTRS i ON (c.Dev_Mnth = i.Dev_Mnth);
QUIT;

*Q CHN LDDER IBNR TOT;

PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_tot as
	SELECT Rsrv_Grp, sum(CLIbnr_SubGrp) as CLIbnr
	FROM Chn_lddr_ibnr_by_sub_grp
	WHERE Roll_Yr = Year(input(&Balancedate.,ddmmyy10.))
	GROUP BY Rsrv_Grp;
QUIT;
*Q CHN LDDER IBNR TOT 2 ROLLING YEARS;
PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_tot_nry as
	SELECT Rsrv_Grp, sum(CLIbnr_SubGrp) as CLIbnr_nry
	FROM Chn_lddr_ibnr_by_sub_grp
	WHERE Roll_Yr = Year(input(&Balancedate.,ddmmyy10.)) or Roll_Yr = (Year(input(&Balancedate.,ddmmyy10.))-1)
	GROUP BY Rsrv_Grp;
QUIT;

*Q CHN LDDR SUB GRP TOT;

PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_sub_grp_tot as
	SELECT Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ, sum(CLIbnr_SubGrp) as CLIbnr_SubGrp_Tot
	FROM Chn_lddr_ibnr_by_sub_grp
	WHERE Roll_Yr = Year(input(&Balancedate.,ddmmyy10.))
	GROUP BY Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ;
QUIT;

*Q CHN LDDR SUB GRP TOT 2 ROLLING YEARS;

PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_sub_grp_tot_nry as
	SELECT Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ, sum(CLIbnr_SubGrp) as CLIbnr_SubGrp_Tot_nry
	FROM Chn_lddr_ibnr_by_sub_grp
	WHERE Roll_Yr = Year(input(&Balancedate.,ddmmyy10.)) or Roll_Yr = (Year(input(&Balancedate.,ddmmyy10.))-1)
	GROUP BY Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ;
QUIT;

*Q CHN LDDR IBNR YRMNTH;
PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_yrmnth as
	SELECT Rsrv_Grp, Acc_Yr, Acc_Mnth, sum(CLIbnr_SubGrp) as CLIbnr_YrMnth
	FROM Chn_lddr_ibnr_by_sub_grp
	GROUP BY Rsrv_Grp, Acc_Yr, Acc_Mnth;
QUIT;


*DO THE IBNR BY POLYR SPLIT;

PROC SQL;
		CREATE TABLE CLMHDRwithPolYr as 
		SELECT *, Year(Incptn_Dt) as PolYr
		FROM &Ouput..CLMHDR_ALL_&c.
		where Rsrv_Grp="&Rsrv_Typ." and LEGACY_SCHEME_BOOK="TIA"
		;
QUIT;
PROC SQL;
		CREATE TABLE PolYrs as 
		SELECT DISTINCT Year(Incptn_Dt) as PolYr
		FROM &Ouput..CLMHDR_ALL_&c.
		where Rsrv_Grp="&Rsrv_Typ." and LEGACY_SCHEME_BOOK="TIA"
		ORDER BY PolYr
		;
QUIT;

PROC SQL;
		CREATE TABLE DEFINE_ROLLING_YR_0 as 
		SELECT DISTINCT Country,Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ
		FROM CLMHDRwithPolYr
		ORDER BY Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ
		;
QUIT;

PROC SQL;
	CREATE TABLE DEFINE_ROLLING_YR as
	SELECT DISTINCT Country,Rsrv_Grp, Yr as Acc_Yr, Mnth as Acc_Mnth, PolYr,
	Schm, Undrwrtng_Cmpny,Cvr_Typ,
	year(input(&Balancedate.,ddmmyy10.))*12+month(input(&Balancedate.,ddmmyy10.))-Yr*12-Mnth+1 as Dev_Mnth,
	case when Mnth<=Month(input(&Balancedate.,ddmmyy10.)) then Yr else Yr+1 end as Roll_Yr
	FROM YRMNTH_GRID, DEFINE_ROLLING_YR_0, PolYrs
	;
QUIT;

PROC SQL;
	CREATE TABLE CLMNS_INCRD_BY_SUB_GRP as
	SELECT DISTINCT d.Country,d.Rsrv_Grp, d.Acc_Yr, d.Acc_Mnth, d.Dev_Mnth, d.Roll_Yr, d.Schm, d.Undrwrtng_Cmpny, d.Cvr_Typ, d.PolYr,
	sum(case when Totl_Amnt_Pd+Rsrv_Amt Is Null then 0 else Totl_Amnt_Pd+Rsrv_Amt end) as Clms_Incrd
	FROM ClmhdrwithPolYr h
	RIGHT JOIN DEFINE_ROLLING_YR d ON (h.Rsrv_Grp = d.Rsrv_Grp
	and h.Acc_Yr = d.Acc_Yr
	and h.Acc_Mnth = d.Acc_Mnth
	and h.Schm = d.Schm
	and h.Undrwrtng_Cmpny = d.Undrwrtng_Cmpny
	and h.Cvr_Typ = d.Cvr_Typ
	and h.PolYr = d.PolYr)
	GROUP BY d.Rsrv_Grp, d.Acc_Yr, d.Acc_Mnth, d.Dev_Mnth, d.Roll_Yr, d.Schm, d.Undrwrtng_Cmpny, d.Cvr_Typ, d.PolYr;
QUIT;
PROC SQL;
	CREATE TABLE CHN_LDDR_IBNR_BY_SUB_GRP as
	SELECT DISTINCT c.Country,c.Rsrv_Grp, c.Acc_Yr, c.Acc_Mnth, c.Schm, c.Undrwrtng_Cmpny, c.Cvr_Typ, c.Clms_Incrd, c.Dev_Mnth,
	c.Roll_Yr, c.PolYr ,i.Cum_Per_Rgstrd,
	case when i.Cum_Per_Rgstrd = .  then 0 else case when i.Cum_Per_Rgstrd<0.33 then 0 
	else (c.Clms_Incrd/i.Cum_Per_Rgstrd)*(1-i.Cum_Per_Rgstrd) end end as CLIbnr_SubGrp
	FROM CLMNS_INCRD_BY_SUB_GRP c
	LEFT JOIN IBNR_DVLPMNT_FCTRS i ON (c.Dev_Mnth = i.Dev_Mnth);
QUIT;
PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_sub_grp_tot as
	SELECT Country,Rsrv_Grp, Schm, PolYr, Undrwrtng_Cmpny, Cvr_Typ, sum(CLIbnr_SubGrp) as CLIbnr_SubGrp_Tot
	FROM Chn_lddr_ibnr_by_sub_grp
	WHERE Roll_Yr = Year(input(&Balancedate.,ddmmyy10.))
	GROUP BY Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ, PolYr;
QUIT;

*Q CHN LDDR SUB GRP TOT 2 ROLLING YEARS;
PROC SQL;
	CREATE TABLE Chn_lddr_ibnr_sub_grp_tot_nry as
	SELECT Country,Rsrv_Grp, Schm, PolYr, Undrwrtng_Cmpny, Cvr_Typ, sum(CLIbnr_SubGrp) as CLIbnr_SubGrp_Tot_nry
	FROM Chn_lddr_ibnr_by_sub_grp
	WHERE Roll_Yr = Year(input(&Balancedate.,ddmmyy10.)) or Roll_Yr = (Year(input(&Balancedate.,ddmmyy10.))-1)
	GROUP BY Rsrv_Grp, Schm, Undrwrtng_Cmpny, Cvr_Typ, PolYr;
QUIT;



Data IBNR_BY_SUB_GRP_&Rsrv_Typ._PolYrs_&c._1 (drop = rc rc2 rc3 rc4 rc5 rc6 );
If _n_ = 1 then do;/* obligatorie */
      IF 0 then set Ibnr_rsrv_by_yrmnth(keep = Rsrv_Grp Acc_Yr Acc_Mnth Ibnr_YrMnth ); /* Obligatoire aussi : j'ai mis "keep" ici pour que tu n'oublis pas de le mettre toi aussi */
      DCL HASH chek (dataset: 'Ibnr_rsrv_by_yrmnth(keep = Rsrv_Grp Acc_Yr Acc_Mnth Ibnr_YrMnth)') ; /* On demande � sas de monter en RAM la table qui servira � faire le rechercheV, ne pas oublier le m�me KEEP */
      chek.definekey ('Rsrv_Grp', 'Acc_Yr', 'Acc_Mnth'  );/* les cl�s de r�union, entre quote, s�par�es par des virgules*/
      chek.definedata ('Ibnr_YrMnth'); /* Les donn�es � retourner. On peut en mettre plusieurs !! Entre quote et s�par�es par des virgules */
      chek.definedone();/* obligatoire*/
End;

If _n_ = 1 then do;/* obligatorie */
      IF 0 then set Chn_lddr_ibnr_tot(keep = Rsrv_Grp CLIbnr); /* Obligatoire aussi : j'ai mis "keep" ici pour que tu n'oublis pas de le mettre toi aussi */
      DCL HASH test  (dataset: 'Chn_lddr_ibnr_tot(keep = Rsrv_Grp CLIbnr)'); /* On demande � sas de monter en RAM la table qui servira � faire le rechercheV, ne pas oublier le m�me KEEP */
      test.definekey ('Rsrv_Grp');/* les cl�s de r�union, entre quote, s�par�es par des virgules*/
      test.definedata ('CLIbnr'); /* Les donn�es � retourner. On peut en mettre plusieurs !! Entre quote et s�par�es par des virgules */
      test.definedone();/* obligatoire*/
End;

If _n_ = 1 then do;/* obligatorie */
      IF 0 then set Chn_lddr_ibnr_sub_grp_tot(keep = Rsrv_Grp Schm Undrwrtng_Cmpny Cvr_Typ PolYr CLIbnr_SubGrp_Tot); /* Obligatoire aussi : j'ai mis "keep" ici pour que tu n'oublis pas de le mettre toi aussi */
      DCL HASH test1  (dataset: 'Chn_lddr_ibnr_sub_grp_tot(keep = Rsrv_Grp Schm Undrwrtng_Cmpny Cvr_Typ PolYr CLIbnr_SubGrp_Tot)'); /* On demande � sas de monter en RAM la table qui servira � faire le rechercheV, ne pas oublier le m�me KEEP */
      test1.definekey ('Rsrv_Grp', 'Schm', 'Undrwrtng_Cmpny', 'Cvr_Typ', 'PolYr');/* les cl�s de r�union, entre quote, s�par�es par des virgules*/
      test1.definedata ('CLIbnr_SubGrp_Tot'); /* Les donn�es � retourner. On peut en mettre plusieurs !! Entre quote et s�par�es par des virgules */
      test1.definedone();/* obligatoire*/
End;

If _n_ = 1 then do;/* obligatorie */
      IF 0 then set Chn_lddr_ibnr_yrmnth(keep = Rsrv_Grp Acc_Yr Acc_Mnth CLIbnr_YrMnth); /* Obligatoire aussi : j'ai mis "keep" ici pour que tu n'oublis pas de le mettre toi aussi */
      DCL HASH test2  (dataset: 'Chn_lddr_ibnr_yrmnth(keep = Rsrv_Grp Acc_Yr Acc_Mnth CLIbnr_YrMnth)'); /* On demande � sas de monter en RAM la table qui servira � faire le rechercheV, ne pas oublier le m�me KEEP */
      test2.definekey ('Rsrv_Grp', 'Acc_Yr', 'Acc_Mnth');/* les cl�s de r�union, entre quote, s�par�es par des virgules*/
      test2.definedata ('CLIbnr_YrMnth'); /* Les donn�es � retourner. On peut en mettre plusieurs !! Entre quote et s�par�es par des virgules */
      test2.definedone();/* obligatoire*/
End;


If _n_ = 1 then do;/* obligatorie */
      IF 0 then set Chn_lddr_ibnr_tot_nry(keep = Rsrv_Grp CLIbnr_nry); /* Obligatoire aussi : j'ai mis "keep" ici pour que tu n'oublis pas de le mettre toi aussi */
      DCL HASH test3  (dataset: 'Chn_lddr_ibnr_tot_nry(keep = Rsrv_Grp CLIbnr_nry)'); /* On demande � sas de monter en RAM la table qui servira � faire le rechercheV, ne pas oublier le m�me KEEP */
      test3.definekey ('Rsrv_Grp');/* les cl�s de r�union, entre quote, s�par�es par des virgules*/
      test3.definedata ('CLIbnr_nry'); /* Les donn�es � retourner. On peut en mettre plusieurs !! Entre quote et s�par�es par des virgules */
      test3.definedone();/* obligatoire*/
End;


If _n_ = 1 then do;/* obligatorie */
      IF 0 then set Chn_lddr_ibnr_sub_grp_tot_nry(keep = Rsrv_Grp Schm Undrwrtng_Cmpny Cvr_Typ PolYr CLIbnr_SubGrp_Tot_nry); /* Obligatoire aussi : j'ai mis "keep" ici pour que tu n'oublis pas de le mettre toi aussi */
      DCL HASH test4  (dataset: 'Chn_lddr_ibnr_sub_grp_tot_nry(keep = Rsrv_Grp Schm Undrwrtng_Cmpny Cvr_Typ PolYr CLIbnr_SubGrp_Tot_nry)'); /* On demande � sas de monter en RAM la table qui servira � faire le rechercheV, ne pas oublier le m�me KEEP */
      test4.definekey ('Rsrv_Grp' ,'Schm', 'Undrwrtng_Cmpny', 'Cvr_Typ', 'PolYr');/* les cl�s de r�union, entre quote, s�par�es par des virgules*/
      test4.definedata ('CLIbnr_SubGrp_Tot_nry'); /* Les donn�es � retourner. On peut en mettre plusieurs !! Entre quote et s�par�es par des virgules */
      test4.definedone();/* obligatoire*/
End;


Set CHN_LDDR_IBNR_BY_SUB_GRP; /* Table de travail*/
rc = chek.find(); /* On demande d'aller rechercher les infos dans notre table de Hashing */
rc2 = test.find(); /* On demande d'aller rechercher les infos dans notre table de Hashing */
rc3 = test1.find(); /* On demande d'aller rechercher les infos dans notre table de Hashing */
rc4 = test2.find(); /* On demande d'aller rechercher les infos dans notre table de Hashing */
rc5 = test3.find(); /* On demande d'aller rechercher les infos dans notre table de Hashing */
rc6 = test4.find(); /* On demande d'aller rechercher les infos dans notre table de Hashing */

Run; 
 
 
 
 PROC SQL;
	CREATE TABLE IBNR_BY_SUB_GRP_&Rsrv_Typ._PolYrs_&c. as
	SELECT DISTINCT Country, Rsrv_Grp, Schm, PolYr, Undrwrtng_Cmpny, Cvr_Typ, CLIbnr_SubGrp_Tot, Acc_Yr, Acc_Mnth, Dev_Mnth ,Roll_Yr,CLIbnr, Cum_Per_Rgstrd, CLIbnr_SubGrp, CLIbnr_YrMnth,CLIbnr_SubGrp_Tot_nry, CLIbnr_nry, Ibnr_YrMnth,
	case 
	when CLIbnr_YrMnth <> 0 then (CLIbnr_SubGrp/CLIbnr_YrMnth)*Ibnr_YrMnth else case 
	when CLIbnr <> 0 then (CLIbnr_SubGrp_Tot/CLIbnr)*Ibnr_YrMnth 
	else (CLIbnr_SubGrp_Tot_nry/CLIbnr_nry)*Ibnr_YrMnth 
	end end as Ibnr_SubGrp
	FROM IBNR_BY_SUB_GRP_&Rsrv_Typ._PolYrs_&c._1 
	WHERE case
	when CLIbnr_YrMnth <> 0 then (CLIbnr_SubGrp/CLIbnr_YrMnth)*Ibnr_YrMnth else  case
	when CLIbnr <> 0 then (CLIbnr_SubGrp_Tot/CLIbnr)*Ibnr_YrMnth 
	else (CLIbnr_SubGrp_Tot_nry/CLIbnr_nry)*Ibnr_YrMnth 
	end end >= 0.01;
QUIT;
 
 
%MEND;

%MACRO IBNR_FUSION_FR(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GD2_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GD3_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR2_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR3_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL2_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GP1_PolYrs_&pays.
   
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;


%MEND;



%MACRO IBNR_FUSION_1(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;

set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GC1_PolYrs_&pays.
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;


%MEND;

%MACRO IBNR_FUSION_2(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
 
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;


%MEND;

%MACRO IBNR_FUSION_3(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;
 
 %MEND;

%MACRO IBNR_FUSION_5(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GC1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;


%MEND;


%MACRO IBNR_FUSION_4(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GC1_PolYrs_&pays.
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;

%MEND;

%MACRO IBNR_FUSION_DE(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GP1_PolYrs_&pays.
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;

%MEND;

%MACRO IBNR_FUSION_0(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GP1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GC1_PolYrs_&pays.
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;

%MEND;

%MACRO IBNR_FUSION_AT(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GP1_PolYrs_&pays.
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;


%MEND;
%MACRO IBNR_FUSION_BE(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GL1_PolYrs_&pays.
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;

%MEND;

%MACRO IBNR_FUSION_MX(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GP1_PolYrs_&pays.
    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;

%MEND;

%MACRO IBNR_FUSION_CO(pays=,);

data &Ouput..&pays._IBNR_PolYrsplit_all ;
set IBNR_BY_SUB_GRP_GD1_PolYrs_&pays.
    IBNR_BY_SUB_GRP_GR1_PolYrs_&pays.

    
;
rename 
Cvr_Typ=Cover
PolYr=Vintage_year
Schm=Scheme
Ibnr_SubGrp=Rsrv_Amt
Undrwrtng_Cmpny=Entity_CD

;
Date_of_reserving="&Balancequarter.";
Rsrv_Typ="IBNR";
Type_Insurance=0;

if Acc_Mnth in (1,2,3)    THEN Incident_Quarter=cats(Acc_Yr,"Q1");
if Acc_Mnth in (4,5,6)    THEN Incident_Quarter=cats(Acc_Yr,"Q2");
if Acc_Mnth in (7,8,9)    THEN Incident_Quarter=cats(Acc_Yr,"Q3");
if Acc_Mnth in (10,11,12) THEN Incident_Quarter=cats(Acc_Yr,"Q4");

run;

PROC SQL;
      create table &Ouput..IBNR_&pays. as
             SELECT country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    Rsrv_Amt as Rsrv_Amt 
                                                         
     FROM    &Ouput..&pays._IBNR_PolYrsplit_all
     
      ; 
 quit;

%MEND;

 
/*POLAND*/        
%IBNR_SPLIT(c=PL,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=PL,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=PL,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=PL,Rsrv_Typ=GC1) ;
%IBNR_SPLIT(c=PL,Rsrv_Typ=GP1) ;
%IBNR_FUSION_0(pays=PL) ;

/*ITALY*/    
%IBNR_SPLIT(c=IT,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=IT,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=IT,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=IT,Rsrv_Typ=GC1) ;
%IBNR_SPLIT(c=IT,Rsrv_Typ=GP1) ;
%IBNR_FUSION_0(pays=IT) ;

/*DENMARK*/       
%IBNR_SPLIT(c=DK,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=DK,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=DK,Rsrv_Typ=GL1) ;
%IBNR_FUSION_2(pays=DK) ;

/*GERMANY*/      
%IBNR_SPLIT(c=DE,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=DE,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=DE,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=DE,Rsrv_Typ=GP1) ;
%IBNR_FUSION_DE(pays=DE) ;

/*IRELAND*/       
%IBNR_SPLIT(c=IE,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=IE,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=IE,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=IE,Rsrv_Typ=GC1) ;
%IBNR_FUSION_1(pays=IE) ;

/*NETHERLAND*/        
%IBNR_SPLIT(c=NL,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=NL,Rsrv_Typ=GR1) ;
%IBNR_FUSION_3(pays=NL) ;

/*GREECE*/       
%IBNR_SPLIT(c=GR,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=GR,Rsrv_Typ=GR1) ;
/*%IBNR_SPLIT(c=GR,Rsrv_Typ=GL1) ;*/
%IBNR_FUSION_3(pays=GR) ;

/*****Traitement sp�cial pour la gr�ce*********/

data &Ouput..IBNR_GR;
    set &Ouput..IBNR_GR;
    if Country = "GR" and Scheme in ("BP3.3", "BP3.4", "BP5.3", "BP5.4", "BP7.3", "BP7.4") then Rsrv_Amt = 0;
run;

data &Ouput..GR_IBNR_POLYRSPLIT_ALL;
    set &Ouput..GR_IBNR_POLYRSPLIT_ALL;
    if Country = "GR" and Scheme in ("BP3.3", "BP3.4", "BP5.3", "BP5.4", "BP7.3", "BP7.4") then Rsrv_Amt = 0;
run;

/*****Fin traitement sp�cial pour la gr�ce*********/

/*PORTUGAL*/        
%IBNR_SPLIT(c=PT,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=PT,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=PT,Rsrv_Typ=GL1) ;
%IBNR_FUSION_2(pays=PT) ;

/*SWEDEN*/        
%IBNR_SPLIT(c=SE,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=SE,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=SE,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=SE,Rsrv_Typ=GC1) ;
%IBNR_FUSION_1(pays=SE) ;

/*FINLAND*/  
%IBNR_SPLIT(c=FI,Rsrv_Typ=GC1) ;     
%IBNR_SPLIT(c=FI,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=FI,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=FI,Rsrv_Typ=GL1) ;
%IBNR_FUSION_1(pays=FI) ;

 /*FRANCE*/       
%IBNR_SPLIT(c=FR,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GD2) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GD3) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GR2) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GR3) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GL2) ;
%IBNR_SPLIT(c=FR,Rsrv_Typ=GP1) ;
%IBNR_FUSION_FR(pays=FR) ;

 /*NORWAY*/        
%IBNR_SPLIT(c=NO,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=NO,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=NO,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=NO,Rsrv_Typ=GC1) ;
%IBNR_FUSION_1(pays=NO) ;

/*TURKEY*/        
%IBNR_SPLIT(c=TR,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=TR,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=TR,Rsrv_Typ=GL1) ;
%IBNR_FUSION_2(pays=TR) ;

/*SPAIN*/   
%IBNR_SPLIT(c=ES,Rsrv_Typ=GC1) ;      
%IBNR_SPLIT(c=ES,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=ES,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=ES,Rsrv_Typ=GL1) ;
%IBNR_FUSION_1(pays=ES) ;

/*SWITERLAND*/        
%IBNR_SPLIT(c=CH,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=CH,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=CH,Rsrv_Typ=GC1) ;
%IBNR_FUSION_4(pays=CH) ;

/*UK*/        
%IBNR_SPLIT(c=UK,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=UK,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=UK,Rsrv_Typ=GL1) ;
%IBNR_FUSION_2(pays=UK) ;

/*COLOMBIA*/      
%IBNR_SPLIT(c=CO,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=CO,Rsrv_Typ=GR1) ;
%IBNR_FUSION_CO(pays=CO) ;

/*AUSTRIA*/      
%IBNR_SPLIT(c=AT,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=AT,Rsrv_Typ=GL1) ;
%IBNR_SPLIT(c=AT,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=AT,Rsrv_Typ=GP1) ;
%IBNR_FUSION_AT(pays=AT) ;

/*MEXICO */
%IBNR_SPLIT(c=MX,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=MX,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=MX,Rsrv_Typ=GP1) ;
%IBNR_FUSION_MX(pays=MX) ;

/*BELGIUM */
%IBNR_SPLIT(c=BE,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=BE,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=BE,Rsrv_Typ=GL1) ;
%IBNR_FUSION_BE(pays=BE) ;
 
/* NORTHEN IRELAND */       
/*%IBNR_SPLIT(c=NI,Rsrv_Typ=GD1) ;
%IBNR_SPLIT(c=NI,Rsrv_Typ=GR1) ;
%IBNR_SPLIT(c=NI,Rsrv_Typ=GL1) ;
%IBNR_FUSION_2(pays=NI) ;*/



DATA &Ouput..wps_daap_IBNR_POLYRSPLIT_ALL;
set &Ouput..PT_IBNR_POLYRSPLIT_ALL
	&Ouput..DE_IBNR_POLYRSPLIT_ALL
    &Ouput..DK_IBNR_POLYRSPLIT_ALL
    &Ouput..FR_IBNR_POLYRSPLIT_ALL
    &Ouput..GR_IBNR_POLYRSPLIT_ALL
    &Ouput..IE_IBNR_POLYRSPLIT_ALL
    &Ouput..NL_IBNR_POLYRSPLIT_ALL
    &Ouput..NO_IBNR_POLYRSPLIT_ALL
    &Ouput..PL_IBNR_POLYRSPLIT_ALL
    &Ouput..SE_IBNR_POLYRSPLIT_ALL
    &Ouput..TR_IBNR_POLYRSPLIT_ALL
    &Ouput..CH_IBNR_POLYRSPLIT_ALL
    &Ouput..ES_IBNR_POLYRSPLIT_ALL
    &Ouput..FI_IBNR_POLYRSPLIT_ALL
    &Ouput..IT_IBNR_POLYRSPLIT_ALL
    &Ouput..UK_IBNR_POLYRSPLIT_ALL
    &Ouput..CO_IBNR_POLYRSPLIT_ALL
    &Ouput..AT_IBNR_POLYRSPLIT_ALL
    &Ouput..MX_IBNR_POLYRSPLIT_ALL
    &Ouput..BE_IBNR_POLYRSPLIT_ALL
;
run;


DATA &Ouput..wps_daap_ibnr_&yr.&month.&day._G;
set &Ouput..IBNR_PT
	&Ouput..IBNR_DE
    &Ouput..IBNR_DK
    &Ouput..IBNR_FR
    &Ouput..IBNR_GR
    &Ouput..IBNR_IE
    &Ouput..IBNR_NL
    &Ouput..IBNR_NO
    &Ouput..IBNR_PL
    &Ouput..IBNR_SE
    &Ouput..IBNR_TR
    &Ouput..IBNR_CH
    &Ouput..IBNR_ES
    &Ouput..IBNR_FI 
    &Ouput..IBNR_IT 
    &Ouput..IBNR_UK 
    &Ouput..IBNR_CO 
    &Ouput..IBNR_AT   
    &Ouput..IBNR_MX
    &Ouput..IBNR_BE
;   
run;


/*#################################################################################################################################################################################
/*######################################################   CALCUL DU NET INSURANCE : CASE RESERVES & IBNR    #####################################################
/*################################################################################################################################################################################ */

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Reassurance.xlsx";


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE 
;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=Parametres_Reas,ONGLET=Parametres_Reas);

data Parametres_Reas; 
set Parametres_Reas;
y_char = compress(put(Original_underwritter,21.0));
drop Original_underwritter; rename y_char = Original_underwritter;
run;

data WPS_DAAP_IBNR_&yr.&month.&day. ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day._G ;
Undrwrtng_Cmpny=Entity_CD*1;
run;

proc sql ; 
create table WPS_DAAP_IBNR_&yr.&month.&day. as
select 
t1.*,
t8.QP_rei_CLAIM AS QP_rei_CLAIM 
from WPS_DAAP_IBNR_&yr.&month.&day.  t1 
left join Parametres_Reas t8 on (t1.country=t8.country AND t1.scheme=t8.scheme AND t1.cover=t8.cover AND t1.Entity_CD=t8.Original_underwritter) 
 ;
quit ; 


data WPS_DAAP_IBNR_&yr.&month.&day.;
set WPS_DAAP_IBNR_&yr.&month.&day. ;
if QP_rei_CLAIM=. then Type_Insurance=0 ;
if QP_rei_CLAIM NOT IN (.) then Type_Insurance=4 ;
rename Rsrv_Amt=Rsrv_Amt_Gross ;
if Type_Insurance=0 then QP_rei_CLAIM=1; 

run;


data WPS_DAAP_IBNR_&yr.&month.&day.;
keep country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
set WPS_DAAP_IBNR_&yr.&month.&day.;
Rsrv_Amt_Net= Rsrv_Amt_Gross*QP_rei_CLAIM;
run;

proc sql ; 
create table WPS_DAAP_IBNR_&yr.&month.&day. as
select DISTINCT
t1.*,
t8.Entity AS Entity 
from WPS_DAAP_IBNR_&yr.&month.&day.  t1 
left join &Ouput..WPS_DAAP_CASE_RESERVES_&yr.&month.&day. t8 on (t1.country=t8.country AND t1.scheme=t8.scheme AND t1.cover=t8.cover AND t1.Entity_CD=t8.Entity_CD) 
 ;
quit ; 


data WPS_DAAP_IBNR_&yr.&month.&day.;
Retain country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
keep country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
set WPS_DAAP_IBNR_&yr.&month.&day.;
run;

PROC SQL;
      create table &Ouput..WPS_DAAP_IBNR_&yr.&month.&day. as
             SELECT distinct country,
                    Rsrv_Grp,
                    Scheme,
                    Type_Insurance,
                    cover,
                    Entity_CD,
                    Entity,
                    Incident_Quarter,
                    Vintage_year,
                    Date_of_reserving,
                    Rsrv_Typ,
                    sum(Rsrv_Amt_Gross) as Rsrv_Amt_Gross,
                    sum(Rsrv_Amt_Net) as Rsrv_Amt_Net                                       
     FROM    WPS_DAAP_IBNR_&yr.&month.&day.
     group by country, Rsrv_Grp,Scheme,Type_Insurance, cover,Entity_CD,Entity,Incident_Quarter,Vintage_year,Date_of_reserving, Rsrv_Typ
      ; 
 quit;

data &Ouput..WPS_DAAP_IBNR_&yr.&month.&day. ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.  ;
if Entity="UNKNOWN" and Cover in ("LL","LR") then Entity="FACL" ;
if Entity="UNKNOWN" and Cover in ("RU","RR") then Entity="FICL" ;
if Entity_CD="" and Cover in ("LL","LR") then Entity_CD="102" ;
if Entity_CD="" and Cover in ("RU","RR") then Entity_CD="101" ;
if Entity="UNKNOWN" and Entity_CD="792" then Entity="FACL" ;
if Entity="UNKNOWN" and Entity_CD="801" then Entity="FICL" ;
run ;



