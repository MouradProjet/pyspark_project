
/*The libname input below is infact the output location*/
/*Experience analysis is from previous quarter*/

%let LReseau = X ; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete = 2026_06_Prov ;
%LET quarter = 2026Q2 ;

LIBNAME Out_GEP "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/GEP/Output/DAAP" ;

%Let YM_SUP=202606 ;
%Let YM_INF=202403 ;


/*####################################################   REP DATA  ######################################################################################### */

%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx" ;    
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=flag_legacy,ONGLET="flag_legacy");


%macro REP(CC=,Grp_Rsrv=,);
/*%let CC=FR ; %let Grp_Rsrv=GD2;*/

proc sql ; 
create table HISTO_FLUX_&CC. as
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao as Flag_Macao  
from OUT_GEP.HISTO_FLUX_&CC.  t1 
left join FLAG_LEGACY t8 on (t1.country=t8.country AND t1.scheme=t8.scheme and t1.cover=t8.Cover) 
 ;
quit ; 

Data HISTO_FLUX_&CC. ;
set HISTO_FLUX_&CC.;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

Data OUT_GEP.HISTO_FLUX_&CC. ;
set HISTO_FLUX_&CC.;
/*if RPP not in ("0","") then LEGACY_SCHEME_BOOK="MACAO";
if RPP in ("0","") then LEGACY_SCHEME_BOOK="TIA";*/
drop informer_type Data_Validated Flag_Macao;
run ;

data &CC._REP_&Grp_Rsrv. ;
keep country Rsrv_Grp Month REP ;
set OUT_GEP.HISTO_FLUX_&CC.;
where Rsrv_Grp="&Grp_Rsrv."  and Month >"&YM_INF."  and LEGACY_SCHEME_BOOK="TIA" ;
run ; 

PROC SQL;
      create table &CC._REP_&Grp_Rsrv. as
             SELECT DISTINCT country,
                    Rsrv_Grp,
                    Month,
                    sum(REP) as REP
                                                       
     FROM    &CC._REP_&Grp_Rsrv.
     where Month <="&YM_SUP."
     group by country, Rsrv_Grp, Month 
      ; 
quit;
/* Pour stocker l'avant dernier montant REP dans le dernier REP*/

proc sql;
create table &CC._Tes_&Grp_Rsrv. as select count(REP) as count
from &CC._REP_&Grp_Rsrv.;
quit;

data _NULL_;
set &CC._Tes_&Grp_Rsrv.;
call symput('X_dernier',Count)  ;       
run;

%put &X_dernier;

data _NULL_;
set &CC._REP_&Grp_Rsrv.;
if  _N_= %EVAL(&X_dernier-1) THEN call symput('X_dernierS',REP)  ;       
run;


%put &X_dernierS;

data &CC._REP_&Grp_Rsrv.;
set &CC._REP_&Grp_Rsrv.;
if  _N_= &X_dernier  then REP= &X_dernierS;
run;

%macro EXPORT_EXCEL(DATABASE=,pays=,);

%let Chemin = "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/IBNR/Inputs/&quarter./&pays.";

PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET = &DATABASE. ;
run;
%MEND;

%EXPORT_EXCEL(DATABASE=&CC._REP_&Grp_Rsrv.,pays=&CC.);

proc datasets lib=work memtype=DATA;   delete &CC._REP_&Grp_Rsrv.;   run;

%mend;

%REP(CC=FR,Grp_Rsrv=GD1);
%REP(CC=FR,Grp_Rsrv=GR1);
%REP(CC=FR,Grp_Rsrv=GL1);
%REP(CC=FR,Grp_Rsrv=GP1);
/*%REP(CC=FR,Grp_Rsrv=GD2);*//*vide*/
/*%REP(CC=FR,Grp_Rsrv=GR2);*//*vide*/
%REP(CC=FR,Grp_Rsrv=GR3);
%REP(CC=FR,Grp_Rsrv=GL2);
%REP(CC=FR,Grp_Rsrv=GD3);

%REP(CC=PT,Grp_Rsrv=GD1);
%REP(CC=PT,Grp_Rsrv=GR1);
%REP(CC=PT,Grp_Rsrv=GL1);

%REP(CC=DE,Grp_Rsrv=GD1);
%REP(CC=DE,Grp_Rsrv=GR1);
%REP(CC=DE,Grp_Rsrv=GL1);
%REP(CC=DE,Grp_Rsrv=GP1);

%REP(CC=DK,Grp_Rsrv=GD1);
%REP(CC=DK,Grp_Rsrv=GR1);
%REP(CC=DK,Grp_Rsrv=GL1);

%REP(CC=FI,Grp_Rsrv=GD1);
%REP(CC=FI,Grp_Rsrv=GR1);
%REP(CC=FI,Grp_Rsrv=GL1);
%REP(CC=FI,Grp_Rsrv=GC1);

%REP(CC=NO,Grp_Rsrv=GD1);
%REP(CC=NO,Grp_Rsrv=GR1);
%REP(CC=NO,Grp_Rsrv=GL1);
%REP(CC=NO,Grp_Rsrv=GC1);
/*new*/
*%REP(CC=NO,Grp_Rsrv=GP1);/*vide*/


%REP(CC=SE,Grp_Rsrv=GD1);
%REP(CC=SE,Grp_Rsrv=GR1);
%REP(CC=SE,Grp_Rsrv=GL1);
/*new*/
%REP(CC=SE,Grp_Rsrv=GC1);

%REP(CC=GR,Grp_Rsrv=GD1);
%REP(CC=GR,Grp_Rsrv=GR1);

%REP(CC=IE,Grp_Rsrv=GD1);
%REP(CC=IE,Grp_Rsrv=GR1);
%REP(CC=IE,Grp_Rsrv=GL1);
%REP(CC=IE,Grp_Rsrv=GC1);

%REP(CC=PL,Grp_Rsrv=GD1);
%REP(CC=PL,Grp_Rsrv=GR1);
%REP(CC=PL,Grp_Rsrv=GL1);
%REP(CC=PL,Grp_Rsrv=GC1);
%REP(CC=PL,Grp_Rsrv=GP1);

%REP(CC=NL,Grp_Rsrv=GD1);
%REP(CC=NL,Grp_Rsrv=GR1);

%REP(CC=TR,Grp_Rsrv=GD1);
%REP(CC=TR,Grp_Rsrv=GR1);
%REP(CC=TR,Grp_Rsrv=GL1);

%REP(CC=ES,Grp_Rsrv=GD1);
%REP(CC=ES,Grp_Rsrv=GR1);
%REP(CC=ES,Grp_Rsrv=GL1);
%REP(CC=ES,Grp_Rsrv=GC1);

%REP(CC=CH,Grp_Rsrv=GD1);
%REP(CC=CH,Grp_Rsrv=GR1);
%REP(CC=CH,Grp_Rsrv=GC1);

%REP(CC=UK,Grp_Rsrv=GD1);
%REP(CC=UK,Grp_Rsrv=GR1);
%REP(CC=UK,Grp_Rsrv=GL1);


%REP(CC=IT,Grp_Rsrv=GD1);
%REP(CC=IT,Grp_Rsrv=GR1);
%REP(CC=IT,Grp_Rsrv=GL1);
%REP(CC=IT,Grp_Rsrv=GC1);
%REP(CC=IT,Grp_Rsrv=GP1);

%REP(CC=CO,Grp_Rsrv=GR1);
%REP(CC=CO,Grp_Rsrv=GD1);

%REP(CC=BE,Grp_Rsrv=GL1);
*%REP(CC=BE,Grp_Rsrv=GD1);/*vide*/
*%REP(CC=BE,Grp_Rsrv=GR1);/*vide*/

*%REP(CC=MX,Grp_Rsrv=GD1);/*vide*/
*%REP(CC=MX,Grp_Rsrv=GR1);/*vide*/
%REP(CC=MX,Grp_Rsrv=GP1);

%REP(CC=AT,Grp_Rsrv=GL1);
%REP(CC=AT,Grp_Rsrv=GD1);
%REP(CC=AT,Grp_Rsrv=GR1);
%REP(CC=AT,Grp_Rsrv=GP1);
