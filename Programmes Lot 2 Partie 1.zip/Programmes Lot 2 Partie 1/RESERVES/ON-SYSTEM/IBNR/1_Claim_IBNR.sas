/*#################################################################################################################################################################################
/*##########################################################       EXTRACTION DATA IBNR   ########################################################################################
/*################################################################################################################################################################################ 

######## Name: EXTRACTION DATA IBNR
######## Author: ALSENY SOW 
######## Date started :26/06/2018
######## Date finished:
######## Context: CREATION DES INPUTS  POUR LE CALCUL DES IBNR CLP

/*#####################################################  CREATION DES LIBRARY  ######################################################################################### */

%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%let QN = Q226 ;/* modifier le numero du quarter ( Q1,Q2,Q3,Q4) suivi de l'ann�e 21 pour 2021 par exemple*/
%LET Arrete = 2026_06_Prov;

LIBNAME CR_&QN. "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
/*######### Modification � faire: */

%LET Balancedate = '26/06/2026';
%LET quarter = 2026Q2;
%let Ouput=CR_&QN.;


/*#################################################################################################################################################################################
/*######################################################   MACRO EXTRACTION PAID   ########################################################################################
/*################################################################################################################################################################################ */

%Macro Dataprep(Balancedate);

*M3: 1 Set up Year-month grid;

DATA YRMNTH_GRID;

	do i = 0 to 95;
	YR = year(intnx('month',input(&Balancedate.,ddmmyy10.),-i));
	MNTH = month(intnx('month',input(&Balancedate.,ddmmyy10.),-i));
	output;
	end;
	drop i;
RUN;
DATA DEVMONTH;

	do i = 1 to 60;
	DEVMONTH = i;
	output;
	end;
	drop i;
RUN;

PROC SQL;
	CREATE TABLE YRMNTHDEV as
	SELECT DISTINCT YR, MNTH, DEVMONTH
	FROM YRMNTH_GRID, DEVMONTH;
QUIT;

%Mend;

%Dataprep(&Balancedate.);

%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx" ; 
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_01.,OUT=flag_legacy,ONGLET="flag_legacy");

%Macro DATA_IBNR(Grp=,pays=,);

proc sql ; 
create table CLMHDR_ALL_&pays. as
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from CR_&QN..CLMHDR_ALL_&pays.  t1 
left join FLAG_LEGACY t8 on (t1.country=t8.country AND t1.Schm=t8.scheme and t1.Cvr_Typ=t8.Cover) 
 ;
quit ;

Data CLMHDR_ALL_&pays.;
set CLMHDR_ALL_&pays. ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

Data CR_&QN..CLMHDR_ALL_&pays.;
set CLMHDR_ALL_&pays. ;
/*if RPP not in ("0","") then LEGACY_SCHEME_BOOK="MACAO";
if RPP in ("0","") then LEGACY_SCHEME_BOOK="TIA";*/
drop informer_type RPP Flag_Macao;
run ;

data CLMHDR_ALL_&pays. ;
set &Ouput..CLMHDR_ALL_&pays. ;
where  LEGACY_SCHEME_BOOK="TIA" ;
run;

PROC SQL;
		CREATE TABLE Export_IBNR_data_&pays._&Grp._0 as 
		SELECT  Acc_Yr, Acc_Mnth,
				case when ((Rgstrtn_Yr-Acc_Yr)*12+ (Rgstrtn_Mnth - Acc_Mnth))+1 <=0 then 1 when ((Rgstrtn_Yr-Acc_Yr)*12 + 
				(Rgstrtn_Mnth - Acc_Mnth))+1 > 59 then 60 else ((Rgstrtn_Yr-Acc_Yr)*12 + (Rgstrtn_Mnth - Acc_Mnth)) + 1 end as 
				Dev_Mnth,
				sum(Totl_Amnt_Pd) as Clms_Paid,
				sum(Totl_Amnt_Pd + Rsrv_Amt) as Clms_Incrd
		FROM CLMHDR_ALL_&pays.
		where Rsrv_Grp="&Grp."
		GROUP BY Acc_Yr, Acc_Mnth, Dev_Mnth;
QUIT;

PROC SQL;
		CREATE TABLE Export_PAID_data_&pays._&Grp._0 as 
		SELECT y.YR as AccYr, y.Mnth as AccMnth, y.DEVMONTH as Dev_Mnth, i.Clms_Paid
		FROM Export_IBNR_data_&pays._&Grp._0 i
		RIGHT JOIN YRMNTHDEV y ON (y.YR = i.Acc_Yr and y.Mnth = i.Acc_Mnth and y.DEVMONTH= i.Dev_Mnth)
		;
QUIT;

proc transpose DATA=EXPORT_PAID_DATA_&pays._&Grp._0 out=EXPORT_PAID_DATA_&pays._&Grp.;
	BY AccYr AccMnth;
	id Dev_Mnth;
run;

data EXPORT_PAID_DATA_&pays._&Grp.;
	set EXPORT_PAID_DATA_&pays._&Grp.;
	drop _NAME_;
run;

DATA  Q_EXPORT_PAID_DATA_&pays._&Grp. ;
  SET EXPORT_PAID_DATA_&pays._&Grp. ;
  ARRAY missing{*} _: ;
  DO i=1 to dim(missing) ;
    IF missing(i) =. THEN missing(i)= 0 ;
  END ;
  drop i;
RUN ;


PROC SQL;
		CREATE TABLE Export_IBNR_data_&pays._&Grp._1 as 
		SELECT y.YR as AccYr, y.Mnth as AccMnth, y.DEVMONTH as Dev_Mnth, i.Clms_Incrd
		FROM Export_IBNR_data_&pays._&Grp._0 i
		RIGHT JOIN YRMNTHDEV y ON (y.YR = i.Acc_Yr and y.Mnth = i.Acc_Mnth and y.DEVMONTH= i.Dev_Mnth)
		;
QUIT;

proc transpose DATA=EXPORT_IBNR_DATA_&pays._&Grp._1 out=EXPORT_IBNR_DATA_&pays._&Grp.;
	BY AccYr AccMnth;
	id Dev_Mnth;
run;
data EXPORT_IBNR_DATA_&pays._&Grp.;
	set EXPORT_IBNR_DATA_&pays._&Grp.;
	drop _NAME_;
run;

DATA  Q_EXPORT_IBNR_DATA_&pays._&Grp. ;
  SET EXPORT_IBNR_DATA_&pays._&Grp. ;
  ARRAY missing{*} _: ;
  DO i=1 to dim(missing) ;
    IF missing(i) =. THEN missing(i)= 0 ;
  END ;
  drop i;
RUN ;

%macro EXPORT_EXCEL(DATABASE=,c=,);

%let Chemin = "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/IBNR/Inputs/&quarter./&c.";

PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET ="Q_EXPORT_DATA" ;
run;
%MEND;

%EXPORT_EXCEL(DATABASE=Q_EXPORT_IBNR_DATA_&pays._&Grp.,c=&pays.);
%EXPORT_EXCEL(DATABASE=Q_EXPORT_PAID_DATA_&pays._&Grp.,c=&pays.);

proc datasets lib=work memtype=DATA;   delete Q_EXPORT_IBNR_DATA_&pays._&Grp.;   run;
proc datasets lib=work memtype=DATA;   delete Q_EXPORT_PAID_DATA_&pays._&Grp.;   run;
proc datasets lib=work memtype=DATA;   delete EXPORT_PAID_DATA_&pays._&Grp._0;   run;
proc datasets lib=work memtype=DATA;   delete EXPORT_PAID_DATA_&pays._&Grp.;   run;
proc datasets lib=work memtype=DATA;   delete Export_IBNR_data_&pays._&Grp._1;   run;
proc datasets lib=work memtype=DATA;   delete Export_IBNR_data_&pays._&Grp._0;   run;
proc datasets lib=work memtype=DATA;   delete Export_IBNR_data_&pays._&Grp.;   run;
proc datasets lib=work memtype=DATA;   delete CLMHDR_ALL_&pays.;   run;

%MEND;

 
/*#################################################################################################################################################################################
/*######################################################  EXTRACTION PAYS & GROUP OF RESERVE    ########################################################################################
/*################################################################################################################################################################################ */

        /* AUSTRIA */
        
%DATA_IBNR(Grp=GL1,pays=AT) ;
%DATA_IBNR(Grp=GR1,pays=AT) ;
%DATA_IBNR(Grp=GD1,pays=AT) ;
%DATA_IBNR(Grp=GP1,pays=AT) ;

        /* GERMANY*/
        
%DATA_IBNR(Grp=GL1,pays=DE) ;
%DATA_IBNR(Grp=GR1,pays=DE) ;
%DATA_IBNR(Grp=GD1,pays=DE) ;
%DATA_IBNR(Grp=GP1,pays=DE) ;

         /* SPAIN */

%DATA_IBNR(Grp=GR1,pays=ES) ;
%DATA_IBNR(Grp=GD1,pays=ES) ;
%DATA_IBNR(Grp=GC1,pays=ES) ;
%DATA_IBNR(Grp=GL1,pays=ES) ;
%DATA_IBNR(Grp=GP1,pays=ES) ;

       /* FINLAND*/ 

%DATA_IBNR(Grp=GR1,pays=FI) ;
%DATA_IBNR(Grp=GD1,pays=FI) ;
%DATA_IBNR(Grp=GL1,pays=FI) ;
%DATA_IBNR(Grp=GC1,pays=FI) ;

         /* ITALY*/

%DATA_IBNR(Grp=GR1,pays=IT) ;
%DATA_IBNR(Grp=GD1,pays=IT) ;
%DATA_IBNR(Grp=GC1,pays=IT) ;
%DATA_IBNR(Grp=GL1,pays=IT) ;
%DATA_IBNR(Grp=GP1,pays=IT) ;

        /* DENMARK*/

%DATA_IBNR(Grp=GR1,pays=DK) ;
%DATA_IBNR(Grp=GD1,pays=DK) ;
%DATA_IBNR(Grp=GL1,pays=DK) ;
%DATA_IBNR(Grp=GP1,pays=DK) ;

        /* PORTUGAL */

%DATA_IBNR(Grp=GR1,pays=PT) ;
%DATA_IBNR(Grp=GD1,pays=PT) ;
%DATA_IBNR(Grp=GL1,pays=PT) ;
%DATA_IBNR(Grp=GP1,pays=PT) ;
 
         /* NORWAY*/

%DATA_IBNR(Grp=GR1,pays=NO) ;
%DATA_IBNR(Grp=GD1,pays=NO) ;
%DATA_IBNR(Grp=GL1,pays=NO) ;
%DATA_IBNR(Grp=GC1,pays=NO) ;
/*new*/
%DATA_IBNR(Grp=GP1,pays=NO) ;



          /* SWEDEN */

%DATA_IBNR(Grp=GR1,pays=SE) ;
%DATA_IBNR(Grp=GD1,pays=SE) ;
%DATA_IBNR(Grp=GL1,pays=SE) ;
/*new*/
%DATA_IBNR(Grp=GC1,pays=SE) ;


         /* IRELAND */
         
%DATA_IBNR(Grp=GR1,pays=IE) ;
%DATA_IBNR(Grp=GD1,pays=IE) ;
%DATA_IBNR(Grp=GL1,pays=IE) ;
%DATA_IBNR(Grp=GC1,pays=IE) ;

        /* NORTHEN IRELAND */

%DATA_IBNR(Grp=GD1,pays=NI) ;
%DATA_IBNR(Grp=GL1,pays=NI) ;


         /* NETHERLAND*/

%DATA_IBNR(Grp=GR1,pays=NL) ;
%DATA_IBNR(Grp=GD1,pays=NL) ;

        /* SWITZERLAND */

%DATA_IBNR(Grp=GR1,pays=CH) ;
%DATA_IBNR(Grp=GD1,pays=CH) ;
%DATA_IBNR(Grp=GC1,pays=CH) ;

         /* POLAND */

%DATA_IBNR(Grp=GR1,pays=PL) ;
%DATA_IBNR(Grp=GD1,pays=PL) ;
%DATA_IBNR(Grp=GL1,pays=PL) ;
%DATA_IBNR(Grp=GC1,pays=PL) ;
%DATA_IBNR(Grp=GP1,pays=PL) ;

        /* TURKEY*/

%DATA_IBNR(Grp=GR1,pays=TR) ;
%DATA_IBNR(Grp=GD1,pays=TR) ;
%DATA_IBNR(Grp=GL1,pays=TR) ;

       /* UK */

%DATA_IBNR(Grp=GR1,pays=UK) ;
%DATA_IBNR(Grp=GD1,pays=UK) ;
%DATA_IBNR(Grp=GL1,pays=UK) ;
%DATA_IBNR(Grp=GP1,pays=UK) ;
/*new*/
%DATA_IBNR(Grp=GC1,pays=UK) ;


       /* GREECE */

%DATA_IBNR(Grp=GR1,pays=GR) ;
%DATA_IBNR(Grp=GD1,pays=GR) ;

      /* FRANCE */

%DATA_IBNR(Grp=GR1,pays=FR) ;
%DATA_IBNR(Grp=GR2,pays=FR) ;
%DATA_IBNR(Grp=GR3,pays=FR) ;
%DATA_IBNR(Grp=GD1,pays=FR) ;
%DATA_IBNR(Grp=GD2,pays=FR) ;
%DATA_IBNR(Grp=GD3,pays=FR) ;
%DATA_IBNR(Grp=GL1,pays=FR) ;
%DATA_IBNR(Grp=GL2,pays=FR) ;
%DATA_IBNR(Grp=GP1,pays=FR) ;

        /* COLOMBIA */
        
%DATA_IBNR(Grp=GR1,pays=CO) ;
%DATA_IBNR(Grp=GD1,pays=CO) ;

        /* BELGIUM*/
        
%DATA_IBNR(Grp=GR1,pays=BE) ;
%DATA_IBNR(Grp=GD1,pays=BE) ;
%DATA_IBNR(Grp=GL1,pays=BE) ;

        /* MEXICO */
        
%DATA_IBNR(Grp=GR1,pays=MX) ;
%DATA_IBNR(Grp=GD1,pays=MX) ;
%DATA_IBNR(Grp=GP1,pays=MX) ;