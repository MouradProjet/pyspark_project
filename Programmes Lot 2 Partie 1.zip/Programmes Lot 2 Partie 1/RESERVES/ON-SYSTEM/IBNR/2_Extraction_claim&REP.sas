/*#####################################################################################################################################################################################
/*##########################################################   EXTRACTION CLAIM PAID & RISK EARNED PREMIUM : NON-CORE COVER    ######################################################################################
/*##################################################################################################################################################################################### 

######## Name: EXTRACTION NON-CORE COVER
######## Author: ALSENY SOW 
######## Date started :15/11/2018
######## Date finished:
######## Context: RESERVING NON-CORE COVER LPI */

%Let arrete_carto=2026_04_V2;/**Mettre l'arret� le plus r�cent si on est hors arret�*/
%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete = 2026_06_Prov ;   
%LET DT_Arrete_Reel = "26JUN2026"d ; 
       
LIBNAME CR_Q226 "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
LIBNAME Out_GEP "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/DAAP" ;
LIBNAME TIA "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_techniques/TIA/Extraction Donnees/TIA";
*LIBNAME TIA2 "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/2021_11_Q4/02_Elements_Techniques/TIA/Extraction Donnees/TIA";
LIBNAME TIA2 "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&arrete_carto./02_Elements_Techniques/TIA/Extraction Donnees/TIA";

%LET Balancedate = '26/06/2026';
%LET Balancequarter = Q22026;
%LET quarter = 2026Q2;
%let Ouput=CR_Q226;

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx" ;

%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=SDB,ONGLET=SDB2);
%IMPORT_EXCEL(FILE=&Import_02.,OUT=Carto_TIA,ONGLET=Carto_TIA);

data &Ouput..scheme_databse ;

retain country scheme agent_name Products ;
keep country scheme agent_name Products Sub_Product;
set SDB ;
length Products $50.;
format Products $50.;
format agent_name $25.;
rename agent_name=Agent      
;

if Sub_Product="AUTFIN" then Products="Auto Finance" ;
if Sub_Product="INCPRO" then Products="Income Protection" ;
if Sub_Product="MORTGA" then Products="Mortgage" ;
if Sub_Product="PERACC" then Products="Personal Accident" ;
if Sub_Product="PERLOA" then Products="Personal Loan" ;
if Sub_Product="INSPRE" then Products="WOP" ;
if Sub_Product="CCANPP" then Products="Credit Card" ;
if Sub_Product in ("GAPCAR","GUAASS","GAPEQT") then Products="GAP" ;
if Sub_Product="EXPPRO" then Products="Expense Protection" ;
if Sub_Product="SCIINS" then Products="Standalone Critical Illness" ;
if Sub_Product="LUMPSU" then Products="Lump Sum" ;
if Sub_Product="FIPINS" then Products="Family Income Plan" ;
if Sub_Product="MISCPL" then Products="Misc Pecuniary" ;
if Sub_Product="MISCLE" then Products="Miscellaneous Life Events" ;
if Sub_Product="MISCPR" then Products="Miscellaneous Price Protection" ;
if Sub_Product="LIFINS" then Products="Standalone Life" ;
if Sub_Product="SSIINS" then Products="Standalone Serious Illness" ;
if Sub_Product="MISCSW" then Products="Miscellaneous Wallet Protection" ;
if Sub_Product="KEYMAN" then Products="Standalone Keyman" ;
if Sub_Product="WARRAN" then Products="Warranty" ;
if Sub_Product="TRAVEL" then Products="TRAVEL" ;
if Sub_Product="PRPROT" then Products="Price Protection" ;
run ;

data &Ouput..scheme_databse ;
set &Ouput..scheme_databse ;
rename Products=Product;
run;


data /*TIA.carto_TIA*/ carto_TIA2; 
set TIA2.CARTO_TIA; 
RUN;

PROC SORT DATA=carto_TIA2  nodupkey;by _all_;run;


%Macro EXTRACTION(pays=,country_name=,);

/*%LET pays =ES ;  */
/*%LET country_name =SPAIN;*/

/*  IMPORTATION DE LA LISTE DES CLIENTS TIA  */

Data CLAIM_PAID_&pays.;
Keep Country Rsrv_Grp Clm_Nmbr  Schm Cvr_Typ  Quarter Cohort Undrwrtng_Cmpny Totl_Amnt_Pd Rsrv_Amt Month ;
set &Ouput..CLMHDR_ALL_&pays.;
if Acc_Mnth in (1,2,3)    THEN Quarter=cats("Q1",Acc_Yr);
if Acc_Mnth in (4,5,6)    THEN Quarter=cats("Q2",Acc_Yr);
if Acc_Mnth in (7,8,9)    THEN Quarter=cats("Q3",Acc_Yr);
if Acc_Mnth in (10,11,12) THEN Quarter=cats("Q4",Acc_Yr);
if Acc_Mnth in (10,11,12) then Month=cats(Acc_Yr,Acc_Mnth) ;
if Acc_Mnth in (1,2,3,4,5,6,7,8,9) then  Month=cats(Acc_Yr,0,Acc_Mnth) ;
rename 
Schm=scheme
Cvr_Typ=cover
Undrwrtng_Cmpny=Entity_CD
;
Cohort=year(Incptn_Dt);
run;

PROC SQL;
      create table CLAIM_PAID_&pays. as
             SELECT DISTINCT country,
                    Rsrv_Grp,
                    COVER,
                    scheme ,
                    Entity_CD ,
                    Cohort,
                    Quarter,
                    Month,
                    sum(Totl_Amnt_Pd) as Claim_Paid
                                                       
     FROM    CLAIM_PAID_&pays.
     group by Country,COVER,scheme,Entity_CD,Cohort, Quarter,Month 
      ; 
 quit;


/* UPF */

/*DATA GEP_UPF_&pays.;
keep country scheme cover Cohort gl_type_no GEP QTR_Period Month  ;
set OUT_GEP.&country_name._UPF;
where EXP_PERIOD <= &DT_Arrete_Reel. ;
rename QTR_Period=Quarter  ;
Mois=month(EXP_PERIOD) ;
year=year(EXP_PERIOD) ;
if Mois in (10,11,12) then Month=cats(year,Mois) ;
if Mois in (1,2,3,4,5,6,7,8,9) then  Month=cats(year,0,Mois) ;
if GEP=. then GEP=0;
run;*/


/* BLK */

DATA GEP_BLK_&pays.;
keep country scheme  cover Cohort gl_type_no GEP QTR_Period Month  ;
set OUT_GEP.&country_name._BLK ;
where EXP_PERIOD <= &DT_Arrete_Reel. ;
rename QTR_Period=Quarter ;
Mois=month(EXP_PERIOD) ;
year=year(EXP_PERIOD) ;
if Mois in (10,11,12) then Month=cats(year,Mois) ;
if Mois in (1,2,3,4,5,6,7,8,9) then  Month=cats(year,0,Mois) ;
if GEP=. then GEP=0;
run;


/* MF */

DATA GEP_MF_&pays.;
keep country scheme  Cohort cover  gl_type_no GEP QTR_Period  Month  ;
set OUT_GEP.&country_name._MF ;
where EXP_PERIOD <= &DT_Arrete_Reel. ;
rename QTR_Period=Quarter ;     
Mois=month(EXP_PERIOD) ;
year=year(EXP_PERIOD) ;
if Mois in (10,11,12) then Month=cats(year,Mois) ;
if Mois in (1,2,3,4,5,6,7,8,9) then  Month=cats(year,0,Mois) ;
if GEP=. then GEP=0;
run;

/* MR  */

DATA GEP_MTRANS_&pays.;
keep country scheme  cover Cohort  gl_type_no GEP QTR_Period  Month  ;
set OUT_GEP.&country_name._MTRANS ;
where EXP_PERIOD <= &DT_Arrete_Reel. ;
rename QTR_Period=Quarter ;
Mois=month(EXP_PERIOD) ;
year=year(EXP_PERIOD) ;
if Mois in (10,11,12) then Month=cats(year,Mois) ;
if Mois in (1,2,3,4,5,6,7,8,9) then  Month=cats(year,0,Mois) ;
if GEP=. then GEP=0;
run;

/*concat*/
Data GEP_&pays.;
SET  GEP_MF_&pays. GEP_MTRANS_&pays. GEP_BLK_&pays. /*GEP_UPF_&pays.*/;
run;

PROC SQL;
      create table GEP_&pays. as
             SELECT DISTINCT country,
                    scheme,
                    cover,
                    gl_type_no AS Entity_CD,
                    Cohort,
                    Quarter,
                    Month ,
                    sum(GEP) as GEP
                                                       
     FROM    GEP_&pays.
     group by Country,scheme,cover, gl_type_no,Cohort, Quarter, Month 
      ; 
quit;

proc sql ; 
create table GEP_&pays._0 as
select DISTINCT
t1.*,
t2.Taux_Comm as Taux_Comm,
t2.retention_1_num as retention_1_num
from GEP_&pays. t1  
left join /*TIA.CARTO_TIA*/ CARTO_TIA2  t2 on (t1.country=t2.country AND t1.Scheme=t2.Scheme AND t1.COVER=t2.COVER);
quit ; 




DATA GEP_&pays._1 ;
set GEP_&pays._0;
IF Taux_Comm=. then Taux_Comm=0 ;
IF retention_1_num=. then retention_1_num=0 ;
comm_amount = (Taux_Comm/100)*GEP;
ret_amount = retention_1_num*GEP;
REP=GEP-comm_amount-ret_amount;
run;

%IF &pays.=DE or &pays.=IT or &pays.=FI or &pays.=PT or &pays.=NO or &pays.=DK or &pays.=ES or &pays.=SE or &pays.=TR or &pays.=NL or &pays.=NI or &pays.=IE or &pays.=GR or &pays.=PL  or &pays.=CH or &pays.=UK %THEN %DO;

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/&pays. Model Properties.xlsx" ;


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=&pays._RESERVE_GROUP_SPEC,ONGLET=RESERVE_GROUP_SPEC3);

PROC SQL;
	CREATE TABLE GEP_&pays._2 as 
	SELECT
			h.*,
			Rsrv_Grp
	FROM GEP_&pays._1 h
	LEFT JOIN &pays._RESERVE_GROUP_SPEC s ON (h.Cover = s.Cvr_Typ )
	;
QUIT;

data GEP_&pays._all ;
retain country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month GEP comm_amount ret_amount REP  ;
keep country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month GEP  comm_amount ret_amount REP ;
set GEP_&pays._2 ;
if Rsrv_Grp="" then Rsrv_Grp="ZZ1" ;
if GEP <0 then GEP=-GEP ;
if REP <0 then REP=-REP ;
run;

%END;

%IF &pays.=FR %THEN %DO;


%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/&pays. Model Properties.xlsx" ;

    
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=&pays._RESERVE_GROUP_SPEC,ONGLET=RESERVE_GROUP_SPEC3);
%IMPORT_EXCEL(FILE=&Import_02.,OUT=&pays._SCHEME_DATABASE,ONGLET=SCHEME_DATABASE);

PROC SQL;
	CREATE TABLE &pays._SCHEME_DATABASE as 
	SELECT DISTINCT
			Schm,
			COVER_TYPE,
			SUB_PRODUCT ,
			PAYMENT_BENEFIT as Clm_Pymnt_Basis,
			PRODUCT_TYPE
	FROM &pays._SCHEME_DATABASE 

	;
QUIT;


PROC SQL;
	CREATE TABLE GEP_&pays._11 as 
	SELECT DISTINCT
			h.*,
			s.SUB_PRODUCT ,
			s.Clm_Pymnt_Basis as Clm_Pymnt_Basis,
			s.PRODUCT_TYPE
	FROM GEP_&pays._1 h
	LEFT JOIN &pays._SCHEME_DATABASE s ON (h.SCHEME=s.Schm and  h.cover = s.COVER_TYPE )
	;
QUIT;

proc sort data=GEP_&pays._11 nodupkey out=GEP_&pays._11; 
 by country scheme cover Entity_CD Cohort Quarter Month ; 
run;

data GEP_&pays._1 ;
set GEP_&pays._11 ;
if SUB_PRODUCT not in ("MORTGAGE") then Sub_Prdct ="NMORTGAGE" ;
if SUB_PRODUCT     in ("MORTGAGE") then Sub_Prdct ="MORTGAGE" ;
run;


PROC SQL;
	CREATE TABLE GEP_&pays._2 as 
	SELECT DISTINCT 
			h.*,
			Rsrv_Grp
	FROM GEP_&pays._1 h
	LEFT JOIN &pays._RESERVE_GROUP_SPEC s ON (h.cover = s.Cvr_Typ and h.Sub_Prdct=s.Sub_Prdct and h.Clm_Pymnt_Basis=s.Clm_Pymnt_Basis )
	;
QUIT;

data GEP_&pays._2;

	set GEP_&pays._2;
	if Rsrv_Grp = "" and cover in ('DA','DB','DS','DC') then Rsrv_Grp = "GD1";
    if Rsrv_Grp = "" and cover in ('DI','DJ') then Rsrv_Grp = "GD3";
    if Rsrv_Grp = "" and cover in ('RR','RU') then Rsrv_Grp = "GR1";
    if Rsrv_Grp = "" and cover in ('GP') then Rsrv_Grp = "GP1";
    if Rsrv_Grp = "" and cover in ('LA','LL','LR','DY','DZ') then Rsrv_Grp = "GL1";
	if Rsrv_Grp = ""  then Rsrv_Grp = "ZZ1";
run;

data GEP_&pays._all ;
retain country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month GEP comm_amount ret_amount REP  ;
keep country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month GEP  comm_amount ret_amount REP ;
set GEP_&pays._2 ;
if Rsrv_Grp="" then Rsrv_Grp="ZZ1" ;
run;

%END;

/*#####################################################  FILTRE DES SCHEMES QUI NE FONT PAS PARTI DU ON-SYSTEM  ######################################################################################### */

/* The following codes put any claims which we want to filter out and not hold reserves for into group ZZ2. 
   This replaces the previous deletion of these claims from &pays._clmhdr_all in A2 Filter. DP 23/07/2014*/

/*S1-S7 are Santander business that is now reserved off system using bordereau.
H1-H6, HPA are Hispamer business that is now reserved off system using bordereau*/

%IF &pays. = ES %THEN %DO;

Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "H1%"
OR Scheme Like "H2%"
OR Scheme Like "H3%"
OR Scheme Like "H4%"
OR Scheme Like "H5%"
OR Scheme Like "H6%"
OR Scheme Like "HPA%"
OR Scheme Like "S1%"
OR Scheme Like "S2%"
OR Scheme Like "S3%"
OR Scheme Like "S4%"
OR Scheme Like "S5%"
OR Scheme Like "S6%"
OR Scheme Like "S7%";
Quit;

%END;

/*Linea Schemes are reserved by loss ratio*/

%IF &pays. =IT %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "LN1%";
Quit;
%END;

/*Norway TERRA Schemes are excluded*/

%IF &pays. = NO %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme IN("TA.1","TB.1","TC.1","TD.1","TE.1","TF.1","TG.1","TH.1","TI.1","TJ.1");
Quit;
%END;

/* Added 08/06/2017 to deal with 501/502 uw codes. */ 
/* Germany and turkey are only country which have these codes at time of writing, Underwriting company 501/502 need not be evaluated, so remove. */

%IF &pays. = DE OR &pays. = TR  %THEN %DO;

Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Entity_CD IN (501,502);
Quit;
%END;

/*removing of CNP Santander TPA Schemes for DK, FI, NO, SE*/

%IF &pays. = DK %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "5B%" or Scheme like "5C%";
Quit;
%END;

%IF &pays. = FI %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "SN%" ;
Quit;
%END;

%IF &pays. = NO %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "ED.%" or Scheme Like "EE.%" or Scheme Like "EG.%" or Scheme Like "EH.%" or Scheme Like "EI.%" or Scheme Like "EJ.%" or Scheme Like "EK.%" or Scheme Like "EL.%" or Scheme Like "EM.%";
Quit;
%END;

%IF &pays.= SE %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "ED.%" or Scheme Like "EE.%" or Scheme Like "EF.%" or Scheme Like "EG.%" or Scheme Like "EH.%" or Scheme Like "EI.%" or Scheme Like "EJ.%";
Quit;
%END;


/*From Q3 2012 some claims started being classified under dummy Schemes 8A.1 and ZA.1 due to them being in bulk and not having an 
identifiable Scheme.  These should not have reserves.*/


%IF &pays. =SE %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "ZA.%" ;
Quit;
%END;

%ELSE %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "8A.%";
Quit;
%END;

/* Capital One UK contract and run-off period ended on 27th November 2013*/

%IF &pays. = UK %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "CFA%" OR Scheme Like "CFN%";
Quit;
%END;

/* Ceasing business with the client DLFA in Denmark from 01/04/14 - 
All claims then paid by client including those which are outstanding*/

%IF &pays. = DK %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme Like "Q%";
Quit;
%END;

/* Some Greece Schemes have run off more than 12 months ago and terms and conditions 
   don�t allow for claims 12 month after insurance period. Added by DP 23/07/2014*/

%IF &pays. = GR %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme IN ("BPI.1","BPJ.1","BPK.1","BPL.1","BPM.1","EM1.1","EM2.1","GM1.1");
Quit;
%END;

/*We had some German contracts that were terminated as part of project bounce.
We were required to pay claims up to a certain period. That period has now lapsed. Added by DP 23/07/2014*/

%IF &pays. = DE %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme IN ("P4.2","P4.3");
Quit;
%END;


/*Irish Santander Schemes nearly run-off. Added by DP 03/11/2014*/

%IF &pays. = IE %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme IN ("EV.3","EV.4");
Quit;
%END;




/* Some France UGIP claims on TIA but full history not loaded so continue reserving off-system . Added by DP 18/09/2014*/

/*%IF &pays. = FR %THEN %DO;
Proc Sql;
Update GEP_&pays._all 
Set Rsrv_Grp = "ZZ2"
WHERE Scheme like "UG1%" or Scheme like "UG6%" or Scheme like "UG7%" or Scheme like "UG8%" 
or Scheme like "UG9%" or Scheme like "UGC%" or Scheme like "UGD%" or Scheme like "UGG%" 
or Scheme like "UGH%" or Scheme like "UGI%" or Scheme like "UGN%" or Scheme like "UGX%";
Quit;
%END;
*/

/* Some France GMAC policies needed to be switched from GL Type 101 to 102 (therefore underwritten by FACL) as part of the
AS60 transfer. Added by TD 09/09/2015*/

%IF &pays. = FR %THEN %DO;

Proc Sql;
Update GEP_&pays._all
Set Entity_CD = 102
Where Scheme like "1%" and cover like "D%";
Quit;
%END;

/* Merge GEP & claims */

data CLAIM_PAID_&pays. ;
set CLAIM_PAID_&pays. ;
Entity_CD2=Entity_CD*1;
DROP Entity_CD ;
run;

data CLAIM_PAID_&pays. ;
set CLAIM_PAID_&pays. ;
rename Entity_CD2=Entity_CD;
run;

proc sort data=GEP_&pays._all  ;              by     country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month    ; run;
proc sort data=CLAIM_PAID_&pays.  ;           by     country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month     ; run;

data GEP_CLAIM_&pays._all;
retain country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month GEP comm_amount ret_amount REP Claim_Paid   ;
Keep   country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month  GEP comm_amount ret_amount REP Claim_Paid   ;
merge GEP_&pays._all (in=a) CLAIM_PAID_&pays.(in=b);
by  country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month   ;
if a or b;

if GEP=. then GEP=0;
if comm_amount=. then comm_amount =0 ;
if ret_amount=.  then ret_amount =0 ;
if REP=. then REP=0 ;
if Claim_Paid=. then Claim_Paid=0 ;
run;

proc sort data=GEP_CLAIM_&pays._all nodupkey out=GEP_CLAIM_&pays._all; 
 by country Rsrv_Grp scheme cover Entity_CD Cohort Quarter Month ; 
run;


PROC SQL;
	CREATE TABLE GEP_CLAIM_&pays._all as 
	SELECT distinct
			h.*,
			s.Agent,
			s.Product
	FROM GEP_CLAIM_&pays._all h
	left JOIN &Ouput..SCHEME_DATABSE s ON (h.Country=s.Country  and h.scheme=s.scheme)
	
	;
QUIT;

data Out_GEP.HISTO_FLUX_&pays. ;
set  GEP_CLAIM_&pays._all  ;
run;

PROC SQL;
      create table Out_GEP.HISTO_FLUX_&pays. as
             SELECT DISTINCT country,
                    Rsrv_Grp,
                    scheme,
                    cover,
                    Entity_CD AS Entity_CD,
                    Cohort,
                    Quarter,
                    Month ,
                    sum(GEP) as GEP,
                    sum(REP) as REP,
                    sum(Claim_Paid) as Claim_Paid,
                    Agent,
                    Product
                                                      
     FROM    Out_GEP.HISTO_FLUX_&pays.
     group by Country,Rsrv_Grp,scheme,cover, Entity_CD,Cohort, Quarter, Month, Agent,Product
                    
      ; 
quit;

%MEND;

/* les 4 type de primes*/

%EXTRACTION(pays=DE,country_name=GERMANY) ;
%EXTRACTION(pays=ES,country_name=SPAIN) ;
%EXTRACTION(pays=PT,country_name=PORTUGAL) ;
%EXTRACTION(pays=GR,country_name=GREECE) ;
%EXTRACTION(pays=DK,country_name=DENMARK) ;
%EXTRACTION(pays=IE,country_name=IRELAND) ;
%EXTRACTION(pays=TR,country_name=TURKEY) ;
%EXTRACTION(pays=CH,country_name=SWITZERLAND) ;
%EXTRACTION(pays=IT,country_name=ITALY) ;
%EXTRACTION(pays=UK,country_name=UK);
%EXTRACTION(pays=AT,country_name=AUSTRIA) ;

/* faut enlever le MF*/

%EXTRACTION(pays=NO,country_name=NORWAY) ;
%EXTRACTION(pays=FI,country_name=FINLAND) ;
%EXTRACTION(pays=SE,country_name=SWEDEN) ;
%EXTRACTION(pays=PL,country_name=POLAND) ;
%EXTRACTION(pays=CO,country_name=COLOMBIA) ;
%EXTRACTION(pays=MX,country_name=MEXICO) ;
%EXTRACTION(pays=BE,country_name=BELGIUM) ;

/* Faut enlever le BLK et le MF*/

%EXTRACTION(pays=NL,country_name=NETHERLANDS) ;

/*Il faut enlever le MR et le MF*/
%EXTRACTION(pays=NI,country_name=NORTHERNIRELAND) ; 

/* faut enlever le UPF */

%EXTRACTION(pays=FR,country_name=FRANCE)  ;

/*Check pour voir s'il y a des agents manquants*/

%macro manquante(pays);
Data schim_manq_&pays.;
set OUT_GEP.HISTO_FLUX_&pays.;
where Agent ="";
run;
%mend;
%manquante(FR);%manquante(IE);
%manquante(DE);%manquante(BE);%manquante(AT);%manquante(MX);%manquante(NL);%manquante(NI);
%manquante(NO);%manquante(PT);%manquante(ES);%manquante(SE);%manquante(PL);%manquante(CO);
%manquante(FI);%manquante(UK);%manquante(IT);%manquante(CH);%manquante(GR);%manquante(DK);
