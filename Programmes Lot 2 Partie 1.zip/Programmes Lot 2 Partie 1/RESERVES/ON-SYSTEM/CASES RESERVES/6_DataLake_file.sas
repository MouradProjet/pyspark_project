/*#####################################################################################################################################################################################
/*##########################################################       Creation des fichiers du Datalake    ######################################################################################
/*##################################################################################################################################################################################### 


######## Name: MODUL RESERVING CLP
######## Author: ALSENY SOW 
######## Date started :26/06/2018
######## Date finished:10/07/2018
######## Context: 

/*#####################################################  CREATION DES LIBRARY  ######################################################################################### */

%let LReseau =  ~/NAS/X; /* Mettre le serveur appropri�  entre -> ~/NAS/X  ou -> X:/Inventprev ** */
%let Arrete = 2026_06_Prov ;
%let Ouput=CR_Q226;
%let month=06;
%let day=26;
%let yr=2026;

LIBNAME input "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Input";
LIBNAME &Ouput. "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";


/*###################################################  CASES RESERVES  ######################################################################################### */

DATA &Ouput..clmhdr_all_countries;
set &Ouput..clmhdr_all_FR
    &Ouput..clmhdr_all_FI
    &Ouput..clmhdr_all_CH
    &Ouput..clmhdr_all_DE
    &Ouput..clmhdr_all_DK
    &Ouput..clmhdr_all_ES
    &Ouput..clmhdr_all_IE
    &Ouput..clmhdr_all_IT
    &Ouput..clmhdr_all_NI
    &Ouput..clmhdr_all_NL
    &Ouput..clmhdr_all_NO
    &Ouput..clmhdr_all_GR
    &Ouput..clmhdr_all_PL
    &Ouput..clmhdr_all_PT
    &Ouput..clmhdr_all_NO
    &Ouput..clmhdr_all_SE
    &Ouput..clmhdr_all_TR
    &Ouput..clmhdr_all_UK
    &Ouput..clmhdr_all_AT
    &Ouput..clmhdr_all_BE
    &Ouput..clmhdr_all_CO
    &Ouput..clmhdr_all_MX;
run;


DATA &Ouput..wps_daap_case_reserves_&yr.&month.&day. ;
set &Ouput..clmhdr_all_FR_CR
    &Ouput..clmhdr_all_FI_CR
    &Ouput..clmhdr_all_DE_CR
    &Ouput..clmhdr_all_DK_CR
    &Ouput..clmhdr_all_ES_CR
    &Ouput..clmhdr_all_IE_CR
    &Ouput..clmhdr_all_IT_CR
    &Ouput..clmhdr_all_NI_CR
    &Ouput..clmhdr_all_NL_CR
    &Ouput..clmhdr_all_NO_CR
    &Ouput..clmhdr_all_GR_CR
    &Ouput..clmhdr_all_PL_CR
    &Ouput..clmhdr_all_PT_CR
    &Ouput..clmhdr_all_NO_CR
    &Ouput..clmhdr_all_SE_CR
    &Ouput..clmhdr_all_TR_CR
    &Ouput..clmhdr_all_UK_CR
    &Ouput..clmhdr_all_CH_CR
    &Ouput..clmhdr_all_AT_CR
    &Ouput..clmhdr_all_CO_CR
    &Ouput..clmhdr_all_BE_CR
    &Ouput..clmhdr_all_MX_CR;
run;


PROC SQL;
create table &Ouput..wps_daap_case_reserves_&yr.&month.&day. as
SELECT DISTINCT *                                 
FROM &Ouput..wps_daap_case_reserves_&yr.&month.&day.
group by country, Clm_Nmbr; 
quit;

%let Import_01="&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx" ;     
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=flag_legacy,ONGLET="flag_legacy");

/*Correction du mapping MACAO vs TIA*/

proc sql ; 
create table wps_daap_case_reserves_&yr.&month.&day. as 
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from &Ouput..wps_daap_case_reserves_&yr.&month.&day.  t1 
left join FLAG_LEGACY t8 on (t1.country=t8.country AND t1.SCHEME=t8.scheme and t1.cover=t8.Cover) ;
quit ; 

DATA wps_daap_case_reserves_&yr.&month.&day.  ;
set wps_daap_case_reserves_&yr.&month.&day.  ;
if Flag_Macao in ("MACAO") then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao  in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

DATA &Ouput..wps_daap_case_reserves_&yr.&month.&day.  ;
set wps_daap_case_reserves_&yr.&month.&day.  ;
drop informer_type RPP Flag_Macao;
run ;

data WPS_DAAP_CASE_RESERVES_&yr.&month.&day. ;
set &Ouput..wps_daap_case_reserves_&yr.&month.&day. ;
where country not in ("CH") and LEGACY_SCHEME_BOOK="TIA" ; /*la DAAP n'est pas responsable du calcul de la suisse, pour les autres c'est encore du off-system et nous n'avons pas le sign-off de l'IT (donn�es non fiables)*/
drop LEGACY_SCHEME_BOOK ;
IF   Country="" then delete ;
run;										/* les tables n'ont pas �t� qualibr�es pour ces pays, pour l'instant on prend les hypoth�ses de l'allemagne -> � mettre � jour*/

PROC SQL;
		CREATE TABLE WPS_DAAP_CASE_RESERVES_&yr.&month.&day. as 
		SELECT 		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Type_Insurance,
		 SCHEME ,
		 cover,
		 Entity_CD,
		 Entity,
		 Incident_date,
		 Rgstrtn_Dt,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Vintage_year,
		 Date_of_reserving,
		 STATUS,
		 Totl_Amnt_Pd_Gross,
		 Totl_Amnt_Pd_Net,
		 Totl_Bnfts_Amnt_Pd_Gross,
		 Totl_Bnfts_Amnt_Pd_Net,
		 Probablty_Accptd,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt_Gross,
		 Rsrv_Amt_Net		 		 
		FROM WPS_DAAP_CASE_RESERVES_&yr.&month.&day. 
		GROUP BY country,Clm_Nmbr,SCHEME,cover ;
QUIT;


/*#####################################################  IBNR et NCC  ######################################################################################### */

data &Ouput..WPS_DAAP_IBNR_&yr.&month.&day._ACR ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day. ;
where Rsrv_Grp NE "ZZ1";
run ;


DATA WPS_DAAP_IBNR_&yr.&month.&day.  ;
retain country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD2 Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
retain country Rsrv_Grp Scheme Type_Insurance Cover Entity_CD2 Entity Incident_Quarter Vintage_year Date_of_reserving Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day._ACR ;
Entity_CD2=Entity_CD*1 ;
drop Entity_CD ;
rename Entity_CD2=Entity_CD ;
run;

Data &Ouput..WPS_DAAP_IBNR_&yr.&month.&day. ;
set  WPS_DAAP_IBNR_&yr.&month.&day. &Ouput..WPS_DAAP_NCC_&yr.&month.&day. ;
if Vintage_year="" then Vintage_year=9999 ;
if Vintage_year in (2026,5015,2918,2077,2088,3007) then Vintage_year=9999 ;
run;

data &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.;
if date_of_reserving=" &yr.substr(&Arrete.,9,2)" then date_of_reserving="substr(&Arrete.,9,2)&yr." ;
if country = "" then country = "ES" ;
if country = "ES" and entity = "" then entity = "FICL";
RUN;

data WPS_DAAP_IBNR_&yr.&month.&day. ;
set &Ouput..WPS_DAAP_IBNR_&yr.&month.&day. ;
where country ne "CH" ;
run;

PROC SQL;
create table WPS_DAAP_IBNR_&yr.&month.&day. as
SELECT DISTINCT *                                 
FROM    WPS_DAAP_IBNR_&yr.&month.&day.
group by country, Scheme, Type_Insurance, Cover, Entity_CD, Entity, Incident_Quarter, Vintage_year; 
quit;
 
%let Import_01="&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/2021_11_Q4/02_Elements_Techniques/TIA/Extraction Donnees/20210408 List TIA scheme exclusion - C and TPA.xlsx" ;
%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT
DATAFILE= &FILE.
OUT= &OUT.
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;
%IMPORT_EXCEL(FILE=&Import_01.,OUT=flag_double,ONGLET="Sheet1");

data FLAG_DOUBLE;
set FLAG_DOUBLE;
RUN;

proc sql ;
create table WPS_DAAP_IBNR_&yr.&month.&day. as
select
t1.*,
t7.RI_inwards_cash_matching AS flag_web
from WPS_DAAP_IBNR_&yr.&month.&day. t1
left join flag_double t7 on (t1.Country=t7.Country_CD AND t1.SCHEME=t7.contract_id_version);
quit ;


DATA WPS_DAAP_IBNR_&yr.&month.&day. ;
set WPS_DAAP_IBNR_&yr.&month.&day. ;
if cats(flag_web) in ("","N/A")  then LEGACY_WEBXL_BOOK="TIA";
else LEGACY_WEBXL_BOOK="WEBXL";
run ;

DATA WPS_DAAP_IBNR_&yr.&month.&day. ;
set WPS_DAAP_IBNR_&yr.&month.&day. ;
where LEGACY_WEBXL_BOOK="TIA";
drop LEGACY_WEBXL_BOOK flag_web;
Run;



/*********** EXPORT DES BASES POUR LE SHAREPOINT ************/

%let Chemin = "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/REPORTING/Datalake";

%macro EXPORT_EXCEL(DATABASE=);
PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=csv REPLACE ;
SHEET = &DATABASE. ;
run;
%MEND;

%EXPORT_EXCEL(DATABASE=wps_daap_case_reserves_&yr.&month.&day.);
%EXPORT_EXCEL(DATABASE=WPS_DAAP_IBNR_&yr.&month.&day.);

*IBNR + NCC en xlsx ;
PROC EXPORT       
DATA =WPS_DAAP_IBNR_&yr.&month.&day.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET ="&yr.&month.&day." ;
run;

