/*#################################################################################################################################################################################
/*##########################################################       EXTRACTION CLAIMS DU DATA LAKE   ########################################################################################
/*################################################################################################################################################################################ 

######## Name: EXTRACTION CLAIMS DU DATA LAKE
######## Author: ALSENY SOW 
######## Date started :26/06/2018
######## Date finished:
######## Context: EXTRACTION CLAIMS DANS LE DATA LAKE POUR CONSTRUIRE LES BASES CLMHDR & CLMTRNS QUI PERMETTENT DE CALCULER LES CASES RESERVES (ICOP & RBNP)


/*####################################################  CREATION DES LIBRARY  ######################################################################################### */
/*LIBNAME CLAIM2 ODBC REQUIRED="DSN=WPS_Shine_blcl" SCHEMA = "clp_wps" readbuff=100000;*/

%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete =2026_06_Prov ;
libname data "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Claims Extracts";

/*%wps_mac_connexion_db(
    nom_libname = CLAIM ,
    nom_db = WPS_SHINE_BLCL ,
    nom_schema = clp_wps ,
    nom_options = readbuff=10000 schema=global_claims_extracts
    );*/
libname CLAIM odbcold  DSN=WPS_SHINE_BLCL  authdomain="DB_WPS_SHINE_BLCL"  schema=global_claims_extracts ;

%Macro Datadownload_DTW(pays=,);


/*###########################################################       CREATION DE LA BASE CLMHDR    ######################################################################################### */

/*%LET pays =PT ;*/

/*data data.&pays._claim_header ;*/
/*set  CLAIM2.&pays._claim_head_tiariadmin ;*/
/*run ;*/

data data.&pays._claim_header ;
set  CLAIM.&pays._claim_head_tiariadmin ;  /*table filtrer sans categroy C*/
run ;


/*data data.&pays._claim_header ;ou il y a la catergorie C*/
/*set  CLAIM2.&pays._claim_header;*/
/*run ;*/

PROC SQL;
		CREATE TABLE data.&pays._CLMHDR as
		SELECT COUNTRY_CD as Country,
			CLA_CASE_NO format=BEST12.,
			POLICY_LINE_NO format=BEST12.,
			POLICY_LINE_SEQ_NO format = BEST12., 
			COVER format = $2. length = 2,
			scheme format = $8. length = 8, 
			datepart(incident_date) as incident_date  format = ddmmyy10., 
			datepart(NOTIFICATION_DATE) as NOTIFICATION_DATE format = ddmmyy10.,
			datepart(COVER_START_DATE) as COVER_START_DATE format = ddmmyy10., 
			datepart(COVER_END_DATE) as COVER_END_DATE format = ddmmyy10.,
			datepart(FIRST_OPEN_DATE) as FIRST_OPEN_DATE  format = ddmmyy10., 
			datepart(FIRST_CLOSE_DATE) as FIRST_CLOSE_DATE format ddmmyy10.,
			datepart(REOPEN_DATE) as REOPEN_DATE format = ddmmyy10., 
			datepart(RECLOSE_DATE) as RECLOSE_DATE format = ddmmyy10.,
			STATUS format = $2. length = 2,
            CLOSE_CODE format = $3. length = 3,
			INSURANCE_TERM format = BEST12.,
			UW_COMPANY /*format = BEST12.*/ , 
			CLAIM_MONTHLY_BENEFIT format = BEST12., 
			POLICY_MONTHLY_BENEFIT format = BEST12.,
			OUTSTANDING_LIFE_BALANCE format = BEST12., 
			datepart(POLICY_EXPIRY_DATE) as POLICY_EXPIRY_DATE format = ddmmyy10., 
			MAX_NO_OF_PAYMENTS format = BEST12.,
			IS_BULK format = $1. length = 1,
			OUTSTANDING_NONLIFE_BALANCE format = BEST12.,
			GROUP_POL_NO format = $6. length = 6,
			TOTAL_PAYMENTS format = BEST12., 
			TOTAL_NON_OTHER_PAYMENTS format = BEST12., 
			TOTAL_NON_OTHER_PAYMENTS_AMT format = BEST12., 
			datepart(BIRTH_DATE) as BIRTH_DATE  format = ddmmyy10.,
			GENDER format = $1. length = 1, 
			POLICY_NO format = BEST12., 
			EVENT_TYPE format = $3. length = 3,
			DECLINE format = $4. length =4,
			DECLINE_REASON_REF format = $50. length =50,
			potential_clm_amt  AS POTENTIAL_CLM_AMT format = BEST12.,
			datepart(DECISION_DATE) as DECISION_DATE format = ddmmyy10.,
			datepart(last_activity_date) as last_activity_date format = ddmmyy10.,  
			PROD_ID format = $5. length = 5,
		    cause_code format = $20. length = 20,
		    informer_type format = $20. length = 20
		FROM data.&pays._claim_header ;
		
		/*%IF &pays. = UK %THEN %DO;
		UK filters to incident dates after 2003
			where incident_date > MDY(1,1,2003);
		%END;
		%ELSE %DO;
			;
		%END;
		*/
		
		QUIT;
		
		
/*#####################################################  CREATION DE LA BASE CLMTRANS  ######################################################################################### */

data data.&pays._claim_detail ;
set  CLAIM.&pays._claim_det_tiariadmin ;
run ;
/**/
/*data data.&pays._claim_detail ;*/
/*set  CLAIM2.&pays._claim_detail ;*/
/*run ;*/



	PROC SQL;
		CREATE TABLE data.&pays._CLMTRNS as
		SELECT COUNTRY_CD as Country, 
			CLA_CASE_NO format = BEST12.,
			datepart(TRANS_DATE) as TRANS_DATE format = ddmmyy10.,
			CURRENCY_AMT format = BEST12.,
			SPECIFICATION format = $5. length = 5,
			ITEM_CLASS format = BEST12.,
			GROSS_AMT format = BEST12.,
			datepart(DUE_DATE) as DUE_DATE format = ddmmyy10.,
			SUBITEM_TYPE format = $3. length = 3,
			ACC_ITEM_NO format = BEST12.
		FROM data.&pays._claim_detail ;
		
       /* %IF &pays. = UK %THEN %DO;
   
		UK filters to incident dates after 2003 
		
			where incident_date > MDY(1,1,2003);
		%END;
		%ELSE %DO;
			;
		%END;
	   */
	
	QUIT;
	
%MEND; 

%Datadownload_DTW(pays=DE) ;
%Datadownload_DTW(pays=FR) ;
%Datadownload_DTW(pays=FI) ;
%Datadownload_DTW(pays=NO) ;
%Datadownload_DTW(pays=IT) ;
%Datadownload_DTW(pays=ES) ;
%Datadownload_DTW(pays=IE) ;
%Datadownload_DTW(pays=GR) ;
%Datadownload_DTW(pays=NI) ;
%Datadownload_DTW(pays=NL) ;
%Datadownload_DTW(pays=PL) ;
%Datadownload_DTW(pays=PT) ;
%Datadownload_DTW(pays=TR) ;
%Datadownload_DTW(pays=DK) ;
%Datadownload_DTW(pays=SE) ;
%Datadownload_DTW(pays=UK) ;
%Datadownload_DTW(pays=CH) ;
%Datadownload_DTW(pays=AT) ;
%Datadownload_DTW(pays=BE) ;
%Datadownload_DTW(pays=MX) ;
*%Datadownload_DTW(pays=LU) ;
%Datadownload_DTW(pays=LT) ;
%Datadownload_DTW(pays=CO) ;
%Datadownload_DTW(pays=EE) ;
*%Datadownload_DTW(pays=KR) ;
*%Datadownload_DTW(pays=PE) ;
%Datadownload_DTW(pays=LV) ;


data DATA.UK_CLMHDR ;
set DATA.UK_CLMHDR ;
if Country="GB" then Country="UK" ;
run ;

data DATA.UK_CLMTRNS ;
set DATA.UK_CLMTRNS ;
if Country="GB" then Country="UK" ;
run ; 




