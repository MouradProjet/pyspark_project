
%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete = 2026_06_Prov ;
%let Ouput=CR_Q226;
%let month=06;
%let day=26;
%let yr=2026;
%let Q=Q22026;


LIBNAME &Ouput. "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";


/*#################################################################################################################################################################################
/*######################################################   IMPACT CASE RESERVES : COMPARER LES CASES RESERVES Q1   VS Q2    ##############################################
/*################################################################################################################################################################################ */


/*  CR DAAP  */

DATA Table_DAAP_&yr.&month.&day.;
retain country Rsrv_Grp Clm_Nmbr cover Entity Totl_Bnfts_Amnt_Pd_Gross Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net informer_type;
keep country Rsrv_Grp Clm_Nmbr  cover  Entity Totl_Bnfts_Amnt_Pd_Gross Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net informer_type ;
set &Ouput..wps_daap_case_reserves_&yr.&month.&day.;
where  STATUS  in ("OP","RO")  and Rsrv_Grp NOT in ("ZZ1","ZZ2") and LEGACY_SCHEME_BOOK="TIA" ; 
Rename 
Totl_Bnfts_Amnt_Pd_Gross=Totl_Bnfts_Amnt_Pd_DAAP_&Q.
Rsrv_Amt_Gross=Rsrv_Amt_DAAP_&Q.
;

run;


PROC SQL;
      create table Table_DAAP_&yr.&month.&day. as
             SELECT country,
                    Rsrv_Grp,
                    cover,
                    Entity,
                    Rsrv_Typ,
                    sum(Rsrv_Amt_DAAP_&Q.) as Rsrv_Amt_DAAP_&Q.,
                    sum(Rsrv_Amt_Net) as Rsrv_Amt_Net_&Q.
                                                       
     FROM    Table_DAAP_&yr.&month.&day.
     group by country, Rsrv_Grp, cover,Entity, Rsrv_Typ
      ; 
 quit;
 
 
DATA Table_MACAO_&yr.&month.&day.;
retain country Rsrv_Grp Clm_Nmbr cover Entity Totl_Bnfts_Amnt_Pd_Gross Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net informer_type;
keep country Rsrv_Grp Clm_Nmbr  cover  Entity Totl_Bnfts_Amnt_Pd_Gross Rsrv_Typ Rsrv_Amt_Gross Rsrv_Amt_Net informer_type ;
set &Ouput..wps_daap_case_reserves_&yr.&month.&day.;
where  STATUS  in ("OP","RO")  and Rsrv_Grp NOT in ("ZZ1","ZZ2") and LEGACY_SCHEME_BOOK="MACAO" ; 
Rename 
Totl_Bnfts_Amnt_Pd_Gross=Totl_Bnfts_Amnt_Pd_DAAP_&Q.
Rsrv_Amt_Gross=Rsrv_Amt_DAAP_&Q.
;

run;

 PROC SQL;
      create table Table_MACAO_&yr.&month.&day. as
             SELECT country,
                    Rsrv_Grp,
                    cover,
                    Entity,
                    Rsrv_Typ,
                    sum(Rsrv_Amt_DAAP_&Q.) as Rsrv_Amt_DAAP_&Q.,
                    sum(Rsrv_Amt_Net) as Rsrv_Amt_Net_&Q.
                                                       
     FROM    Table_MACAO_&yr.&month.&day.
     group by country, Rsrv_Grp, cover,Entity, Rsrv_Typ
      ; 
 quit; 

%let Chemin = "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";

%let database=WORK.TABLE_DAAP_&yr.&month.&day.;
PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET ="&yr.&month.&day." ;
run;

%let database1=WORK.TABLE_MACAO_&yr.&month.&day.;
PROC EXPORT       
DATA =&DATABASE1.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET ="&yr.&month.&day." ;
run;
 
/*#################################################################################################################################################################################
/*######################################################   IMPACT IBNR : COMPARER LES IBNR  Q1 VS  Q2    ##############################################
/*################################################################################################################################################################################ */

PROC SQL;
      create table IBNR_LPI_%substr(&Q.,1,2)&yr. as
             SELECT country,
                    Rsrv_Grp,
                    cover,
                    Entity,
                    sum(Rsrv_Amt_Gross) as Rsrv_Amt                                    
     FROM    &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.
     where Rsrv_Grp not in ("ZZ1")
     group by country, Rsrv_Grp, cover,Entity
      ; 
 quit;
 
%let database=IBNR_LPI_%substr(&Q.,1,2)&yr.;
%let Chemin = "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
PROC EXPORT       
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET ="&yr.&month.&day." ;
run;

/*PROC SQL;*/
/*      create table NC_LPI_Q42019 as*/
/*             SELECT country,*/
/*                    Rsrv_Grp,*/
/*                    cover,*/
/*                    Entity,*/
/*                    sum(Rsrv_Amt_Gross) as Rsrv_Amt_Q4  */
/*     FROM    CR_Q120.WPS_DAAP_IBNR_20191227*/
/*     where Rsrv_Grp  in ("ZZ1")*/
/*     group by country, Rsrv_Grp, cover,Entity*/
/*      ; */
/* quit;*/

PROC SQL;
      create table NNC_LPI_&Q. as
             SELECT country,
                    Rsrv_Grp,
                    cover,
                    Entity,
                    sum(Rsrv_Amt_Gross) as Rsrv_Amt                                    
     FROM    &Ouput..WPS_DAAP_NCC_&yr.&month.&day.
     where Rsrv_Grp in ("ZZ1")
     group by country, Rsrv_Grp, cover,Entity
      ; 
 quit;
%let database=WORK.NNC_LPI_&Q.;
*%let Chemin = "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/NON-CORE-COVER/Outputs";
Proc export
DATA =&DATABASE.
OUTFILE=&Chemin.
DBMS=xlsx REPLACE ;
SHEET ="&yr.&month.&day." ;
run;

