%LET Balancedate = '26/06/2026'; *dernier vendredi du trimestre (mois si on le fait hors quarter); 
%LET Arrete = 2026_06_Prov;

*This macro downloads the country specific parameters for each country.;

%MACRO Specification(pays=,);

%let Import="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/&pays. Model Properties.xlsx";

PROC IMPORT OUT= WORK.&pays._RESERVE_GROUP_SPEC 
            DATAFILE= &Import. REPLACE;
     RANGE="RESERVE_GROUP_SPEC$";
RUN;
PROC IMPORT OUT= WORK.&pays._MNTHLY_BNFT_LIMITS
            DATAFILE= &Import. REPLACE;
     RANGE="MNTHLY_BNFT_LIMITS$"; 
RUN;
PROC IMPORT OUT= WORK.&pays._OTSTANDING_BLNC_LIMITS
            DATAFILE= &Import. REPLACE;
     RANGE="OTSTANDING_BLNC_LIMITS$"; 
RUN;
PROC IMPORT OUT= WORK.&pays._TRANS_TYPE_MAP
            DATAFILE= &Import. REPLACE;
     RANGE="TRANS_TYPE_MAP$"; 
RUN;

%IF &pays. = FR %THEN %DO;
PROC IMPORT OUT= WORK.&pays._SCHEME_DATABASE
            DATAFILE= &Import. REPLACE;
     RANGE="SCHEME_DATABASE$"; 
RUN;
PROC IMPORT OUT= WORK.&pays._BEN_POUC
            DATAFILE= &Import. REPLACE;
     RANGE="BEN_POUC$"; 
RUN;
%END;

%IF &pays. = UK %THEN %DO;
PROC IMPORT OUT= WORK.&pays.FIXED_BNFT_LIMITS
            DATAFILE= &Import. REPLACE;
     RANGE="FIXED_BNFT_LIMITS$";
RUN;

%END;

%ELSE %DO;
%END;
%MEND;


%Specification(pays=UK) ;
%Specification(pays=FI) ;
%Specification(pays=FR) ;
%Specification(pays=SE) ;
%Specification(pays=PT) ;
%Specification(pays=DE) ;
%Specification(pays=PL) ;
%Specification(pays=IT) ;
%Specification(pays=NO) ;
%Specification(pays=ES) ;
%Specification(pays=IE) ;
%Specification(pays=NI) ;
%Specification(pays=NL) ;
%Specification(pays=GR) ;
%Specification(pays=TR) ;
%Specification(pays=CH) ;
%Specification(pays=DK) ;
%Specification(pays=AT) ;
%Specification(pays=BE) ;
%Specification(pays=CO) ;
%Specification(pays=MX) ;
%Specification(pays=LT) ;
%Specification(pays=LV) ;
%Specification(pays=EE) ;
/*%Specification(pays=LU) ;*/