
/*#####################################################################################################################################################################################
/*##########################################################       MODUL CALCUL CASE RESERVES    ######################################################################################
/*##################################################################################################################################################################################### 

######## Name: MODUL RESERVING CLP
######## Author: ALSENY SOW 
######## Date started :26/06/2018
######## Date finished:10/07/2018
######## Context: CALCUL DES CASES RESERVES ON-SYSTEME: ICOP & RBNP

######## Name: MODUL RESERVING CLP UPDATED
######## Author: GNANISSO SARE 
######## Date started :02/01/2024
######## Date finished:05/01/2024
######## Context: CALCUL DES CASES RESERVES ON-SYSTEME: ICOP & RBNP


/*#####################################################  CREATION DES LIBRARY  ######################################################################################### */

%let LReseau = X; /* Lettre du serveur "Inventprev" attention au majuscule et minuscule*/
%LET Arrete = 2026_06_Prov ;
%let exer =Q226;

LIBNAME input "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Input";
LIBNAME CR_&exer. "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";

%LET Balancedate = '26/06/2026';


/*######### Modification � faire: */

%let month_reserving=06;
%let day_reserving=26;
%let yr_reserving=2026;
%let Input=input ;
%let Ouput=CR_Q226;


/*#########################################################################################################################################################################################
/*######################################################  MACRO DE CALCUL DES RESERVES DE TOUT LES PAYS HORS FRANCE    ####################################################################
/*######################################################################################################################################################################################### */


%Macro ACR(yr_of_calculation=,cover_typ=,pays=,guideline=,);

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Mapping Cover Initial.xlsx";
%let Import_022="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Mapping Cover Updated.xlsx";

%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);PROC IMPORT DATAFILE= &FILE. OUT= &OUT. DBMS=xlsx REPLACE ;SHEET=&ONGLET. ;RUN; %MEND;


/* REGROUPEMENT DES COUVERTURES */


%IMPORT_EXCEL(FILE=&Import_02.,OUT=Mapping_cover_1,ONGLET=Mapping_cover);
%IMPORT_EXCEL(FILE=&Import_022.,OUT=Mapping_cover_2,ONGLET=Mapping_cover);


Data &pays._CLMHDR_ALL;
length Prod_type $40.;
set &Input..&pays._CLMHDR_all;
if Rsrv_Grp in ("GD1","GL1","GR1") THEN Prod_type="Mortgage" ;
else Prod_type="Non_Mortgage" ;
run;

/*new*/
proc sql;
     create table &pays._CLMHDR_ALL as
     select t1.*, t2.Cover
     from &pays._CLMHDR_ALL t1
     %if &pays. = GR or &pays. = SE  or &pays. = NO or &pays. = IT %then %do;
         left join MAPPING_COVER_2 t2
     %end;
     %else %do;
        left join MAPPING_COVER_1 t2
     %end;
     on t1.Cvr_Typ = t2.Cvr_Typ;
quit;

/*old*/
/*Proc SQL; Create Table &pays._CLMHDR_ALL As
Select distinct t1.*,t2.Cover
From &pays._CLMHDR_ALL t1 Left Join  MAPPING_COVER_1 t2 on (t1.Cvr_Typ = t2.Cvr_Typ)  
;
quit;*/


Data &pays._CLMHDR_ALL;
set &pays._CLMHDR_ALL;
if Country="SE" and Cvr_Typ in ("DK") then Cover="DIS" ; 
run;

Proc SQL; Create Table Reserves_all_&pays._V&yr_of_calculation. As
Select distinct t1.*
From &pays._CLMHDR_ALL t1 
where  t1.cover="&cover_typ." and t1.Rsrv_Grp not in ("ZZ1","ZZ2")  
;
Quit;

/*  RECUPERATION DE LA DERNIERE DATE DE TRANSACTION POUR CHAQUE CLAIMS  */

PROC SQL;
		CREATE TABLE &pays._FIRSTLASTBENEFIT as 
		SELECT Clm_Nmbr,

				
				case when day(min(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(min(Trns_Dt))=12 then Year(min(Trns_Dt)) else Year(min(Trns_Dt)) end 
				else Year(min(Trns_Dt)) end as Frst_Bnft_Pd_Yr,

				case when day(min(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(min(Trns_Dt))=12 then 1 else Month(min(Trns_Dt)) end 
				else Month(min(Trns_Dt)) end as Frst_Bnft_Pd_Mnth,

                case when day(min(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(min(Trns_Dt))=12 then 1 else day(min(Trns_Dt)) end 
				else day(min(Trns_Dt)) end as Frst_Bnft_Pd_Dy,


				case when day(max(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(max(Trns_Dt))=12 then Year(max(Trns_Dt)) else Year(max(Trns_Dt))end 
				else Year(max(Trns_Dt)) end as latst_Bnft_Pd_Yr,

				case when day(max(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(max(Trns_Dt))=12 then 1 else Month(max(Trns_Dt)) end 
				else Month(max(Trns_Dt)) end as latst_Bnft_Pd_Mnth,

                case when day(max(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(max(Trns_Dt))=12 then day(max(Trns_Dt)) else day(max(Trns_Dt))end 
				else day(max(Trns_Dt)) end as latst_Bnft_Pd_Dy

		FROM INPUT.&pays._CLMTRNS_ALL
		WHERE Amt>1 AND Trns_Type ne "O"
		GROUP BY Clm_Nmbr
		;
QUIT;


data CLMTRNS_samp_all_&pays._V&yr_of_calculation. ;
keep country clm_nmbr trns_dt ;
FORMAT trns_dt DDMMYY10. ;
set &pays._FIRSTLASTBENEFIT;
trns_dt = mdy(latst_Bnft_Pd_Mnth, latst_Bnft_Pd_Dy, latst_Bnft_Pd_Yr) ;
run;


/*  CLASSIFICATION DES CLAIMS PAR TYPE DE RESERVE:ICOP ET RBNP */

Data Reserves_all_&cover_typ._&pays._V&yr_of_calculation.;
length Rsrv_Typ $40.;
FORMAT Date_of_reserving DDMMYY10. ;
length Rsrv_Typ $40.;
set Reserves_all_&pays._V&yr_of_calculation.;
Date_of_reserving = mdy(&month_reserving., &day_reserving., &yr_reserving.) ;
if Totl_Bnfts_Amnt_Pd=. then Totl_Bnfts_Amnt_Pd=0;
if Mnthly_Bnft=. then Mnthly_Bnft=0;
if Otstndng_Balnc=. then Otstndng_Balnc=0;
Age_surv=int(yrdif(Dt_of_Brth,Accdnt_Dt,ACTUAL)) ;
drop  ACTUAL;

/*  Cas des claims CL et DC */

if Rsrv_Grp not in ("ZZ1","ZZ2")     AND STATUS in ("CL","DC")     then Rsrv_Typ = "CLOSE";
if Rsrv_Grp in     ("ZZ1","ZZ2")     AND STATUS in ("CL","DC")     then Rsrv_Typ = "NON-CORE CLOSE";

/*  Cas des claims OP et RO */

if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and first_pd_date <=Date_of_reserving and Totl_Bnfts_Amnt_Pd > 1 then Rsrv_Typ = "ICOP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and first_pd_date < Date_of_reserving and Totl_Bnfts_Amnt_Pd < 1 then Rsrv_Typ = "RBNP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and first_pd_date > Date_of_reserving then Rsrv_Typ = "RBNP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and Totl_Bnfts_Amnt_Pd = 0 then Rsrv_Typ = "RBNP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and cover in ("CI","LIFE","PTD","GAP") and Totl_Bnfts_Amnt_Pd > 0  then Rsrv_Typ = "RBNP";
if Rsrv_Grp in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") then Rsrv_Typ = "NON-CORE OPEN";
run ;

/* CALCUL DE L'AGE MOYEN PAR COUNTRY & COVER */

PROC SQL;
		CREATE TABLE AGE_ACCDT_AVRG_&cover_typ._&pays as 
		SELECT h.Country, h.Cover as Cover, int(MEAN(h.Age_surv)) as AVG_AGE
		FROM Reserves_all_&cover_typ._&pays._V&yr_of_calculation. h
		GROUP BY h.Country, h.Cover;
QUIT;


Proc SQL; Create Table Reserves_all_&cover_typ._&pays._V&yr_of_calculation. As
Select distinct t1.*,t2.trns_dt
From Reserves_all_&cover_typ._&pays._V&yr_of_calculation. t1 Left Join  CLMTRNS_samp_all_&pays._V&yr_of_calculation. t2 on (t1.Clm_Nmbr = t2.Clm_Nmbr);
Quit;

Proc SQL; Create Table Reserves_all_&cover_typ._&pays._V&yr_of_calculation. As
Select distinct t1.*,t2.AVG_AGE
From Reserves_all_&cover_typ._&pays._V&yr_of_calculation. t1 Left Join  AGE_ACCDT_AVRG_&cover_typ._&pays t2 on (t1.Cover = t2.Cover);
Quit;

Proc sort data=Reserves_all_&cover_typ._&pays._V&yr_of_calculation. ; by clm_nmbr; run;

data Reserves_all_&cover_typ._&pays._V&yr_of_calculation.;
set Reserves_all_&cover_typ._&pays._V&yr_of_calculation. ;

/*  Calcul des variables : Nmbr_Mnths_Pndng, Mnths_lag & Nmbr_Bnfts_Pd   */

if Rsrv_Typ = "RBNP" then  Nmbr_Mnths_Pndng=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;   /*  nb de mois �coul� entre la date d'enregistrement et la date de  calcul */
if Rsrv_Typ = "ICOP" then  Mnths_lag=((year(Date_of_reserving )-year(trns_dt))*12 + (month(Date_of_reserving)-month(trns_dt)));;                 /*  nb de mois �coul� entre la date de la derni�re transaction et la date de  calcul */
if Rsrv_Typ = "RBNP" then  Mnths_lag=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;
if Rsrv_Typ = "ICOP" then  Nmbr_Mnths_Pndng=0;
if Rsrv_Typ not in ("ICOP","RBNP") then  Nmbr_Mnths_Pndng=0;
if Rsrv_Typ not in ("ICOP","RBNP") then  Mnths_lag=0;  

if Rsrv_Typ = "RBNP" then  Nmbr_Mnths_Pndng2=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;   /*  nb de mois �coul� entre la date d'enregistrement et la date de  vision */
if Rsrv_Typ = "ICOP" then  Mnths_lag2=((year(Date_of_reserving )-year(trns_dt))*12 + (month(Date_of_reserving)-month(trns_dt)));;
if Rsrv_Typ = "RBNP" then  Mnths_lag2=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;
if Rsrv_Typ = "ICOP" then  Nmbr_Mnths_Pndng2=0;
if Rsrv_Typ not in ("ICOP","RBNP") then  Nmbr_Mnths_Pndng2=0;
if Rsrv_Typ  not in ("ICOP","RBNP") then  Mnths_lag2=0; 

if Rsrv_Typ = "ICOP" then Nmbr_Bnfts_Pd=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Rsrv_Typ = "ICOP" then Nmbr_Bnfts_Pd2=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Rsrv_Typ = "RBNP" then Nmbr_Bnfts_Pd=0 ;
if Rsrv_Typ = "RBNP" then Nmbr_Bnfts_Pd2=0 ;
if Rsrv_Typ = "CLOSE" then Nmbr_Bnfts_Pd=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Rsrv_Typ = "CLOSE" then Nmbr_Bnfts_Pd2=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Nmbr_Bnfts_Pd=. then Nmbr_Bnfts_Pd=0;
if Nmbr_Bnfts_Pd2=. then Nmbr_Bnfts_Pd2=0;
run;

/* CORRECTION DE L'AGE ET DU SEXE MANQUANT */

data Reserves_&cover_typ._&pays._V&yr_of_calculation._F;
set Reserves_all_&cover_typ._&pays._V&yr_of_calculation. ;
if  Gndr ="" then Gndr="M";
if  Gndr ="X" then Gndr="M";
if  Age_surv in (.,0) then Age_surv=AVG_AGE;
if  Age_surv <= 0 then Age_surv=AVG_AGE;
if  potential_clm_amt=0 then potential_clm_amt=0;
if  Otstndng_Balnc=0 then Otstndng_Balnc=0;
if  Mnthly_Bnft=0 then Mnthly_Bnft=0;
if Nmbr_Mnths_Pndng > 12 then Nmbr_Mnths_Pndng=12;
if Mnths_lag > 12 then Mnths_lag=12;
if Nmbr_Bnfts_Pd > 60 then Nmbr_Bnfts_Pd=60 ;
if cover="IU" and Age_surv > 80 then Age_surv =70 ;
if cover in ("DIS","LIFE","CI","PTD","GAP") and Age_surv > 100 then Age_surv =100 ;
run;


/*  IMPORTATION DES TABLES DE DURATION ET D'ACCEPTATION */


%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Reserving tables/&cover_typ./Tables_&pays._&cover_typ..xlsx";

%IF &cover_typ.=IU or &cover_typ.=DIS %THEN %DO;

%IMPORT_EXCEL(FILE=&Import_01.,OUT=Table_duration_&cover_typ._&pays.,ONGLET=Duration);
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Table_acceptation_&cover_typ._&pays.,ONGLET=Acceptation);

/*  MISE EN FORME DES FACTEURS DE LA TABLE DURATION ET DE LA TABLE ACCEPTATION */

data TABLE_DURATION_&cover_typ._&pays.;set TABLE_DURATION_&cover_typ._&pays.;run;

data facteur_age_D;keep Age_surv factor_age_D;set TABLE_DURATION_&cover_typ._&pays.;run;

data facteur_gender_D;keep Gndr factor_sexe_D Intercept_D;set TABLE_DURATION_&cover_typ._&pays.;run;

data facteur_Number_D;keep Nmbr_Bnfts_Pd factor_numbr_D;set TABLE_DURATION_&cover_typ._&pays.;run;

data facteur_Inactivity_D;keep Mnths_lag factor_lag_D ;set TABLE_DURATION_&cover_typ._&pays.;run;

data facteur_MAX_D;keep Max_Nmbr_Bnfts factor_max_D ;set TABLE_DURATION_&cover_typ._&pays.;run;

data TABLE_ACCEPTATION_&cover_typ._&pays.;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

data facteur_age_A;keep Age_surv factor_age_A;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

data facteur_gender_A;keep Gndr factor_sexe_A Intercept_A;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

data facteur_Waiting_A;keep Nmbr_Mnths_Pndng factor_month_A ;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

%END;

%IF &cover_typ.=LIFE or &cover_typ.=CI or &cover_typ.=PTD or &cover_typ.=GAP %THEN %DO;

%IMPORT_EXCEL(FILE=&Import_01.,OUT=Table_acceptation_&cover_typ._&pays.,ONGLET=Acceptation);

/*  MISE EN FORME DES FACTEURS DE LA TABLE ACCEPTATION */

data TABLE_ACCEPTATION_&cover_typ._&pays.;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

data facteur_age_A;keep Age_surv factor_age_A;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

data facteur_gender_A;keep Gndr factor_sexe_A Intercept_A;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

data facteur_Waiting_A;keep Nmbr_Mnths_Pndng factor_month_A ;set TABLE_ACCEPTATION_&cover_typ._&pays.;run;

%END;


/*  MERGE DES FACTEURS DE LA TABLE DURATION ET DE TABLE ACCEPTATION */


%IF &cover_typ.=IU or &cover_typ.=DIS %THEN %DO;


Proc SQL; Create Table Reserves_&cover_typ._&pays._V&yr_of_calculation._F As
Select distinct t1.*,t2.factor_age_D,t3.factor_numbr_D,t4.factor_max_D,t5.factor_sexe_D,t5.Intercept_D,t6.factor_lag_D,t7.factor_age_A,t8.factor_sexe_A,t8.Intercept_A,t9.factor_month_A
From Reserves_&cover_typ._&pays._V&yr_of_calculation._F t1 Left Join  facteur_age_D t2    on (t1.Age_surv = t2.Age_surv)
                                                           Left Join  facteur_Number_D t3 on (t1.Nmbr_Bnfts_Pd = t3.Nmbr_Bnfts_Pd)
                                                           Left Join  facteur_Max_D t4    on (t1.Max_Nmbr_Bnfts = t4.Max_Nmbr_Bnfts)
                                                           Left Join  facteur_gender_D t5 on (t1.Gndr = t5.Gndr)
                                                           Left Join  facteur_Inactivity_D t6 on (t1.Mnths_lag = t6.Mnths_lag)
                                                           Left Join  FACTEUR_AGE_A t7 on (t1.Age_surv = t7.Age_surv)
                                                           Left Join  FACTEUR_GENDER_A t8 on (t1.Gndr = t8.Gndr)
                                                           Left Join  FACTEUR_WAITING_A t9 on (t1.Nmbr_Mnths_Pndng = t9.Nmbr_Mnths_Pndng)
           
;
Quit;

%END;

%IF &cover_typ.=LIFE or &cover_typ.=CI or &cover_typ.=PTD or &cover_typ.=GAP %THEN %DO;

Proc SQL; Create Table Reserves_&cover_typ._&pays._V&yr_of_calculation._F As
Select distinct t1.*,0 as factor_age_D,0 as factor_numbr_D,0 as factor_max_D,0 as factor_sexe_D,0 as Intercept_D,0 as factor_lag_D,t7.factor_age_A,t8.factor_sexe_A,t8.Intercept_A,t9.factor_month_A
From Reserves_&cover_typ._&pays._V&yr_of_calculation._F t1 Left Join  FACTEUR_AGE_A t7 on (t1.Age_surv = t7.Age_surv)
                                                           Left Join  FACTEUR_GENDER_A t8 on (t1.Gndr = t8.Gndr)
                                                           Left Join  FACTEUR_WAITING_A t9 on (t1.Nmbr_Mnths_Pndng = t9.Nmbr_Mnths_Pndng)
           
;
Quit;

%END;

/*  CALCUL DE LA PROBABILITE D'ACCEPTATION ET DU NOMBRE DE BENEFIT OUSTANDING */

data CLMHDR_&cover_typ._&pays._V&yr_of_calculation.;
set Reserves_&cover_typ._&pays._V&yr_of_calculation._F ;

%IF &cover_typ.=IU or &cover_typ.=DIS %THEN %DO;

if Rsrv_Typ = "ICOP" then Nmbr_Bnfts_Otstndng=exp(Intercept_D + factor_age_D + factor_sexe_D + factor_max_D+ factor_numbr_D + factor_lag_D);
if Rsrv_Typ = "RBNP" then Nmbr_Bnfts_Otstndng=exp(Intercept_D + factor_age_D + factor_sexe_D + factor_max_D+ factor_numbr_D + factor_lag_D);
if Rsrv_Typ = "RBNP" then Probablty_Otstndng=exp(Intercept_A + factor_age_A + factor_sexe_A + factor_month_A)/(1+exp(Intercept_A+factor_age_A +factor_sexe_A+ factor_month_A));
if Rsrv_Typ in ("CLOSE","NON-CORE OPEN","NON-CORE CLOSE") then Nmbr_Bnfts_Otstndng=0;
if Rsrv_Typ in ("CLOSE","ICOP","NON-CORE OPEN","NON-CORE CLOSE") then Probablty_Otstndng=0;

/*  CALCUL DES RESERVES */

if Rsrv_Typ = "ICOP" and cover in ("IU","DIS") then Rsrv_Amt=Mnthly_Bnft*Nmbr_Bnfts_Otstndng;
if Rsrv_Typ = "RBNP" and cover in ("IU","DIS") then Rsrv_Amt=Probablty_Otstndng*Mnthly_Bnft*Nmbr_Bnfts_Otstndng;
if Rsrv_Typ not in ("ICOP","RBNP") then Rsrv_Amt=0;

%END;

%IF &cover_typ.=LIFE or &cover_typ.=CI or &cover_typ.=PTD or &cover_typ.=GAP %THEN %DO;

Nmbr_Bnfts_Otstndng=0 ;
if Rsrv_Typ = "RBNP" then Probablty_Otstndng=exp(Intercept_A + factor_age_A + factor_sexe_A + factor_month_A)/(1+exp(Intercept_A+factor_age_A +factor_sexe_A+ factor_month_A));
if Rsrv_Typ = "ICOP" then Probablty_Otstndng=0;
if Rsrv_Typ  not in ("RBNP") then Probablty_Otstndng=0;

/*  CALCUL DES RESERVES */

if Rsrv_Typ = "RBNP" and cover in ("CI","LIFE","PTD") then Rsrv_Amt=Probablty_Otstndng*Otstndng_Balnc ;
if Rsrv_Typ = "RBNP" and cover in ("GAP") then Rsrv_Amt=Probablty_Otstndng*potential_clm_amt ;
if Rsrv_Typ  not in ("ICOP","RBNP") then Rsrv_Amt=0;
if Rsrv_Grp in ("ZZ1","ZZ2") then Rsrv_Amt=0;

%END;

/* AUTO CLOSE SUR LE CALCUL DES RESERVES */
/**/
/*if Rsrv_Typ = "ICOP"  and Nmbr_Bnfts_Pd > MAX(Max_Nmbr_Bnfts,&guideline.) then Rsrv_Amt=0;*/
/*if Rsrv_Typ = "ICOP"  and Mnths_lag2 > &guideline. then Rsrv_Amt=0;*/
/*if Rsrv_Typ = "RBNP"  and Nmbr_Mnths_Pndng2 > &guideline. then Rsrv_Amt=0;*/

rename Nmbr_Mnths_Pndng2 =Nmbr_Mnths_Pndng
       Nmbr_Bnfts_Pd2=Nmbr_Bnfts_Pd
;
run;

PROC SQL;
		CREATE TABLE CLMHDR_&cover_typ._&pays._V&yr_of_calculation. as 
		SELECT distinct 
		 Date_of_reserving,		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Policy_Line_No,
		 Policy_Line_Seq_No,
		 Cvr_Typ,
		 cover,
		 Schm,
		 Accdnt_Dt,
		 Acc_yr,
		 Acc_Mnth,
		 Rgstrtn_Dt,
		 Rgstrtn_Yr,
		 Rgstrtn_Mnth,
		 Cls_Dt,
		 STATUS,
		 potential_clm_amt,
		 Otstndng_Balnc,
		 Undrwrtng_Cmpny,
		 Max_Nmbr_Bnfts,
		 Expry_dt,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Frst_Bnft_Pd_Yr,
		 Frst_Bnft_Pd_Mnth,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Incptn_Dt,
		 Insrnc_Trm,
		 Mnthly_Bnft,
		 Prdct,
		 Gndr,
		 Dt_of_Brth,
		 Nmbr_Mnths_Pndng,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Probablty_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type,
		 Legal_Entity 
		FROM CLMHDR_&cover_typ._&pays._V&yr_of_calculation. 
		GROUP BY Clm_Nmbr ;
QUIT;



%MEND;


/*#################################################################  MACRO DE CONCATENATION DE TOUTES LES COUVERTURES ######################################################################################### */


%Macro fusion(pays=,yr_of_calculation=,);

/*%let yr_of_calculation=2021 ;
%let pays=SE ;*/

/* FILTRE SUR LES COUVERTURES NON-CORE HORS CASE RESERVES */

Data CLMHDR_Hors_p_&pays._V&yr_of_calculation.;
FORMAT Date_of_reserving DDMMYY10. ;
length Rsrv_Typ $40.;
set &pays._CLMHDR_ALL ;
where Rsrv_Grp  in ("ZZ1","ZZ2");
if Rsrv_Grp in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") then Rsrv_Typ = "NON-CORE OPEN";
if Rsrv_Grp in ("ZZ1","ZZ2") AND STATUS in ("CL","DC") then Rsrv_Typ = "NON-CORE CLOSE";
Date_of_reserving = mdy(&month_reserving., &day_reserving., &yr_reserving.) ;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Nmbr_Mnths_Pndng=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Pd=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Otstndng=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Probablty_Otstndng=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Rsrv_Amt=0;
run;



PROC SQL;
		CREATE TABLE CLMHDR_Hors_p_&pays._V&yr_of_calculation. as 
		SELECT distinct 
		 Date_of_reserving ,		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Policy_Line_No,
		 Policy_Line_Seq_No,
		 Cvr_Typ,
		 cover,
		 Schm,
		 Accdnt_Dt,
		 Acc_yr,
		 Acc_Mnth,
		 Rgstrtn_Dt,
		 Rgstrtn_Yr,
		 Rgstrtn_Mnth,
		 Cls_Dt,
		 STATUS,
		 potential_clm_amt,
		 Otstndng_Balnc,
		 Undrwrtng_Cmpny,
		 Max_Nmbr_Bnfts,
		 Expry_dt,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Frst_Bnft_Pd_Yr,
		 Frst_Bnft_Pd_Mnth,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Incptn_Dt,
		 Insrnc_Trm,
		 Mnthly_Bnft,
		 Prdct,
		 Gndr,
		 Dt_of_Brth,
		 Nmbr_Mnths_Pndng,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Probablty_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type,
		 Legal_Entity 
		FROM CLMHDR_Hors_p_&pays._V&yr_of_calculation.
		GROUP BY Clm_Nmbr ;
QUIT;


/* FUSION DES COUVERTURES: CREATION DE LA BASE CLMHDR  */

data CLMHDR_all_&pays.;
set  CLMHDR_IU_&pays._V&yr_of_calculation.
     CLMHDR_DIS_&pays._V&yr_of_calculation.
     CLMHDR_LIFE_&pays._V&yr_of_calculation.
     CLMHDR_PTD_&pays._V&yr_of_calculation.
     CLMHDR_CI_&pays._V&yr_of_calculation.
     CLMHDR_GAP_&pays._V&yr_of_calculation.
     CLMHDR_Hors_p_&pays._V&yr_of_calculation.
;

run;

proc sort data=CLMHDR_all_&pays. nodupkey out=CLMHDR_all_&pays.;  by Clm_Nmbr Policy_Line_No Policy_Line_Seq_No Schm Cvr_Typ; run;


PROC SQL;
		CREATE TABLE &Ouput..CLMHDR_all_&pays. as 
		SELECT 
		 Date_of_reserving,		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Policy_Line_No,
		 Policy_Line_Seq_No,
		 Cvr_Typ,
		 cover,
		 Schm,
		 Accdnt_Dt,
		 Acc_yr,
		 Acc_Mnth,
		 Rgstrtn_Dt,
		 Rgstrtn_Yr,
		 Rgstrtn_Mnth,
		 Cls_Dt,
		 STATUS,
		 potential_clm_amt,
		 Otstndng_Balnc,
		 Undrwrtng_Cmpny,
		 Max_Nmbr_Bnfts,
		 Expry_dt,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Frst_Bnft_Pd_Yr,
		 Frst_Bnft_Pd_Mnth,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Incptn_Dt,
		 Insrnc_Trm,
		 Mnthly_Bnft,
		 Prdct,
		 Gndr,
		 Dt_of_Brth,
		 Nmbr_Mnths_Pndng,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Probablty_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type,
		 Legal_Entity 
		FROM CLMHDR_all_&pays. 
		GROUP BY Clm_Nmbr ;
QUIT;


/* CREATION DE LA BSE CLMHDR POUR LE DATA LAKE */

PROC SQL;
		CREATE TABLE CLMHDR_all_&pays._CR as 
		SELECT 		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Schm as SCHEME ,
		 Cvr_Typ as cover,
		 Undrwrtng_Cmpny as Entity_CD,
		 Legal_Entity as Entity,
		 Accdnt_Dt as Incident_date,
		 Rgstrtn_Dt,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 year(Incptn_Dt) as Vintage_year,
		 Date_of_reserving,
		 STATUS,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Probablty_Otstndng as Probablty_Accptd,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type
		 
		FROM &Ouput..CLMHDR_all_&pays. 
		
		GROUP BY Clm_Nmbr ;
QUIT;

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Reassurance.xlsx";


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE 
;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=Parametres_Reas,ONGLET=Parametres_Reas);

data Parametres_Reas ;
set Parametres_Reas;
y_char = compress(put(Original_underwritter,21.0));
drop Original_underwritter; rename y_char = Original_underwritter;
run;



proc sql ; 
create table CLMHDR_all_&pays._CR as
select distinct
t1.*,
t8.QP_rei_CLAIM AS QP_rei_CLAIM 
from CLMHDR_all_&pays._CR  t1 
left join Parametres_Reas t8 on (t1.country=t8.country AND t1.scheme=t8.scheme AND t1.cover=t8.cover AND t1.Entity_CD=t8.Original_underwritter) 
 ;
quit ; 


data CLMHDR_all_&pays._CR;
set CLMHDR_all_&pays._CR ;

if QP_rei_CLAIM=. then Type_Insurance=0 ;
if QP_rei_CLAIM NOT IN (.) then Type_Insurance=4 ;

if Rsrv_Grp in ("ZZ1","ZZ2") then Rsrv_Amt=0; 
if Rsrv_Grp in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Otstndng=0;
if Rsrv_Grp in ("ZZ1","ZZ2") then Probablty_Accptd =0;
if Rsrv_Grp in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Pd =0;

rename Rsrv_Amt=Rsrv_Amt_Gross 
       Totl_Bnfts_Amnt_Pd=Totl_Bnfts_Amnt_Pd_Gross
       Totl_Amnt_Pd=Totl_Amnt_Pd_Gross
;

if Type_Insurance=0 then QP_rei_CLAIM=1; 

run;


data CLMHDR_all_&pays._CR;
set CLMHDR_all_&pays._CR ;
Rsrv_Amt_Net= Rsrv_Amt_Gross*QP_rei_CLAIM;
Totl_Amnt_Pd_Net=Totl_Amnt_Pd_Gross*QP_rei_CLAIM;
Totl_Bnfts_Amnt_Pd_Net=Totl_Bnfts_Amnt_Pd_Gross*QP_rei_CLAIM;
run ;

PROC SQL;
		CREATE TABLE &Ouput..CLMHDR_all_&pays._CR as 
		SELECT 		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Type_Insurance,
		 SCHEME ,
		 cover,
		 Entity_CD,
		 Entity,
		 Incident_date,
		 Rgstrtn_Dt,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Vintage_year,
		 Date_of_reserving,
		 STATUS,
		 Totl_Amnt_Pd_Gross,
		 Totl_Amnt_Pd_Net,
		 Totl_Bnfts_Amnt_Pd_Gross,
		 Totl_Bnfts_Amnt_Pd_Net,
		 Probablty_Accptd,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt_Gross,
		 Rsrv_Amt_Net,
		 informer_type
		 		 
		FROM CLMHDR_all_&pays._CR 
		
		GROUP BY Clm_Nmbr ;
QUIT;

/*proc datasets lib=work memtype=DATA;   delete CLMHDR_all_&pays._CR ;      run;
proc datasets lib=work memtype=DATA;   delete CLMHDR_all_&pays.  ;      run;
proc datasets lib=work memtype=DATA;   delete CLMHDR_&cover_typ._&pays._V&yr_of_calculation.;      run;
proc datasets lib=work memtype=DATA;   delete &pays._FIRSTLASTBENEFIT ;      run;

proc datasets lib=work memtype=DATA;   delete &pays._CLMHDR_ALL ;      run;
proc datasets lib=work memtype=DATA;   delete Reserves_all_&pays._V&yr_of_calculation.  ;      run;
proc datasets lib=work memtype=DATA;   delete Reserves_&cover_typ._&pays._V&yr_of_calculation._F;      run;
proc datasets lib=work memtype=DATA;   delete &pays._FIRSTLASTBENEFIT ;      run;
*/
 

%MEND ;


                         /* GERMANY */ 

%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=DE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=DE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=DE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=DE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=DE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=DE,guideline=12) ;
%fusion(pays=DE,yr_of_calculation=&yr_reserving.) ;

                         /* DENMARK */  
                                            
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=DK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=DK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=DK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=DK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=DK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=DK,guideline=12) ;
%fusion(pays=DK,yr_of_calculation=&yr_reserving.) ;


                      /* SWITZERLAND */  
                                         
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=CH,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=CH,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=CH,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=CH,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=CH,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=CH,guideline=12) ;
%fusion(pays=CH,yr_of_calculation=&yr_reserving.) ;



                         /* NORWAY */   
                                           
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=NO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=NO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=NO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=NO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=NO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=NO,guideline=12) ;
%fusion(pays=NO,yr_of_calculation=&yr_reserving.) ;

  
                       /* FINLAND*/ 
                                          
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=FI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=FI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=FI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=FI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=FI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=FI,guideline=12) ;
%fusion(pays=FI,yr_of_calculation=&yr_reserving.) ;


     
                     /* SWEDEN */  
     
                                            
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=SE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=SE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=SE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=SE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=SE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=SE,guideline=12) ;
%fusion(pays=SE,yr_of_calculation=&yr_reserving.) ;



                         /* SPAIN */   
                                          
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=ES,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=ES,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=ES,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=ES,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=ES,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=ES,guideline=12) ;
%fusion(pays=ES,yr_of_calculation=&yr_reserving.) ;

                         /* POLAND */ 
                                           
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=PL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=PL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=PL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=PL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=PL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=PL,guideline=12) ;
%fusion(pays=PL,yr_of_calculation=&yr_reserving.) ;



                        /* UK */  
                                           
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=UK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=UK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=UK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=UK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=UK,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=UK,guideline=12) ;
%fusion(pays=UK,yr_of_calculation=&yr_reserving.) ;

                        /* ITALY */
                        
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=IT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=IT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=IT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=IT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=IT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=IT,guideline=12) ;
%fusion(pays=IT,yr_of_calculation=&yr_reserving.) ;

                       /* PORTUGAL */  
                                          
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=PT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=PT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=PT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=PT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=PT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=PT,guideline=12) ;
%fusion(pays=PT,yr_of_calculation=&yr_reserving.) ;


                       /* IRELAND */   
                                          
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=IE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=IE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=IE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=IE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=IE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=IE,guideline=12) ;
%fusion(pays=IE,yr_of_calculation=&yr_reserving.) ;


                       /* GREECE */  
                                         
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=GR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=GR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=GR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=GR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=GR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=GR,guideline=12) ;
%fusion(pays=GR,yr_of_calculation=&yr_reserving.) ;

/**********Traitements sur la gr�ce suite � une demande de reduire les r�serves � Z�ro***************************/

data &Ouput..CLMHDR_all_GR_CR;
    set &Ouput..CLMHDR_all_GR_CR;
    if Country = "GR" and SCHEME in ("BP3.3", "BP3.4", "BP5.3", "BP5.4", "BP7.3", "BP7.4") then do;
        Rsrv_Amt_Gross = 0;
        Rsrv_Amt_Net = 0;
    end;
run;

data &Ouput..CLMHDR_all_GR;
    set &Ouput..CLMHDR_all_GR;
    if Country = "GR" and Schm in ("BP3.3", "BP3.4", "BP5.3", "BP5.4", "BP7.3", "BP7.4") then Rsrv_Amt = 0;
run;
/*******************************************************************************************************************/



                         /* NETHERLAND */ 
                                        
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=NL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=NL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=NL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=NL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=NL,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=NL,guideline=12) ;
%fusion(pays=NL,yr_of_calculation=&yr_reserving.) ;

                        /* NORTHEN IRELAND */ 
                                         
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=NI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=NI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=NI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=NI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=NI,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=NI,guideline=12) ;
%fusion(pays=NI,yr_of_calculation=&yr_reserving.) ;

                        /* TURKEY */   
                                           
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=TR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=TR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=TR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=TR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=TR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=TR,guideline=12) ;
%fusion(pays=TR,yr_of_calculation=&yr_reserving.) ;





/*#################################################################################################################################################################################
/*######################################################  Macro CALCUL DES RESERVES PAR COUVERTURE : FRANCE    ########################################################################################
/*################################################################################################################################################################################ */


%Macro ACR_FR(yr_of_calculation=,cover_typ=,pays=,prod=,guideline=,type_prod=,);

/*  REGROUPEMENT DES COUVERTURES  */

/*%let pays=FR ;*/

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Mapping Cover Initial.xlsx";

%IMPORT_EXCEL(FILE=&Import_02.,OUT=Mapping_cover_1,ONGLET=Mapping_cover);

Data &pays._CLMHDR_ALL;
length Prod_type $40.;
set &Input..&pays._CLMHDR_all;
if Rsrv_Grp in ("GD1","GL1","GR1") THEN Prod_type="Mortgage" ;
else Prod_type="Non_Mortgage" ;
run;

Proc SQL; Create Table &pays._CLMHDR_ALL As
Select  t1.*,t2.Cover
From &pays._CLMHDR_ALL t1 Left Join  MAPPING_COVER_1 t2 on (t1.Cvr_Typ = t2.Cvr_Typ)  
;
Quit;

Proc SQL; Create Table Reserves_all_&pays._V&yr_of_calculation. As
Select distinct t1.*
From &pays._CLMHDR_ALL t1 
where  t1.cover="&cover_typ." and t1.Prod_type="&Prod." and t1.Rsrv_Grp not in ("ZZ1","ZZ2")  
;
Quit;

/*  RECUPERATION DE LA DERNIERE DATE DE TRANSACTION POUR CHAQUE CLAIMS  */

PROC SQL;
		CREATE TABLE &pays._FIRSTLASTBENEFIT as 
		SELECT Clm_Nmbr,

				
				case when day(min(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(min(Trns_Dt))=12 then Year(min(Trns_Dt)) else Year(min(Trns_Dt)) end 
				else Year(min(Trns_Dt)) end as Frst_Bnft_Pd_Yr,

				case when day(min(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(min(Trns_Dt))=12 then 1 else Month(min(Trns_Dt)) end 
				else Month(min(Trns_Dt)) end as Frst_Bnft_Pd_Mnth,

                case when day(min(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(min(Trns_Dt))=12 then 1 else day(min(Trns_Dt)) end 
				else day(min(Trns_Dt)) end as Frst_Bnft_Pd_Dy,


				case when day(max(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(max(Trns_Dt))=12 then Year(max(Trns_Dt)) else Year(max(Trns_Dt))end 
				else Year(max(Trns_Dt)) end as latst_Bnft_Pd_Yr,

				case when day(max(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(max(Trns_Dt))=12 then 1 else Month(max(Trns_Dt)) end 
				else Month(max(Trns_Dt)) end as latst_Bnft_Pd_Mnth,

                case when day(max(Trns_Dt))>Day(input(&Balancedate.,ddmmyy10.)) then case 
				when Month(max(Trns_Dt))=12 then day(max(Trns_Dt)) else day(max(Trns_Dt))end 
				else day(max(Trns_Dt)) end as latst_Bnft_Pd_Dy

		FROM INPUT.&pays._CLMTRNS_ALL
		WHERE Amt>1 AND Trns_Type ne "O"
		GROUP BY Clm_Nmbr
		;
QUIT;


data CLMTRNS_samp_all_&pays._V&yr_of_calculation. ;
keep country clm_nmbr trns_dt ;
FORMAT trns_dt DDMMYY10. ;
set &pays._FIRSTLASTBENEFIT;
trns_dt = mdy(latst_Bnft_Pd_Mnth, latst_Bnft_Pd_Dy, latst_Bnft_Pd_Yr) ;
run;


/*  CLASSIFICATION DES CLAIMS PAR TYPE DE RESERVE:ICOP ET RBNP */

Data Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation.;
length Rsrv_Typ $40.;
FORMAT Date_of_reserving DDMMYY10. ;
length Rsrv_Typ $40.;
set Reserves_all_&pays._V&yr_of_calculation.;
Date_of_reserving = mdy(&month_reserving., &day_reserving., &yr_reserving.) ;
if Totl_Bnfts_Amnt_Pd=. then Totl_Bnfts_Amnt_Pd=0;
if Mnthly_Bnft=. then Mnthly_Bnft=0;
if Otstndng_Balnc=. then Otstndng_Balnc=0;
Age_surv=int(yrdif(Dt_of_Brth,Accdnt_Dt,ACTUAL)) ;
drop  ACTUAL;

/*  Cas des claims CL et DC */

if Rsrv_Grp not in ("ZZ1","ZZ2")     AND STATUS in ("CL","DC")     then Rsrv_Typ = "CLOSE";
if Rsrv_Grp in     ("ZZ1","ZZ2")     AND STATUS in ("CL","DC")     then Rsrv_Typ = "NON-CORE CLOSE";

/*  Cas des claims OP et RO */

if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and first_pd_date <=Date_of_reserving and Totl_Bnfts_Amnt_Pd > 1 then Rsrv_Typ = "ICOP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and first_pd_date < Date_of_reserving and Totl_Bnfts_Amnt_Pd < 1 then Rsrv_Typ = "RBNP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and first_pd_date > Date_of_reserving then Rsrv_Typ = "RBNP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and Totl_Bnfts_Amnt_Pd = 0 then Rsrv_Typ = "RBNP";
if Rsrv_Grp not in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") and cover in ("CI","LIFE","PTD","GAP") and Totl_Bnfts_Amnt_Pd > 0  then Rsrv_Typ = "RBNP";
if Rsrv_Grp in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") then Rsrv_Typ = "NON-CORE OPEN";
run ;

/* CALCUL DE L'AGE MOYEN PAR COUNTRY & COVER */

PROC SQL;
		CREATE TABLE AGE_ACCDT_AVRG_&cover_typ._&type_prod._&pays as 
		SELECT h.Country, h.Cover as Cover, int(MEAN(h.Age_surv)) as AVG_AGE
		FROM Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. h
		GROUP BY h.Country, h.Cover;
QUIT;


Proc SQL; Create Table Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. As
Select distinct t1.*,t2.trns_dt
From Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. t1 Left Join  CLMTRNS_samp_all_&pays._V&yr_of_calculation. t2 on (t1.Clm_Nmbr = t2.Clm_Nmbr);
Quit;

Proc SQL; Create Table Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. As
Select distinct t1.*,t2.AVG_AGE
From Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. t1 Left Join  AGE_ACCDT_AVRG_&cover_typ._&type_prod._&pays t2 on (t1.Cover = t2.Cover);
Quit;

Proc sort data=Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. ; by clm_nmbr; run;

data Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation.;
set Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. ;

/*  Calcul des variables : Nmbr_Mnths_Pndng, Mnths_lag & Nmbr_Bnfts_Pd   */

if Rsrv_Typ = "RBNP" then  Nmbr_Mnths_Pndng=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;   /*  nb de mois �coul� entre la date d'enregistrement et la date de  calcul */
if Rsrv_Typ = "ICOP" then  Mnths_lag=((year(Date_of_reserving )-year(trns_dt))*12 + (month(Date_of_reserving)-month(trns_dt)));;                 /*  nb de mois �coul� entre la date de la derni�re transaction et la date de  calcul */
if Rsrv_Typ = "RBNP" then  Mnths_lag=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;
if Rsrv_Typ = "ICOP" then  Nmbr_Mnths_Pndng=0;
if Rsrv_Typ not in ("ICOP","RBNP") then  Nmbr_Mnths_Pndng=0;
if Rsrv_Typ not in ("ICOP","RBNP") then  Mnths_lag=0;  

if Rsrv_Typ = "RBNP" then  Nmbr_Mnths_Pndng2=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;   /*  nb de mois �coul� entre la date d'enregistrement et la date de  vision */
if Rsrv_Typ = "ICOP" then  Mnths_lag2=((year(Date_of_reserving )-year(trns_dt))*12 + (month(Date_of_reserving)-month(trns_dt)));;
if Rsrv_Typ = "RBNP" then  Mnths_lag2=((year(Date_of_reserving )-year(Rgstrtn_Dt))*12 + (month(Date_of_reserving)-month(Rgstrtn_Dt)))+1;
if Rsrv_Typ = "ICOP" then  Nmbr_Mnths_Pndng2=0;
if Rsrv_Typ not in ("ICOP","RBNP") then  Nmbr_Mnths_Pndng2=0;
if Rsrv_Typ  not in ("ICOP","RBNP") then  Mnths_lag2=0; 

if Rsrv_Typ = "ICOP" then Nmbr_Bnfts_Pd=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Rsrv_Typ = "ICOP" then Nmbr_Bnfts_Pd2=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Rsrv_Typ = "RBNP" then Nmbr_Bnfts_Pd=0 ;
if Rsrv_Typ = "RBNP" then Nmbr_Bnfts_Pd2=0 ;
if Rsrv_Typ = "CLOSE" then Nmbr_Bnfts_Pd=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Rsrv_Typ = "CLOSE" then Nmbr_Bnfts_Pd2=int(Totl_Bnfts_Amnt_Pd/Mnthly_Bnft+0.5) ;
if Nmbr_Bnfts_Pd=. then Nmbr_Bnfts_Pd=0;
if Nmbr_Bnfts_Pd2=. then Nmbr_Bnfts_Pd2=0;
run;

/* CORRECTION DE L'AGE ET DU SEXE MANQUANT */

data Reserves_&cover_typ._&type_prod._&pays._V&yr_of_calculation._F;
set Reserves_all_&cover_typ._&type_prod._&pays._V&yr_of_calculation. ;
if  Gndr ="" then Gndr="M";
if  Gndr ="X" then Gndr="M";
if  Age_surv in (.,0) then Age_surv=AVG_AGE;
if  Age_surv <= 0 then Age_surv=AVG_AGE;
if  potential_clm_amt=0 then potential_clm_amt=0;
if  Otstndng_Balnc=0 then Otstndng_Balnc=0;
if  Mnthly_Bnft=0 then Mnthly_Bnft=0;
if Nmbr_Mnths_Pndng > 12 then Nmbr_Mnths_Pndng=12;
if Mnths_lag > 12 then Mnths_lag=12;
if Nmbr_Bnfts_Pd > 60 then Nmbr_Bnfts_Pd=60 ;
if cover="IU" and Age_surv > 80 then Age_surv =70 ;
if cover in ("DIS","LIFE","CI","PTD","GAP") and Age_surv > 100 then Age_surv =100 ;
run;


/*  IMPORTATION DES TABLES DE DURATION ET D'ACCEPTATION */


%let Import_01="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Reserving tables/&cover_typ./Tables_&pays._&type_prod._&cover_typ..xlsx";

%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE

;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IF &cover_typ.=IU or &cover_typ.=DIS %THEN %DO;

%IMPORT_EXCEL(FILE=&Import_01.,OUT=Table_duration_&cover_typ._&type_prod._&pays.,ONGLET=Duration);
%IMPORT_EXCEL(FILE=&Import_01.,OUT=Table_acceptation_&cover_typ._&type_prod._&pays.,ONGLET=Acceptation);

/*  MISE EN FORME DES FACTEURS DE LA TABLE DURATION ET DE LA TABLE ACCEPTATION */

data TABLE_DURATION_&cover_typ._&type_prod._&pays.;set TABLE_DURATION_&cover_typ._&type_prod._&pays.;run;

data facteur_age_D;keep Age_surv factor_age_D;set TABLE_DURATION_&cover_typ._&type_prod._&pays.;run;

data facteur_gender_D;keep Gndr factor_sexe_D Intercept_D;set TABLE_DURATION_&cover_typ._&type_prod._&pays.;run;

data facteur_Number_D;keep Nmbr_Bnfts_Pd factor_numbr_D;set TABLE_DURATION_&cover_typ._&type_prod._&pays.;run;

data facteur_Inactivity_D;keep Mnths_lag factor_lag_D ;set TABLE_DURATION_&cover_typ._&type_prod._&pays.;run;

data facteur_MAX_D;keep Max_Nmbr_Bnfts factor_max_D ;set TABLE_DURATION_&cover_typ._&type_prod._&pays.;run;

data TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

data facteur_age_A;keep Age_surv factor_age_A;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

data facteur_gender_A;keep Gndr factor_sexe_A Intercept_A;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

data facteur_Waiting_A;keep Nmbr_Mnths_Pndng factor_month_A ;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

%END;

%IF &cover_typ.=LIFE or &cover_typ.=CI or &cover_typ.=PTD or &cover_typ.=GAP %THEN %DO;

%IMPORT_EXCEL(FILE=&Import_01.,OUT=Table_acceptation_&cover_typ._&type_prod._&pays.,ONGLET=Acceptation);

/*  MISE EN FORME DES FACTEURS DE LA TABLE ACCEPTATION */

data TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

data facteur_age_A;keep Age_surv factor_age_A;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

data facteur_gender_A;keep Gndr factor_sexe_A Intercept_A;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

data facteur_Waiting_A;keep Nmbr_Mnths_Pndng factor_month_A ;set TABLE_ACCEPTATION_&cover_typ._&type_prod._&pays.;run;

%END;


/*  MERGE DES FACTEURS DE LA TABLE DURATION ET DE TABLE ACCEPTATION */


%IF &cover_typ.=IU or &cover_typ.=DIS %THEN %DO;


Proc SQL; Create Table Reserves_&cover_typ._&type_prod._&pays._V&yr_of_calculation._F As
Select distinct t1.*,t2.factor_age_D,t3.factor_numbr_D,t4.factor_max_D,t5.factor_sexe_D,t5.Intercept_D,t6.factor_lag_D,t7.factor_age_A,t8.factor_sexe_A,t8.Intercept_A,t9.factor_month_A
From Reserves_&cover_typ._&type_prod._&pays._V&yr_of_calculation._F t1 Left Join  facteur_age_D t2    on (t1.Age_surv = t2.Age_surv)
                                                           Left Join  facteur_Number_D t3 on (t1.Nmbr_Bnfts_Pd = t3.Nmbr_Bnfts_Pd)
                                                           Left Join  facteur_Max_D t4    on (t1.Max_Nmbr_Bnfts = t4.Max_Nmbr_Bnfts)
                                                           Left Join  facteur_gender_D t5 on (t1.Gndr = t5.Gndr)
                                                           Left Join  facteur_Inactivity_D t6 on (t1.Mnths_lag = t6.Mnths_lag)
                                                           Left Join  FACTEUR_AGE_A t7 on (t1.Age_surv = t7.Age_surv)
                                                           Left Join  FACTEUR_GENDER_A t8 on (t1.Gndr = t8.Gndr)
                                                           Left Join  FACTEUR_WAITING_A t9 on (t1.Nmbr_Mnths_Pndng = t9.Nmbr_Mnths_Pndng)
           
;
Quit;

%END;

%IF &cover_typ.=LIFE or &cover_typ.=CI or &cover_typ.=PTD or &cover_typ.=GAP %THEN %DO;

Proc SQL; Create Table Reserves_&cover_typ._&type_prod._&pays._V&yr_of_calculation._F As
Select distinct t1.*,0 as factor_age_D,0 as factor_numbr_D,0 as factor_max_D,0 as factor_sexe_D,0 as Intercept_D,0 as factor_lag_D,t7.factor_age_A,t8.factor_sexe_A,t8.Intercept_A,t9.factor_month_A
From Reserves_&cover_typ._&type_prod._&pays._V&yr_of_calculation._F t1 Left Join  FACTEUR_AGE_A t7 on (t1.Age_surv = t7.Age_surv)
                                                           Left Join  FACTEUR_GENDER_A t8 on (t1.Gndr = t8.Gndr)
                                                           Left Join  FACTEUR_WAITING_A t9 on (t1.Nmbr_Mnths_Pndng = t9.Nmbr_Mnths_Pndng)
           
;
Quit;

%END;

/*  CALCUL DE LA PROBABILITE D'ACCEPTATION ET DU NOMBRE DE BENEFIT OUSTANDING */

data CLMHDR_&cover_typ._&type_prod._&pays._V&yr_of_calculation.;
set Reserves_&cover_typ._&type_prod._&pays._V&yr_of_calculation._F ;

%IF &cover_typ.=IU or &cover_typ.=DIS %THEN %DO;

if Rsrv_Typ = "ICOP" then Nmbr_Bnfts_Otstndng=exp(Intercept_D + factor_age_D + factor_sexe_D + factor_max_D+ factor_numbr_D + factor_lag_D);
if Rsrv_Typ = "RBNP" then Nmbr_Bnfts_Otstndng=exp(Intercept_D + factor_age_D + factor_sexe_D + factor_max_D+ factor_numbr_D + factor_lag_D);
if Rsrv_Typ = "RBNP" then Probablty_Otstndng=exp(Intercept_A + factor_age_A + factor_sexe_A + factor_month_A)/(1+exp(Intercept_A+factor_age_A +factor_sexe_A+ factor_month_A));
if Rsrv_Typ in ("CLOSE","NON-CORE OPEN","NON-CORE CLOSE") then Nmbr_Bnfts_Otstndng=0;
if Rsrv_Typ in ("CLOSE","ICOP","NON-CORE OPEN","NON-CORE CLOSE") then Probablty_Otstndng=0;

/*  CALCUL DES RESERVES */

if Rsrv_Typ = "ICOP" and cover in ("IU","DIS") then Rsrv_Amt=Mnthly_Bnft*Nmbr_Bnfts_Otstndng;
if Rsrv_Typ = "RBNP" and cover in ("IU","DIS") then Rsrv_Amt=Probablty_Otstndng*Mnthly_Bnft*Nmbr_Bnfts_Otstndng;
if Rsrv_Typ not in ("ICOP","RBNP") then Rsrv_Amt=0;

%END;

%IF &cover_typ.=LIFE or &cover_typ.=CI or &cover_typ.=PTD or &cover_typ.=GAP %THEN %DO;

Nmbr_Bnfts_Otstndng=0 ;
if Rsrv_Typ = "RBNP" then Probablty_Otstndng=exp(Intercept_A + factor_age_A + factor_sexe_A + factor_month_A)/(1+exp(Intercept_A+factor_age_A +factor_sexe_A+ factor_month_A));
if Rsrv_Typ = "ICOP" then Probablty_Otstndng=0;
if Rsrv_Typ  not in ("RBNP") then Probablty_Otstndng=0;

/*  CALCUL DES RESERVES */

if Rsrv_Typ = "RBNP" and cover in ("CI","LIFE","PTD") then Rsrv_Amt=Probablty_Otstndng*Otstndng_Balnc ;
if Rsrv_Typ = "RBNP" and cover in ("GAP") then Rsrv_Amt=Probablty_Otstndng*potential_clm_amt ;
if Rsrv_Typ  not in ("ICOP","RBNP") then Rsrv_Amt=0;
if Rsrv_Grp in ("ZZ1","ZZ2") then Rsrv_Amt=0;

%END;

/* AUTO CLOSE SUR LE CALCUL DES RESERVES */

/*if Rsrv_Typ = "ICOP"  and Nmbr_Bnfts_Pd > MAX(Max_Nmbr_Bnfts,&guideline.) then Rsrv_Amt=0;*/
/*if Rsrv_Typ = "ICOP"  and Mnths_lag2 > &guideline. then Rsrv_Amt=0;*/
/*if Rsrv_Typ = "RBNP"  and Nmbr_Mnths_Pndng2 > &guideline. then Rsrv_Amt=0;*/

rename Nmbr_Mnths_Pndng2 =Nmbr_Mnths_Pndng
       Nmbr_Bnfts_Pd2=Nmbr_Bnfts_Pd
;
run;

PROC SQL;
		CREATE TABLE CLMHDR_&cover_typ._&type_prod._&pays._V&yr_of_calculation. as 
		SELECT 
		 Date_of_reserving,		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Policy_Line_No,
		 Policy_Line_Seq_No,
		 Cvr_Typ,
		 cover,
		 Schm,
		 Accdnt_Dt,
		 Acc_yr,
		 Acc_Mnth,
		 Rgstrtn_Dt,
		 Rgstrtn_Yr,
		 Rgstrtn_Mnth,
		 Cls_Dt,
		 STATUS,
		 potential_clm_amt,
		 Otstndng_Balnc,
		 Undrwrtng_Cmpny,
		 Max_Nmbr_Bnfts,
		 Expry_dt,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Frst_Bnft_Pd_Yr,
		 Frst_Bnft_Pd_Mnth,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Incptn_Dt,
		 Insrnc_Trm,
		 Mnthly_Bnft,
		 Prdct,
		 Gndr,
		 Dt_of_Brth,
		 Nmbr_Mnths_Pndng,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Probablty_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type,
		 Legal_Entity 
		FROM CLMHDR_&cover_typ._&type_prod._&pays._V&yr_of_calculation. 
		GROUP BY Clm_Nmbr ;
QUIT;



%MEND;


/*#################################################################  MACRO DE CONCATENATION DE TOUTES LES COUVERTURES ######################################################################################### */


%Macro fusion_fr(pays=,yr_of_calculation=,);


/* FILTRE SUR LES COUVERTURES NON-CORE HORS CASE RESERVES */

Data CLMHDR_Hors_p_&pays._V&yr_of_calculation.;
FORMAT Date_of_reserving DDMMYY10. ;
length Rsrv_Typ $40.;
set &pays._CLMHDR_ALL ;
where Rsrv_Grp  in ("ZZ1","ZZ2");
if Rsrv_Grp in ("ZZ1","ZZ2") AND STATUS in ("OP","RO") then Rsrv_Typ = "NON-CORE OPEN";
if Rsrv_Grp in ("ZZ1","ZZ2") AND STATUS in ("CL","DC") then Rsrv_Typ = "NON-CORE CLOSE";
Date_of_reserving = mdy(&month_reserving., &day_reserving., &yr_reserving.) ;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Nmbr_Mnths_Pndng=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Pd=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Otstndng=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Probablty_Otstndng=0;
if Rsrv_Grp  in ("ZZ1","ZZ2") then  Rsrv_Amt=0;
run;



PROC SQL;
		CREATE TABLE CLMHDR_Hors_p_&pays._V&yr_of_calculation. as 
		SELECT distinct 
		 Date_of_reserving ,		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Policy_Line_No,
		 Policy_Line_Seq_No,
		 Cvr_Typ,
		 cover,
		 Schm,
		 Accdnt_Dt,
		 Acc_yr,
		 Acc_Mnth,
		 Rgstrtn_Dt,
		 Rgstrtn_Yr,
		 Rgstrtn_Mnth,
		 Cls_Dt,
		 STATUS,
		 potential_clm_amt,
		 Otstndng_Balnc,
		 Undrwrtng_Cmpny,
		 Max_Nmbr_Bnfts,
		 Expry_dt,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Frst_Bnft_Pd_Yr,
		 Frst_Bnft_Pd_Mnth,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Incptn_Dt,
		 Insrnc_Trm,
		 Mnthly_Bnft,
		 Prdct,
		 Gndr,
		 Dt_of_Brth,
		 Nmbr_Mnths_Pndng,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Probablty_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type,
		 Legal_Entity 
		FROM CLMHDR_Hors_p_&pays._V&yr_of_calculation.
		GROUP BY Clm_Nmbr ;
QUIT;


/* FUSION DES COUVERTURES: CREATION DE LA BASE CLMHDR  */

data CLMHDR_all_&pays.;
set  CLMHDR_IU_&pays._V&yr_of_calculation.
     CLMHDR_DIS_M_&pays._V&yr_of_calculation.
     CLMHDR_DIS_NM_&pays._V&yr_of_calculation.
     CLMHDR_LIFE_M_&pays._V&yr_of_calculation.
     CLMHDR_LIFE_NM_&pays._V&yr_of_calculation.
     CLMHDR_PTD_&pays._V&yr_of_calculation.
     CLMHDR_CI_&pays._V&yr_of_calculation.
     CLMHDR_GAP_&pays._V&yr_of_calculation.
     CLMHDR_Hors_p_&pays._V&yr_of_calculation.
;
run;

proc sort data=CLMHDR_all_&pays. nodupkey out=CLMHDR_all_&pays.;  by Clm_Nmbr; run;

PROC SQL;
		CREATE TABLE &Ouput..CLMHDR_all_&pays. as 
		SELECT 
		 Date_of_reserving,		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Policy_Line_No,
		 Policy_Line_Seq_No,
		 Cvr_Typ,
		 cover,
		 Schm,
		 Accdnt_Dt,
		 Acc_yr,
		 Acc_Mnth,
		 Rgstrtn_Dt,
		 Rgstrtn_Yr,
		 Rgstrtn_Mnth,
		 Cls_Dt,
		 STATUS,
		 potential_clm_amt,
		 Otstndng_Balnc,
		 Undrwrtng_Cmpny,
		 Max_Nmbr_Bnfts,
		 Expry_dt,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Frst_Bnft_Pd_Yr,
		 Frst_Bnft_Pd_Mnth,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Incptn_Dt,
		 Insrnc_Trm,
		 Mnthly_Bnft,
		 Prdct,
		 Gndr,
		 Dt_of_Brth,
		 Nmbr_Mnths_Pndng,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Probablty_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type,
		 Legal_Entity 
		FROM CLMHDR_all_&pays. 
		GROUP BY Clm_Nmbr ;
QUIT;


/* CREATION DE LA BSE CLMHDR POUR LE DATA LAKE */


PROC SQL;
		CREATE TABLE CLMHDR_all_&pays._CR as 
		SELECT 		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Schm as SCHEME ,
		 Cvr_Typ as cover,
		 Undrwrtng_Cmpny as Entity_CD,
		 Legal_Entity as Entity,
		 Accdnt_Dt as Incident_date,
		 Rgstrtn_Dt,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 year(Incptn_Dt) as Vintage_year,
		 Date_of_reserving,
		 STATUS,
		 Totl_Amnt_Pd,
		 Totl_Bnfts_Amnt_Pd,
		 Probablty_Otstndng as Probablty_Accptd,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt,
		 informer_type
		 
		FROM &Ouput..CLMHDR_all_&pays. 
		
		GROUP BY Clm_Nmbr ;
QUIT;

%let Import_02="~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/Reassurance.xlsx";


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= WORK.&OUT. 
DBMS=xlsx REPLACE 
;
SHEET=&ONGLET. ;
RUN;
%MEND;

%IMPORT_EXCEL(FILE=&Import_02.,OUT=Parametres_Reas,ONGLET=Parametres_Reas);

data Parametres_Reas ;
set Parametres_Reas;
y_char = compress(put(Original_underwritter,21.0));
drop Original_underwritter; rename y_char = Original_underwritter;
run;

proc sql ; 
create table CLMHDR_all_&pays._CR as
select distinct
t1.*,
t8.QP_rei_CLAIM AS QP_rei_CLAIM 
from CLMHDR_all_&pays._CR  t1 
left join Parametres_Reas t8 on (t1.country=t8.country AND t1.scheme=t8.scheme AND t1.cover=t8.cover AND t1.Entity_CD=t8.Original_underwritter) 
 ;
quit ; 


data CLMHDR_all_&pays._CR;
set CLMHDR_all_&pays._CR ;

if QP_rei_CLAIM=. then Type_Insurance=0 ;
if QP_rei_CLAIM NOT IN (.) then Type_Insurance=4 ;

if Rsrv_Grp in ("ZZ1","ZZ2") then Rsrv_Amt=0; 
if Rsrv_Grp in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Otstndng=0;
if Rsrv_Grp in ("ZZ1","ZZ2") then Probablty_Accptd =0;
if Rsrv_Grp in ("ZZ1","ZZ2") then  Nmbr_Bnfts_Pd =0;

rename Rsrv_Amt=Rsrv_Amt_Gross 
       Totl_Bnfts_Amnt_Pd=Totl_Bnfts_Amnt_Pd_Gross
       Totl_Amnt_Pd=Totl_Amnt_Pd_Gross
;

if Type_Insurance=0 then QP_rei_CLAIM=1; 

run;


data CLMHDR_all_&pays._CR;
set CLMHDR_all_&pays._CR ;
Rsrv_Amt_Net= Rsrv_Amt_Gross*QP_rei_CLAIM;
Totl_Amnt_Pd_Net=Totl_Amnt_Pd_Gross*QP_rei_CLAIM;
Totl_Bnfts_Amnt_Pd_Net=Totl_Bnfts_Amnt_Pd_Gross*QP_rei_CLAIM;
run ;

PROC SQL;
		CREATE TABLE &Ouput..CLMHDR_all_&pays._CR as 
		SELECT 		
		 country,
		 Rsrv_Grp,
		 Clm_Nmbr,
		 Type_Insurance,
		 SCHEME ,
		 cover,
		 Entity_CD,
		 Entity,
		 Incident_date,
		 Rgstrtn_Dt,
		 Latst_Bnft_Pd_Yr,
		 Latst_Bnft_Pd_Mnth,
		 Vintage_year,
		 Date_of_reserving,
		 STATUS,
		 Totl_Amnt_Pd_Gross,
		 Totl_Amnt_Pd_Net,
		 Totl_Bnfts_Amnt_Pd_Gross,
		 Totl_Bnfts_Amnt_Pd_Net,
		 Probablty_Accptd,
		 Nmbr_Bnfts_Pd,
		 Nmbr_Bnfts_Otstndng,
		 Rsrv_Typ,
		 Rsrv_Amt_Gross,
		 Rsrv_Amt_Net,
		 informer_type
		 		 
		FROM CLMHDR_all_&pays._CR 
		
		GROUP BY Clm_Nmbr ;
QUIT;

%MEND;



/*#########################################################################################################################################################################################
/*######################################################   CALCUL DES RESERVES PAR PAYS ET PAR COUVERTURE : TOUT LES PAYS     #############################################################
/*######################################################################################################################################################################################## 


                     /* FRANCE */

%ACR_FR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=FR,prod=Mortgage,guideline=12,type_prod=M) ;
%ACR_FR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=FR,prod=Non_Mortgage,guideline=12,type_prod=NM) ;
%ACR_FR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=FR,prod=Mortgage,guideline=12,type_prod=M) ;
%ACR_FR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=FR,prod=Non_Mortgage,guideline=12,type_prod=NM) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=FR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=FR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=FR,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=FR,guideline=12) ;
%fusion_FR(pays=FR,yr_of_calculation=&yr_reserving.) ;

/*#########################################################################################################################################################################################
/*######################################################   CALCUL DES RESERVES PAR PAYS ET PAR COUVERTURE : OST     #############################################################
/*######################################################################################################################################################################################## 


                        /* COLOMBIA */ 
                                        
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=CO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=CO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=CO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=CO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=CO,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=CO,guideline=12) ;
%fusion(pays=CO,yr_of_calculation=&yr_reserving.) ;

                        /* MEXICO */ 
                                        
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=MX,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=MX,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=MX,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=MX,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=MX,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=MX,guideline=12) ;
%fusion(pays=MX,yr_of_calculation=&yr_reserving.) ;

                        /* AUSTRIA */ 
                                        
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=AT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=AT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=AT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=AT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=AT,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=AT,guideline=12) ;
%fusion(pays=AT,yr_of_calculation=&yr_reserving.) ;


                        /* BELGIUM */ 
                                        
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=IU,pays=BE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=DIS,pays=BE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=LIFE,pays=BE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=PTD,pays=BE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=CI,pays=BE,guideline=12) ;
%ACR(yr_of_calculation=&yr_reserving.,cover_typ=GAP,pays=BE,guideline=12) ;
%fusion(pays=BE,yr_of_calculation=&yr_reserving.) ;


