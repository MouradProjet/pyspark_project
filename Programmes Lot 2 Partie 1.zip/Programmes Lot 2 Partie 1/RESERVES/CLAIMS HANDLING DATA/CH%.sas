%let LReseau = X;
%LET Arrete = 2026_04_V2 ;
%let Ouput=CR_Q126;
%let month=03;
%let day=27;
%let yr=2026;
%let quarter = Q12026;


LIBNAME &ouput. "~/NAS/&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";

%Macro Moduleresults(pays=,); 

*Q ICOP SMRY RESULTS;

PROC SQL;
	CREATE TABLE ICOP_SMRY_RESULTS_&pays. as
	SELECT DISTINCT country,Rsrv_Grp as Rsrv_Grp, Clm_Nmbr, Rsrv_Amt, Probablty_Otstndng, Nmbr_Bnfts_Otstndng, Rsrv_Typ
	FROM &Ouput..CLMHDR_ALL_&pays./*_2*/
	WHERE Rsrv_Amt > 1 AND RSRV_TYP = "ICOP" and LEGACY_SCHEME_BOOK="TIA" ;
QUIT;


PROC SQL;
	CREATE TABLE ICOP_SMRY_RESULTS_&pays. as
	SELECT country,Rsrv_Grp, sum(Rsrv_Amt) as Rsrv_Amt, sum(Probablty_Otstndng) as Effective_Number, 
	Sum(Nmbr_Bnfts_Otstndng)as NOXMTHSOS, count(Clm_Nmbr) as Actual_Nmbr, Rsrv_Typ
	FROM ICOP_SMRY_RESULTS_&pays.
	WHERE Rsrv_Amt > 1 AND RSRV_TYP = "ICOP" 
	GROUP BY country,Rsrv_Grp, Rsrv_Typ;
QUIT;

*Q RBNP SMRY RESULTS;

PROC SQL;
	CREATE TABLE RBNP_SMRY_RESULTS_&pays. as
	SELECT country,Rsrv_Grp, sum(Rsrv_Amt) as Rsrv_Amt, sum(Probablty_Otstndng) as Eff_Nmbr_Otstndng, 
	Sum(Probablty_Otstndng*Nmbr_Bnfts_Otstndng) as ACCXMTHSOS, count(Clm_Nmbr) as Nmbr_Otstndng, Rsrv_Typ
	FROM &Ouput..CLMHDR_ALL_&pays./*_2*/
	WHERE RSRV_TYP = "RBNP" and LEGACY_SCHEME_BOOK="TIA"
	GROUP BY country,Rsrv_Grp, Rsrv_Typ;
QUIT;

*Q IBNR SMRY RESULTS;

PROC SQL;
	CREATE TABLE IBNR_SMRY_RESULTS_&pays. as
	SELECT country,Rsrv_Grp, sum(Rsrv_Amt_Gross) as Ibnr_SubGrp
	FROM &Ouput..WPS_DAAP_IBNR_&yr.&month.&day.
	WHERE country="&pays." and Rsrv_Grp not in ("ZZ2","ZZ1") 
	GROUP BY country,Rsrv_Grp;
QUIT;


%MEND;

%Moduleresults(pays=DE) ;
%Moduleresults(pays=DK) ;
%Moduleresults(pays=ES) ;
%Moduleresults(pays=IE) ;
%Moduleresults(pays=IT) ;
%Moduleresults(pays=FI) ;
%Moduleresults(pays=GR) ;
%Moduleresults(pays=NL) ;
%Moduleresults(pays=NI) ;
%Moduleresults(pays=NO) ;
%Moduleresults(pays=PL) ;
%Moduleresults(pays=PT) ;
%Moduleresults(pays=SE) ;
%Moduleresults(pays=TR) ;
%Moduleresults(pays=UK) ;
%Moduleresults(pays=AT) ;
%Moduleresults(pays=FR) ;

data CH_DATA_ICOP_ALL ;
SET ICOP_SMRY_RESULTS_DE
    ICOP_SMRY_RESULTS_DK
    ICOP_SMRY_RESULTS_ES
    ICOP_SMRY_RESULTS_FI
    ICOP_SMRY_RESULTS_FR
    ICOP_SMRY_RESULTS_GR
    ICOP_SMRY_RESULTS_IE
    ICOP_SMRY_RESULTS_IT
    ICOP_SMRY_RESULTS_NI
    ICOP_SMRY_RESULTS_NL
    ICOP_SMRY_RESULTS_NO
    ICOP_SMRY_RESULTS_PL
    ICOP_SMRY_RESULTS_PT
    ICOP_SMRY_RESULTS_SE
    ICOP_SMRY_RESULTS_TR
    ICOP_SMRY_RESULTS_UK

;
IF Rsrv_Grp IN ("ZZ2","ZZ1") then delete ;
run;

data CH_DATA_RBNP_ALL ;
SET RBNP_SMRY_RESULTS_DE
    RBNP_SMRY_RESULTS_DK
    RBNP_SMRY_RESULTS_ES
    RBNP_SMRY_RESULTS_FI
    RBNP_SMRY_RESULTS_FR
    RBNP_SMRY_RESULTS_GR
    RBNP_SMRY_RESULTS_IE
    RBNP_SMRY_RESULTS_IT
    RBNP_SMRY_RESULTS_NI
    RBNP_SMRY_RESULTS_NL
    RBNP_SMRY_RESULTS_NO
    RBNP_SMRY_RESULTS_PL
    RBNP_SMRY_RESULTS_PT
    RBNP_SMRY_RESULTS_SE
    RBNP_SMRY_RESULTS_TR
    RBNP_SMRY_RESULTS_UK

;
IF Rsrv_Grp IN ("ZZ2","ZZ1") then delete ;
run;

data CH_DATA_IBNR_ALL ;
SET IBNR_SMRY_RESULTS_DE
    IBNR_SMRY_RESULTS_DK
    IBNR_SMRY_RESULTS_ES
    IBNR_SMRY_RESULTS_FI
    IBNR_SMRY_RESULTS_FR
    IBNR_SMRY_RESULTS_GR
    IBNR_SMRY_RESULTS_IE
    IBNR_SMRY_RESULTS_IT
    IBNR_SMRY_RESULTS_NI
    IBNR_SMRY_RESULTS_NL
    IBNR_SMRY_RESULTS_NO
    IBNR_SMRY_RESULTS_PL
    IBNR_SMRY_RESULTS_PT
    IBNR_SMRY_RESULTS_SE
    IBNR_SMRY_RESULTS_TR
    IBNR_SMRY_RESULTS_UK

;
IF Rsrv_Grp IN ("ZZ2","ZZ1") then delete ;
run;


%macro EXPORT_EXCEL(DATABASE=, DATATABLE=, SHEET=, );
PROC EXPORT  	
DATA = &DATATABLE.
OUTFILE=&DATABASE. 
DBMS=XLSX REPLACE ;
SHEET = &SHEET. ;
run;
%MEND;

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/CLAIMS HANDLING DATA/&quarter./Ouput/CH_DATA_IBNR_ALL.xlsx";
%EXPORT_EXCEL(DATATABLE=CH_DATA_IBNR_ALL,DATABASE=&repexp.,SHEET="CH_DATA_IBNR_ALL");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/CLAIMS HANDLING DATA/&quarter./Ouput/CH_DATA_ICOP_ALL.xlsx";
%EXPORT_EXCEL(DATATABLE=CH_DATA_ICOP_ALL,DATABASE=&repexp.,SHEET="CH_DATA_ICOP_ALL");

%let repexp="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/CLAIMS HANDLING DATA/&quarter./Ouput/CH_DATA_RBNP_ALL.xlsx";
%EXPORT_EXCEL(DATATABLE=CH_DATA_RBNP_ALL,DATABASE=&repexp.,SHEET="CH_DATA_RBNP_ALL");

