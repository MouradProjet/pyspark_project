 /* avec run parral�le*/
 
             
* LIBNAMES ET MACROS;     
%LET LReseau =  ~/NAS/X; 
%LET Arrete = 2026_04_V2; 
%LET Cutoffdate= "27MAR2026:23:59:59"dt; *penser � mettre le mois +1 pour le PM;
%LET fin_annee=2026-03-27;
LIBNAME Out_GEP "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/DAAP" ;
LIBNAME TIA3 "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 
LIBNAME EA "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
option mprint mlogic symbolgen;

*DATALAKE; 
%wps_mac_connexion_db(
    nom_libname = POLICY ,
    nom_db = WPS_SHINE_BLCL ,
    nom_schema = clp_wps ,
    nom_options = readbuff=10000 schema=global_policy_extracts
    );

LIBNAME POLICY odbcold  DSN=WPS_SHINE_BLCL  authdomain="DB_WPS_SHINE_BLCL"  schema=global_policy_extracts ;



/************* import *************/ 
%macro mef (country = , pays = ) ;

proc sql;
    %wps_mac_connexion_db(
        nom_connexion = CNX ,
        nom_db = WPS_SHINE_BLCL ,
        nom_schema = clp_wps ,
        nom_options = readbuff=30000 schema=global_policy_extracts
        ); 
    select distinct TRANSACTION_DATE into : liste_annee separated by ' ' from  connection to cnx
    (
        SELECT year(TRANSACTION_DATE) as  TRANSACTION_DATE     
        FROM global_policy_extracts.&pays._pe_renewable_details_view
        where to_date(TRANSACTION_DATE) < to_date("&fin_annee.")
        order by TRANSACTION_DATE
    );
        disconnect from cnx;
quit;
 
%put >>> &liste_annee;
 
%for(annee, in=(&liste_annee.), do=%nrstr(
 
        proc sql;
        %wps_mac_connexion_db(
            nom_connexion = CNX ,
            nom_db = WPS_SHINE_BLCL ,
            nom_schema = clp_wps ,
            nom_options = readbuff=30000 schema=global_policy_extracts
        );
 
           create table policy_TRANSACTION_DATE_&annee. as  
           SELECT 
COUNTRY_CD,           
PRODUCT format=$4. length=4, 
PRODUCT_VERSION format=$10., 
PRODUCT_LINE format=$2. length=2,  
PRODUCT_LINE_VERSION, 
POLICY_NUMBER, 
COVER_CODE format=$5. length=5,
datepart(START_DATE) as start_date format=ddmmyy10., 
datepart(COVER_START_DATE) as cover_start_date format=ddmmyy10., 
datepart(cover_end_DATE) as cover_end_date format=ddmmyy10., 
datepart(EXPIRY_DATE) as expiry_date format=ddmmyy10., 
datepart(cancel_DATE) as cancel_date format=ddmmyy10., 
datepart(transaction_DATE) as transaction_date format=ddmmyy10., 
GL_TYPE format=$60., 
GL_TYPE_NO, 
PER_TRANS_PREMIUM, 
PER_TRANS_NON_PREMIUM,
PER_TRANS_TOTAL_COMMISSION, 
PER_TRANS_PREMIUM_REFUND, 
PER_TRANS_NON_PREMIUM_REFUND, 
PER_TRANS_TOT_COMM_CLAWBACK,
NO_INSUREDS_ON_COVER, TRANS_ID,
SC_CODE format=$6. length=6,
TRANSACTION_TYPE format=$2. length=2          
        
          
            from  connection to cnx
            (
            SELECT  
"&pays." as COUNTRY_CD,           
PRODUCT,
PRODUCT_VERSION, 
PRODUCT_LINE,  
PRODUCT_LINE_VERSION, 
POLICY_NUMBER, 
COVER_CODE,
start_date, 
cover_start_date, 
cover_end_date, 
expiry_date, 
cancel_date, 
transaction_date, 
GL_TYPE, 
GL_TYPE_NO, 
PER_TRANS_PREMIUM, 
PER_TRANS_NON_PREMIUM,
PER_TRANS_TOTAL_COMMISSION, 
PER_TRANS_PREMIUM_REFUND, 
PER_TRANS_NON_PREMIUM_REFUND, 
PER_TRANS_TOT_COMM_CLAWBACK,
NO_INSUREDS_ON_COVER, 
TRANS_ID,
SC_CODE,
TRANSACTION_TYPE          
           
                     
            FROM global_policy_extracts.&pays._pe_renewable_details_view
            where to_date(TRANSACTION_DATE) < to_date("&fin_annee.") and year(to_date(TRANSACTION_DATE)) = &annee.
         );
            disconnect from cnx;
        quit;
 
));


/* Concat�nation des tables de la work */
data &country._mrtrans/*_2*/;
    set policy_transaction_date_:;
run;

data TIA3.&country._mrtrans/*_2*/;
   set &country._mrtrans/*_2*/;
run;


%for(annee, in=(&liste_annee.), do=%nrstr(
proc datasets lib=work memtype=DATA;   delete policy_transaction_date_&annee.;   run; 
));

%mend; 

/*** fin import ***/

 

%macro run_parallele(task=1, same_work=0, cmd=, list_libname=);
 
	signon signon_&task. sascmd="/opt/wps/current/bin/wps -dmr -noautoexec" CONNECTWAIT=NO SIGNONWAIT=NO;
	%put NOTE: Initialisation du signon &task. : %sysfunc(datetime(), datetime.);
	%syslput _local_ ;
	%syslput _global_ ;
	rsubmit signon_&task. wait=no sascmd="!sascmd" CONNECTWAIT=NO SIGNONWAIT=NO inheritlib=(&list_libname.  work=rwork)
	;		
		%put NOTE: Debut de la tache signon_&task. : %sysfunc(datetime(), datetime.);
		%let __debut=%sysfunc(datetime());
		libname rwork "%sysfunc(pathname(rwork))";
		option mstored sasmstore=rwork;
        %unquote(&cmd.)		
		%put NOTE: Fin de la tache signon_&task. : %sysfunc(datetime(), datetime.);
		%put NOTE: Duree de la tache signon_&task. : %sysfunc(INTCK(second,&__debut., %sysfunc(datetime()) ), time.);
	endrsubmit;	
%mend run_parallele;



%macro GEP_MR_TRAITEMENT(country, annee_gep);

	%LET DT_CAL= "31dec2026"d; 
    %LET DT_Arrete_Reel = "27MAR2026"d ; 
    %LET Cutoffdate= "27MAR2026"d;
    %LET N = 2026 ;
      
      
	Proc format;
	Value exp 1,2,3 = "Q1"
	          4,5,6 = "Q2"
	          7,8,9 = "Q3"
	          10,11,12 = "Q4";
	Run;
	
	data &country._PE_RENEWABLE_input ; set /*TIA3*/rwork.&country._MRTRANS/*_2*/(where=(year(start_date) = &annee_gep.)) ;run;
	
	/*adding cancel date to every row of the policy number*/
	data cncl_dt (keep=policy_number cancel_date rename=(cancel_date=cancel_date2));
	set  &country._PE_RENEWABLE_input;
	where cancel_date ne .;
	run;
	
	proc sort data=cncl_dt nodupkey; by policy_number; run;
	proc sort data=&country._PE_RENEWABLE_input; by policy_number; run;
	
	data &country._PE_RENEWABLE_input ;
	merge &country._PE_RENEWABLE_input  (in=a ) cncl_dt(in=b);
	by policy_number;
	if a;
	run;
	
		
	data &country._PE_RENEWABLE (keep=country POLICY_NUMBER cover start_date cover_start_date cover_end_date cancel_date GL_TYPE GL_TYPE_NO PRODUCT PRODUCT_VERSION payfreq premium COMMISSION premium_refund total_commission_clawback term scheme DATE_DEB_TRIM UEP_TRANS_DATE NBR_MS Exp_Mois NB_RT Cohort Rule /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER */) ;
	set &country._PE_RENEWABLE_input; /* Input table � changer */
	where start_date lt &Cutoffdate; /* on supprime toutes les polices qui commencent apr�s la data de calcul */ 
	      
	/* On renomme des variables et formatage */
	if PER_TRANS_PREMIUM = . then premium = 0;else Premium = PER_TRANS_PREMIUM; 
	if PER_TRANS_TOTAL_COMMISSION = . then COMMISSION = 0;else COMMISSION = PER_TRANS_TOTAL_COMMISSION;
	if PER_TRANS_PREMIUM_REFUND = . then premium_refund= 0;else premium_refund = PER_TRANS_PREMIUM_REFUND;
	if PER_TRANS_TOT_COMM_CLAWBACK = . then total_commission_clawback = 0;else total_commission_clawback = PER_TRANS_TOT_COMM_CLAWBACK;
	rename cover_code = cover ;
	rename country_cd = country ; 	      
	FORMAT DATE_DEB_TRIM DATE9. ;
	FORMAT UEP_TRANS_DATE DATE9. ;
	length payfreq $10.;
	length LEGACY_SCHEME_CODE $20.;
	length LEGACY_AGREEMENT_NUMBER $50.;
	length LEGACY_RENEWAL_NUMBER $20.;
	      
	/* D�finition de plusieurs variables */	      
	term=(year(cover_end_date)-year(cover_start_date))*12 + month(cover_end_date)- month(cover_start_date);	      
	if product_version = " " then 
	scheme = compress(trim(product)||'.'||(trim(Product_line_VERSION )) );
	else scheme = compress(trim(product)||'.'||(trim(Product_VERSION )) );	
	DATE_DEB_TRIM =intnx( "QTR",(start_date),1) ;
	NBR_MS =intck( "month",(start_date),DATE_DEB_TRIM) ;
	UEP_TRANS_DATE = &Cutoffdate.;
	Exp_Mois = min(month(UEP_trans_date) - month((cover_start_date))+12*year(UEP_trans_date)-12*year((cover_start_date)),term,month((cancel_date)) - month((cover_start_date))+12*year((cancel_date))-12*year((cover_start_date)));
	NB_RT =intck( "month",(cover_start_date),(cancel_date)) ;
	Cohort =year(start_date) ;
	Rule = "r12";
    payfreq="MRTRANS" ;
	if term < 0 then delete ;
	if cover_start_date=cancel_date2 then delete ;
	LEGACY_SCHEME_CODE= "";
	LEGACY_AGREEMENT_NUMBER="" ;
	LEGACY_RENEWAL_NUMBER="" ;
	run ; 
	       
	/* Traitement des cas o� le term = 1 */	      
	data &country._PE_RENEWABLE_0 ; 
	set &country._PE_RENEWABLE ; 
	where term=1 ;  
	if EXP_PERIOD > UEP_TRANS_DATE then delete ;	      
	FORMAT  EXP_PERIOD MONYY7.;
	days=day(cover_start_date)/30.4167 ;
	EXP_PERIOD =  intnx('month',(cover_start_date),0,'same');
	Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));	      
	if NB_RT >= 0 then GEP=0 ; 
	else GEP=(1-days)*PREMIUM;
	if NB_RT > 0 then UEP_TBT=0 ;
	else UEP_TBT=Premium-GEP ;
    run;
	      
	data &country._PE_RENEWABLE_1 ; 
	set &country._PE_RENEWABLE ; 
	where term=1 ;
	if EXP_PERIOD > UEP_TRANS_DATE then delete ;	
	FORMAT EXP_PERIOD MONYY7.;
	days=day(cover_start_date)/30.4167 ;
	EXP_PERIOD =  intnx('month',(cover_end_date),0,'same');
	Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));	
	if NB_RT >= 0 then GEP=0 ;  else GEP=(days)*PREMIUM;
	if NB_RT > 0 then UEP_TBT=0 ;
	else UEP_TBT=Premium-GEP ;	
	run;
	
	/* Traitement des cas o� le term = 0 */
	data &country._PE_RENEWABLE_5 ; 
	set &country._PE_RENEWABLE ; 
	where term=0 ;
	FORMAT EXP_PERIOD MONYY7.;
	EXP_PERIOD =  intnx('month',(cover_start_date),0,'same');
	GEP=PREMIUM;
	Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));
	if EXP_PERIOD > UEP_TRANS_DATE then delete ;
	if NB_RT > 0 then UEP_TBT=0 ;
	else UEP_TBT=Premium-GEP ;
	run;
	
	/* Merge des cas o� le term = 1 et 0 */
	data &country._PE_RENEWABLE_2 ; 
	set &country._PE_RENEWABLE_0 &country._PE_RENEWABLE_1 &country._PE_RENEWABLE_5 ; 
	NBR=(year(EXP_PERIOD)-year(start_date))*12 + month(EXP_PERIOD)- month(start_date)+1;
	Quart_Dev = IFN(NBR_MS>NBR, 1, int((NBR - NBR_MS)/3 + 2));
	drop days NBR_MS NBR  ;
	run ; 
	
	/* Nettoyage */
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_1;run;
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_5;run;
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_0;run;
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_Input;run;
	
	
	/* Traitement des cas o� le term <> 1 */
	
	data &country._PE_RENEWABLE_3 ; 
	set &country._PE_RENEWABLE ; 
	where (term <> 1 and term <>0) ; 
	FORMAT  EXP_PERIOD MONYY7. ;
	
	      Do TERM_IN_FORCE = 0 to (EXP_MOIS) ;  /* On change i par Term_in_force directement, on �vite le rename */
	          /* calcul EXT_Period : inchang� */    
	            EXP_PERIOD =  intnx('month',(cover_start_date),term_in_force,'same'); 
	            /* Calcul de Quart_Dev en utilisant la fonction IFN() -> meme chose que fonction SI dans Excel */
	            Quart_Dev = IFN(NBR_MS>TERM_IN_FORCE, 1, int((Term_In_Force - NBR_MS)/3 + 2));
	            /* Calcul de QTR_Period en une ligne gr�ce au format */
	           Qtr_Period = Cats(Put(month(Exp_Period),EXP.), year(Exp_Period));
	      
	            /* Calcul GEP */ 
	       if TERM_IN_FORCE ne NB_RT then do ; 	       
	                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
	                  if TERM_IN_FORCE=0 then GEP = ((1-(Term-0.5)/Term))*Premium ; 
	                  else GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;	           
	       end ;
	        
	       else do ; 
	            UEP_TBT = 0 ;
	            GEP = ((Term-(TERM_IN_FORCE-1)-0.5)/Term)*Premium + premium_refund ; 	        
	       end; 
	      
	      output ;       
	      end ;
	      drop TERM_IN_FORCE NBR_MS ;
	run;	
	
	/* MERGE GLOBAL */
	data &country._PE_RENEWABLE_4 ; 
	set &country._PE_RENEWABLE_2 &country._PE_RENEWABLE_3 ; 
	FORMAT  EXP_PERIOD_2 MONYY7. ;
	EXP_PERIOD_2=mdy(month(EXP_PERIOD),1,year(EXP_PERIOD)) ; 
	run ; 
	
	/* Nettoyage */ 	
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_2;run;
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_3;run;
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE;run;
	
	
	/* Input DAAP */ 
	proc sql ; 
	create table rwork.&country._MTRANS_&annee_gep. as 
	select distinct
	country,
	cover,
	GL_TYPE,
	GL_TYPE_NO,
	term,
	scheme,
	UEP_TRANS_DATE,
	Cohort,
	Rule,
	EXP_PERIOD_2 as EXP_PERIOD,
	Qtr_Period,
	Quart_Dev,
	sum(GEP) as GEP,
	payfreq
	from &country._PE_RENEWABLE_4 
	group by country,cover,GL_TYPE,GL_TYPE_NO,term,scheme,UEP_TRANS_DATE,Cohort,Rule,EXP_PERIOD_2,Qtr_Period,Quart_Dev,payfreq /*, LEGACY_SCHEME_CODE, LEGACY_AGREEMENT_NUMBER, LEGACY_RENEWAL_NUMBER*/ ; 
	quit ; 
	
	
	
	/* Input EA SIMON  */
	data &country._EA_MRTRANS ;
	set &country._PE_RENEWABLE_4 ;
	retain country product Product_VERSION cover start_year GL_TYPE_NO UEP_TRANS_DATE cancelled  term  Qtr_Period  Quart_Dev GEP payfreq UEP_TBT /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER*/  ;
	keep country product Product_VERSION cancelled cover GL_TYPE_NO term  Qtr_Period GEP Quart_Dev start_year UEP_TRANS_DATE payfreq UEP_TBT  /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER*/ ;
	if NB_RT =. then cancelled=1 ;
	else cancelled=0 ;
	if product_version = " " then product_version=Product_line_VERSION ;
	rename 
	GL_TYPE_NO=entity
	Product_VERSION=product_version 
	UEP_TRANS_DATE=Date_Cal ;
	start_year=year(start_date);
	run ;
		
	proc sql ; 
	create table rwork.&country._EA_MRTRANS_&annee_gep. as 
	select distinct 
	country,
	product,
	product_version,
	cover,
	start_year,
	entity,
	Date_Cal,
	cancelled,
	term,
	Qtr_Period,
	Quart_Dev,
	sum(GEP) as GEP,
	sum(UEP_TBT) as UEP,
	payfreq
	from &country._EA_MRTRANS 
	group by country,product,product_version,cover,start_year,entity,Date_Cal,cancelled,term,Qtr_Period,Quart_Dev,payfreq/*,LEGACY_SCHEME_CODE,LEGACY_AGREEMENT_NUMBER,LEGACY_RENEWAL_NUMBER*/ ; 
	quit ; 
	
	
	proc datasets lib=work memtype=DATA;delete &country._PE_RENEWABLE_4;run;
	proc datasets lib=work memtype=DATA;delete &country._EA_MRTRANS ;run;
	
%mend gep_mr_traitement;  



   
%macro GEP_MR (country =) ;

	%let liste_annee_gep=;
	proc sql noprint;
		select distinct year(start_date) into : liste_annee_gep separated by ' '
		from /*TIA3.*/&country._MRTRANS/*_2*/
		order by start_date
		;
	quit;
	
	%put >>> &liste_annee_gep;
	proc delete data=&country._EA_MRTRANS_:; run;
	proc delete data=&country._MTRANS_:; run;
	
	%for(annee_gep, in=(&liste_annee_gep.), do=%nrstr(
		%run_parallele(task=&annee_gep.,
			   same_work=1,
               cmd=%nrstr(
					%gep_mr_traitement(&country., &annee_gep.);
	           ),
	           list_libname=ea out_gep 
		);
 
			
	));
	 
	Waitfor _All_ 
	%for(annee_gep, in=(&liste_annee_gep.), do=%nrstr(
		signon_&annee_gep.
	));
	;
	signoff _All_;
	
%put NOTE: Tout termin� : %sysfunc(datetime(), datetime.);

	data EA.&country._EA_MRTRANS/*_2*/;
		set &country._EA_MRTRANS_:;
	run;
	data Out_GEP.&country._MTRANS/*_2*/;
		set &country._MTRANS_:;
	run;	
	
%mend ; 

%macro kill (country =) ;
proc datasets lib=work memtype=DATA;delete &country._EA_MRTRANS: ;run;
proc datasets lib=work memtype=DATA;delete &country._MTRANS_: ;run;
proc datasets lib=work memtype=DATA;delete &country._MRTRANS ;run;
%mend ; 


%mef(country = AUSTRIA , pays = AT) ; 
%GEP_MR(country = AUSTRIA);
%kill(country = AUSTRIA) ;

%mef(country = BELGIUM , pays = BE) ; 
%GEP_MR(country = BELGIUM) ;
%kill(country = BELGIUM) ;

%mef(country = COLOMBIA , pays = CO) ;
%GEP_MR(country = COLOMBIA) ;
%kill(country = COLOMBIA) ;

%mef(country = DENMARK , pays = DK) ;
%GEP_MR(country = DENMARK) ;
%kill(country = DENMARK) ;

%mef(country = FINLAND , pays = FI) ;
%GEP_MR(country = FINLAND) ;
%kill(country = FINLAND) ;

%mef(country = FRANCE , pays = FR) ;
%GEP_MR(country = FRANCE) ; 
%kill(country = FRANCE) ;

%mef(country = GERMANY , pays = DE) ;
%GEP_MR(country = GERMANY) ;
%kill(country = GERMANY) ;

%mef(country = GREECE , pays = GR) ;
%GEP_MR(country = GREECE) ;
%kill(country = GREECE) ;

%mef(country = IRELAND , pays = IE) ; 
%GEP_MR(country = IRELAND) ;
%kill(country = IRELAND) ;

%mef(country = ITALY , pays = IT) ; 
%GEP_MR(country = ITALY);
%kill(country = ITALY) ;

%mef(country = MEXICO , pays = MX) ;
%GEP_MR(country = MEXICO) ;
%kill(country = MEXICO) ;

%mef(country = NETHERLANDS , pays = NL) ; 
%GEP_MR(country = NETHERLANDS) ;
%kill(country = NETHERLANDS) ;

%mef(country = NORWAY , pays = NO) ; 
%GEP_MR(country = NORWAY) ;
%kill(country = NORWAY) ;

%mef(country = POLAND , pays = PL) ; 
%GEP_MR(country = POLAND) ;
%kill(country = POLAND) ;

%mef(country = PORTUGAL , pays = PT) ; 
%GEP_MR(country = PORTUGAL) ;
%kill(country = PORTUGAL) ;

%mef(country = SPAIN , pays = ES) ; 
%GEP_MR(country = SPAIN) ; 
%kill(country = SPAIN) ;

%mef(country = SWEDEN , pays = SE) ;
%GEP_MR(country = SWEDEN) ;
%kill(country = SWEDEN) ;

%mef(country = SWITZERLAND , pays = CH) ; 
%GEP_MR(country = SWITZERLAND) ;
%kill(country = SWITZERLAND) ;

%mef(country = TURKEY , pays = TR) ; 
%GEP_MR(country = TURKEY) ;
%kill(country = TURKEY) ;

%mef(country = UK , pays = UK) ; 
%GEP_MR(country = UK) ;
%kill(country = UK) ;


 