      %LET DT_CAL= "31dec2026"d; 
      %LET DT_Arrete_Reel = "26JUN2026"d ; 
      %LET Arrete = 2026_06_Prov; 
      %LET Cutoffdate= "26JUN2026"d;
      %LET N = 2026 ;
      %let LReseau =  ~/NAS/X; /* Mettre le serveur appropri�  entre -> ~/NAS/X  ou -> X:/Inventprev ** */
        
      /** Libname **/
     
      LIBNAME Out_GEP "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/DAAP" ;
      LIBNAME TIA3 "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Extraction Donnees/Policy Extracts" ; 
      LIBNAME EA "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
     

%macro GEP_MF (country =) ;
 
/*%LET country= GERMANY;*/
 
Proc format;
Value exp 1,2,3 = "Q1"
                4,5,6 = "Q2"
                7,8,9 = "Q3"
                10,11,12 = "Q4";
Run;

data  &country._PE_FIXTERM_input ;
set  TIA3.&country._MF ;
run;

/*adding cancel date to every row of the policy number*/

data cncl_dt (keep=policy_number cancel_date);
set  &country._PE_FIXTERM_input;
where cancel_date ne .;
run;

data cncl_dt ;
set  cncl_dt;
rename cancel_date=cancel_date2 ;
run;

proc sort data=cncl_dt nodupkey;
by policy_number;
run;

proc sort data=&country._PE_FIXTERM_input;
by policy_number;
run;

data &country._PE_FIXTERM_input ;
merge &country._PE_FIXTERM_input  (in=a ) cncl_dt(in=b);
by policy_number;
if a;
run;

     data &country._PE_FIXTERM 
    (keep=country POLICY_NUMBER cover start_date  end_date cancel_date GL_TYPE GL_TYPE_NO product PRODUCT_VERSION Product_line_VERSION
      premium COMMISSION premium_refund total_commission_clawback term scheme DATE_DEB_TRIM UEP_TRANS_DATE NBR_MS Exp_Mois NB_RT Cohort Rule payfreq /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER*/) ;
      set &country._PE_FIXTERM_input; /* Input table � changer */
      
      where start_date lt &Cutoffdate;  /* on supprime toutes les polices qui commencent apr�s la data de calcul */ 
      
      /* On renomme des variables */
      
      if premium = . then premium = 0;else Premium = premium; 
      if TOTAL_COMMISSION = . then COMMISSION = 0;else COMMISSION = TOTAL_COMMISSION;
      if PREMIUM_REFUND = . then premium_refund= 0;else premium_refund = PREMIUM_REFUND;
      if TOTAL_COMMISSION_CLAWBACK = . then total_commission_clawback = 0;else total_commission_clawback = TOTAL_COMMISSION_CLAWBACK;
      rename cover_code = cover ;
      rename country_cd = country ; 
      
      FORMAT DATE_DEB_TRIM DATE9. ;
      FORMAT UEP_TRANS_DATE DATE9. ;
      length payfreq $10.;
      
      /* D�finition de plusieurs variables */
      
      term=(year(end_date)-year(start_date))*12 + month(end_date)- month(start_date);
      
      if product_version = " " then 
      scheme = compress(trim(product)||'.'||(trim(Product_line_VERSION )) );
      else scheme = compress(trim(product)||'.'||(trim(Product_VERSION )) );

      
      DATE_DEB_TRIM =intnx( "QTR",(start_date),1) ;
      NBR_MS =intck( "month",(start_date),DATE_DEB_TRIM) ;
      UEP_TRANS_DATE = &Cutoffdate.;
      Exp_Mois = min(month(UEP_trans_date) - month((start_date))+12*year(UEP_trans_date)-12*year((start_date)),term,month((cancel_date)) - month((start_date))+12*year((cancel_date))-12*year((start_date)));
      NB_RT =intck( "month",(start_date),(cancel_date)) ;
      Cohort =year(start_date) ;
      Rule = "r12";
      if term < 0 then delete ;
      if start_date=cancel_date2 then delete ;
      payfreq="MF" ;
      run ; 
      
  /* Traitement des cas o� le term = 1 */
      
data &country._PE_FIXTERM_0 ; 
set &country._PE_FIXTERM ; 
where term=1 ;  
      if EXP_PERIOD > UEP_TRANS_DATE then delete ;
      
      FORMAT  EXP_PERIOD MONYY7.;
      days=day(start_date)/30.4167 ;
      EXP_PERIOD =  intnx('month',(start_date),0,'same');
      Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));
      
      if NB_RT >= 0 then GEP=0 ; 
      else GEP=(1-days)*PREMIUM;
      if NB_RT > 0 then UEP_TBT=0 ;
      else UEP_TBT=Premium-GEP ;
      run;
      
data &country._PE_FIXTERM_1 ; 
set &country._PE_FIXTERM ; 
where term=1 ;
if EXP_PERIOD > UEP_TRANS_DATE then delete ;

FORMAT EXP_PERIOD MONYY7.;
days=day(start_date)/30.4167 ;
EXP_PERIOD =  intnx('month',(end_date),0,'same');
Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));

if NB_RT >= 0 then GEP=0 ;  else GEP=(days)*PREMIUM;
if NB_RT > 0 then UEP_TBT=0 ;
else UEP_TBT=Premium-GEP ;
run;

 /* Traitement des cas o� le term = 0 */

data &country._PE_FIXTERM_5 ; 
set &country._PE_FIXTERM  ; 
where term=0 ;
FORMAT EXP_PERIOD MONYY7.;
EXP_PERIOD =  intnx('month',(start_date),0,'same');
GEP=PREMIUM;
Qtr_Period= Cats(Put(month(EXP_PERIOD),EXP.), year(EXP_PERIOD));
if EXP_PERIOD > UEP_TRANS_DATE then delete ;
if NB_RT > 0 then UEP_TBT=0 ;
else UEP_TBT=Premium-GEP ;
run;


 /* MERGE des cas o� le term = 1 et 0 */
 
data &country._PE_FIXTERM_2 ; 
set &country._PE_FIXTERM_0 &country._PE_FIXTERM_1 &country._PE_FIXTERM_5  ; 
NBR=(year(EXP_PERIOD)-year(start_date))*12 + month(EXP_PERIOD)- month(start_date)+1;
Quart_Dev = IFN(NBR_MS>NBR, 1, int((NBR - NBR_MS)/3 + 2));
drop days NBR_MS NBR  ;
run ; 

proc datasets lib=work memtype=DATA;
delete &country._PE_FIXTERM_0;
run;

proc datasets lib=work memtype=DATA;
delete &country._PE_FIXTERM_1;
run;

proc datasets lib=work memtype=DATA;
delete &country._PE_FIXTERM_5;
run;

/* Traitement des cas o� le term <> 1 */

data &country._PE_FIXTERM_3 ; 
set &country._PE_FIXTERM ; 
where term <> 1 AND term <> 0 ; 
FORMAT  EXP_PERIOD MONYY7. ;
      Do TERM_IN_FORCE = 0 to (EXP_MOIS) ;  /* On change i par Term_in_force directement, on �vite le rename */
          /* calcul EXT_Period : inchang� */    
            EXP_PERIOD =  intnx('month',(start_date),term_in_force,'same'); 
            /* Calcul de Quart_Dev en utilisant la fonction IFN() -> meme chose que fonction SI dans Excel */
            Quart_Dev = IFN(NBR_MS>TERM_IN_FORCE, 1, int((Term_In_Force - NBR_MS)/3 + 2));
            /* Calcul de QTR_Period en une ligne gr�ce au format */
           Qtr_Period = Cats(Put(month(Exp_Period),EXP.), year(Exp_Period));
      
            /* Calcul GEP */ 
       if TERM_IN_FORCE ne NB_RT then do ; 
       
                  UEP_TBT = max(((Term-TERM_IN_FORCE-0.5)/Term),0)*Premium ;
                  if TERM_IN_FORCE=0 then GEP = ((1-(Term-0.5)/Term))*Premium ; 
                  else GEP = (((Term-(TERM_IN_FORCE-1)-0.5)-max((Term-TERM_IN_FORCE-0.5),0))/Term)*Premium ;
           
         end ;
        else do ; 
        
            UEP_TBT = 0 ;
             GEP = 0 ;
             
        
         end; 
      
      output ;       
      end ;
      drop TERM_IN_FORCE NBR_MS ;
      run;

data &country._PE_FIXTERM_4 ; 
set &country._PE_FIXTERM_2 &country._PE_FIXTERM_3 ; 
FORMAT  EXP_PERIOD_2 MONYY7. ;
EXP_PERIOD_2=mdy(month(EXP_PERIOD),1,year(EXP_PERIOD)) ; 
run ; 

proc datasets lib=work memtype=DATA;
delete &country._PE_FIXTERM_2;
run;

proc datasets lib=work memtype=DATA;
delete &country._PE_FIXTERM_3;
run;

proc sql ; 
create table Out_GEP.&country._MF as 
select distinct
country,
cover,
GL_TYPE,
GL_TYPE_NO,
term,
scheme,
UEP_TRANS_DATE,
Cohort,
Rule,
EXP_PERIOD_2 as EXP_PERIOD,
Qtr_Period,
Quart_Dev,
sum(GEP) as GEP,
payfreq
/*LEGACY_SCHEME_CODE,
LEGACY_AGREEMENT_NUMBER,
LEGACY_RENEWAL_NUMBER*/
from &country._PE_FIXTERM_4 
group by country,cover,GL_TYPE,GL_TYPE_NO,term,scheme,UEP_TRANS_DATE,Cohort,Rule,EXP_PERIOD_2,Qtr_Period,Quart_Dev,payfreq /*,LEGACY_SCHEME_CODE, LEGACY_AGREEMENT_NUMBER, LEGACY_RENEWAL_NUMBER*/ ; 
quit ; 

/* Input EA SIMON  */

data &country._EA_MF ;
set &country._PE_FIXTERM_4 ;
retain country product Product_line_VERSION product_version cover start_year GL_TYPE_NO UEP_TRANS_DATE cancelled  term  Qtr_Period  Quart_Dev GEP payfreq UEP_TBT /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER*/  ;
keep   country product Product_line_VERSION product_version cancelled cover GL_TYPE_NO term  Qtr_Period GEP Quart_Dev start_year UEP_TRANS_DATE payfreq UEP_TBT    /*LEGACY_SCHEME_CODE LEGACY_AGREEMENT_NUMBER LEGACY_RENEWAL_NUMBER */ ;
if NB_RT =. then cancelled=1 ;
else cancelled=0 ;
rename 
GL_TYPE_NO=entity
UEP_TRANS_DATE=Date_Cal ;
start_year=year(start_date);
if product_version = " " then product_version=Product_line_VERSION ;
product_version = put(Product_line_VERSION,10.0);
run ;


proc sql ; 
create table EA.&country._EA_MF as 
select distinct 
country,
product,
product_version,
cover,
start_year,
entity,
Date_Cal,
cancelled,
term,
Qtr_Period,
Quart_Dev,
sum(GEP) as GEP,
sum(UEP_TBT) as UEP,
payfreq
/*LEGACY_SCHEME_CODE,
LEGACY_AGREEMENT_NUMBER,
LEGACY_RENEWAL_NUMBER*/
from &country._EA_MF 
group by country,product,product_version,cover,start_year,entity,Date_Cal,cancelled,term,Qtr_Period,Quart_Dev /*,payfreq,LEGACY_SCHEME_CODE,LEGACY_AGREEMENT_NUMBER,LEGACY_RENEWAL_NUMBER */; 
quit ; 


proc datasets lib=work memtype=DATA;
delete &country._PE_FIXTERM_4;
run;

%mend ; 
  
%GEP_MF(country = AUSTRIA);    
%GEP_MF(country = GREECE) ;
%GEP_MF(country = SPAIN) ;
%GEP_MF(country = PORTUGAL) ;
%GEP_MF(country = IRELAND) ;
%GEP_MF(country = GERMANY) ;
%GEP_MF(country = TURKEY) ;
%GEP_MF(country = SWITZERLAND) ;
%GEP_MF(country = ITALY) ;
%GEP_MF(country = DENMARK) ;
%GEP_MF(country = FRANCE);
%GEP_MF(country = UK);









