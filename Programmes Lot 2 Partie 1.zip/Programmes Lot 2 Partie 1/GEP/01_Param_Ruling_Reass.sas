
                                   
/****************************************************************************/
      
      /********************************************/
                  /* A compl�ter par le user */
      /********************************************/       
      %LET Arrete = 2026_06_Prov ; 
      %LET N = 2026 ;
      %let Version_RICP=RICP 20260626;
      %let quarter = Q22026 ;
     

%macro EXPORT_EXCEL(DATA=, OUTFILE=, SHEET=);
	PROC EXPORT DATA = &DATA.
		OUTFILE = &OUTFILE.
		DBMS = XLSX REPLACE ;
		SHEET = &SHEET. ;
	RUN;
%mend;



%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT DATAFILE= &FILE. 
OUT= &OUT. DBMS=xlsx REPLACE; 
SHEET=&ONGLET. ; 
RANGE = "A1:AZ1000000";
RUN;

DATA &OUT.;
SET &OUT.;
IF COUNTRY= ""	AND COVER = "" AND  LANGUAGE ="" THEN DELETE;
RUN;
%MEND;

%let Importation="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Ruling/UEP Rules Production (All Countries).xlsx" ; 
 
%IMPORT_EXCEL(FILE=&Importation.,OUT=UEP_RULES_PROD,ONGLET="Sheet 1");

data uep_rules;
set uep_rules_prod;
keep DIM08;
run;
proc sort data = uep_rules nodupkey;by DIM08 ;quit;


data uep_rules_prod_;
	set uep_rules_prod;
	if DIM08 in("r_12") then DIM08 ="r12";
	else if DIM08 in("r_78p") then DIM08 ="r78";
	else if DIM08 in("r_78m") then DIM08 ="r78m";
	else if DIM08 in("(1-v)*r_12+v*r_78p") then DIM08 ="V";
	else if DIM08 in("1.5*r_12-0.5*r_78p") then DIM08 ="r45m";

DIM11_=DIM11*1;
DIM07_=DIM07*1;

format DIM20_an  $4.;
format DIM20_jour  DIM20_mois  $2.;
format DIM20_new  DATE9. ;

format  DIM19_an $4.;
format  DIM19_jour  DIM19_mois  $2.;
format  DIM19_new DATE9. ;

DIM20_jour=scan(DIM20, 1, '.');
DIM20_mois=scan(DIM20, 2, '.');
DIM20_an=scan(DIM20, 3, '.');
DIM20_new = mdy(DIM20_mois,DIM20_jour,DIM20_an);

DIM19_jour=scan(DIM19, 1, '.');
DIM19_mois=scan(DIM19, 2, '.');
DIM19_an=scan(DIM19, 3, '.');
DIM19_new = mdy(DIM19_mois,DIM19_jour,DIM19_an);

DROP DIM11;
run;

proc sql;
		create table  uep_rules_prod_2 as
		select COUNTRY,COVER,TABLE_NAME,LANGUAGE,DIM01,DIM02,DIM03,DIM04,DIM05,DIM06,DIM07_ as DIM07,DIM08,DIM09,DIM10,DIM11_ as DIM11,DIM12,DIM13,DIM14,DIM15,DIM16,DIM17,DIM18,DIM19_new as DIM19,DIM20_new as DIM20,START_DATE,END_DATE,SORT_NO,TIMESTAMP,USERID,RECORD_VERSION
		from uep_rules_prod_ ;
				
quit; 

DATA Ruling_Forecast;
set uep_rules_prod_2;
where DIM09= "F";
run;
DATA Ruling_PS;
set uep_rules_prod_2;
where DIM09= "P";
run;

DATA Ruling_L;
set uep_rules_prod_2;
where DIM09= "L";
run;

proc sql noprint;
select count(*) into: NBR1 from uep_rules_prod ;
quit;
proc sql noprint;
select count(*) into: NBR2 from Ruling_Forecast;
quit;

proc sql noprint;
select count(*) into: NBR3 from Ruling_PS;
quit;
proc sql noprint;
select count(*) into: NBR4 from Ruling_L;
quit;

%put NOTE: la table uep_rules_prod contient &NBR1. lignes;
%put NOTE: la table Ruling_Forecast contient &NBR2.;
%put NOTE: la table Ruling_PS contient &NBR3.;
%put NOTE: la table Ruling_L contient &NBR4.;
%put NOTE: la table spliter contient %eval(&NBR1. - (&NBR3. + &NBR2 + &NBR4));


%let chemin_output_ruling =~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Ruling;
%EXPORT_EXCEL(data = Ruling_PS, OUTFILE = "&chemin_output_ruling./Ruling_&quarter..xlsx", SHEET = "PS") ;
%EXPORT_EXCEL(data = Ruling_Forecast, OUTFILE = "&chemin_output_ruling./Ruling_&quarter..xlsx", SHEET = "Forecast")



/*########################################################## Parametre Reassurance ##########################################################################*/
/**** Import Carto reass*/
%let Reass="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/GEP/Ruling/&Version_RICP..xlsx";

%MACRO IMP_EXCEL2(FILE=,OUT=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
RUN;
%MEND;
%IMP_EXCEL2(FILE=&Reass.,OUT=cartographie_reassurance,);

	
DATA cartographie_reassurance;
SET cartographie_reassurance ;
attrib   COUNTRY  label="All schemes there are RI schemes / all remaining ones are direct"	;
attrib   DIM01  label="Product + Product Version"	;
attrib   DIM02  label="Cover"	;
attrib   DIM03  label="Original underwritter"	;
attrib   DIM04  label="AXA Reinsurer entity"	;
attrib   DIM05  label="Irrelevant - no longer used"	;
attrib   DIM06  label="Premium rate of RI / UEP"	;
attrib   DIM07  label="Commission / DAC"	;
attrib   DIM08  label="Claim + Claim reserves"	;
attrib   DIM10  label="AXA Reinsurer entity (SAG = P&C  SAL = Life Z16 =P&C for Spain  Z15 = Life for Spain Z11 = P&C  CH = Country R59 = Life)"	;
attrib   DIM16  label="AXA Reinsurer entity except R59 has a G at the end of coding not relevant in the future"	;
attrib   DIM17  label="Product + Cover"	;
attrib   DIM18  label="Product_version"	;
attrib   DIM19  label="different from 0 & 100 & empty : local branches related - Mark confirms"	;

run;

DATA cartographie_reassurance_1;
SET cartographie_reassurance ;
DIM06_ =DIM06*1 ; DIM07_=DIM07*1; DIM08_ =DIM08*1; DIM18_ =DIM18*1;
run;

proc sql;
		create table  cartographie_reassurance_2 as
		select *, COUNTRY as country,DIM01 as  SCHEME1,	DIM02 as Cover,  DIM03 as Original_underwritter, DIM06_ as DIM06 ,DIM07_ as DIM07, DIM08_ as DIM08 
		 from cartographie_reassurance_1 ;			
quit;

DATA cartographie_reassurance_3;
set cartographie_reassurance_2;
	attrib SCHEME2 informat =$10.  format =$10.  label = "SCHEME2" ;
	attrib Product  informat =$10.  format =$10.  label = "Product" ;
	attrib Version   informat =$10.  format =$10.  label = "Version" ;
	attrib SCHEME  informat  =$10. format =$10.  label = "SCHEME" ;
	attrib CLE informat =$20. format =$20. label = "CLE";
		taille =length(SCHEME1) ;
		if length(SCHEME1) = 3  then SCHEME2 = substr(SCHEME1,1,2) ; else SCHEME2 = substr(SCHEME1,1,3); /*		SCHEME2= substr(SCHEME1, 1, ifn(length(SCHEME1) = 3, 2, 3));*/
		Product=SCHEME2;
		Version=DIM18;
		SCHEME=compress(Product!!"."!!DIM18);
		CLE  = compress(Product!!'_'!!Cover!!'_'!!COUNTRY!!'_'!!Original_underwritter);
		QP_rei_PREMIUM=DIM06/100;
		QP_rei_COMM =DIM07/100;
		QP_rei_CLAIM = DIM08/100;
		gl_type_no = Original_underwritter *1;
		
run;




proc sql;
		create table  Parametres_Reas_new as
		select country,Product,Version,SCHEME,CLE,Cover,gl_type_no as Original_underwritter,QP_rei_PREMIUM,QP_rei_COMM,QP_rei_CLAIM/*,gl_type_no*/
		from cartographie_reassurance_3 ;			
quit;




proc sql;
		create table  Entity_Mappingsv2_test as
		select country,TABLE_NAME,LANGUAGE,SCHEME1 as SCHEME2,cover,DIM03 as entity_cd,DIM04,DIM05,DIM06,DIM07,DIM08,DIM09,DIM10,DIM11,DIM12,DIM13,DIM14,DIM15,DIM16,DIM17,DIM18,DIM19,DIM20,TIMESTAMP,USERID,SCHEME as SCHEME3 
		from cartographie_reassurance_3 ;			
quit;

proc sql;
		create table  Export_SAS_2 as
		select country,TABLE_NAME,LANGUAGE,SCHEME1 as SCHEME2, Product, Version ,SCHEME, cover,DIM03 as entity_cd,DIM04,DIM05,DIM06,DIM07,DIM08,DIM09,DIM10,DIM11,DIM12,DIM13,DIM14,DIM15,DIM16,DIM17,DIM18,DIM19,DIM20,TIMESTAMP,USERID
		from cartographie_reassurance_3 ;			
quit;

%let chemin_output_reass =~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&Arrete./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties;

/* export fichier Carto reass*/
%EXPORT_EXCEL(data = cartographie_reassurance, OUTFILE = "&chemin_output_reass./Cartographie_Reassurance.xlsx", SHEET = "Sheet 1")
%EXPORT_EXCEL(data = Export_SAS_2, OUTFILE = "&chemin_output_reass./Cartographie_Reassurance.xlsx", SHEET = "Export_SAS_2")
%EXPORT_EXCEL(data = Entity_Mappingsv2_test, OUTFILE = "&chemin_output_reass./Cartographie_Reassurance.xlsx", SHEET = "Export_SAS")

/* export fichier Reass*/
%EXPORT_EXCEL(data = Parametres_Reas_new, OUTFILE = "&chemin_output_reass./Reassurance.xlsx", SHEET = "Parametres_Reas") ;
