/**********************************************************************************************************************************
######## Name: Reporting TIA claims
######## Author: GNANISSO SARE 
######## Date started :17/03/2025
######## Date finished:------------
######## Context: Construction des inputs de le reporting des claims

/*####################################################################################################################
     ########################################Les 4 last quarters ################################################
########################################################################################################################*/
%let LReseau = ~/NAS/X  ;     
%LET N1 = 2025 ;
%LET N2 = 2026 ;

%LET nb1=1;
%LET nb2=2;
%LET nb3=3;
%LET nb4=4;

%LET vision1=Q325;
%LET vision2=Q425;
%LET vision3=Q126;
%LET vision4=Q226;

%LET quarter1=2025_09_Q4;
%LET quarter2=2025_12_Prov;
%LET quarter3=2026_04_V2;
%LET quarter4=2026_06_Prov;

%LET Q1=2025Q3;
%LET Q2=2025Q4;
%LET Q3=2026Q1;
%LET Q4=2026Q2;

%let Output1=CR_Q325;
%let Output2=CR_Q425;
%let Output3=CR_Q126;
%let Output4=CR_Q226;

%let month1=08;
%let day1=29;
%let yr1=2025;

%let month2=12;
%let day2=26;
%let yr2=2025;

%let month3=03;
%let day3=27;
%let yr3=2026;

%let month4=06;
%let day4=26;
%let yr4=2026;

%Let YM_SUP1=202508 ;
%Let YM_INF1=202408 ;

%Let YM_SUP2=202512 ;
%Let YM_INF2=202412 ;

%Let YM_SUP3=202603 ;
%Let YM_INF3=202503 ;

%Let YM_SUP4=202606 ;
%Let YM_INF4=202506 ;


%MACRO IMPORT_EXCEL(FILE=,OUT=,ONGLET=,);
PROC IMPORT                 
DATAFILE= &FILE.
OUT= &OUT. 
DBMS=xlsx REPLACE;
SHEET=&ONGLET. ;
RUN;
%MEND;

%MACRO biblio(output=,quarter=,nb=,);
LIBNAME &output. "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/&quarter./02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";
LIBNAME TIA_&nb. "&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/2026_04_V2/02_Elements_Techniques/TIA/Extraction Donnees/TIA";
*LIBNAME GEP_&nb. "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&quarter./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/EA";
LIBNAME GEP_&nb. "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&quarter./02_Elements_Techniques/TIA/Arrete reel/GEP/Output/DAAP";
LIBNAME Sin_&nb. "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/&quarter./02_Elements_Techniques/TIA/Extraction Donnees/Claims Extracts";
%IMPORT_EXCEL(FILE="&LReseau./08.Progammes/INTERNATIONAL/06_Inventaire CLP/2026_04_V2/02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Model Properties/SDB.xlsx",OUT=flag_legacy_&nb.,ONGLET="flag_legacy");
%MEND;

%biblio(output=&output1.,quarter=&quarter1.,nb=&nb1.);
%biblio(output=&output2.,quarter=&quarter2.,nb=&nb2.);
%biblio(output=&output3.,quarter=&quarter3.,nb=&nb3.);
%biblio(output=&output4.,quarter=&quarter4.,nb=&nb4.);


%macro cover_import(nb=,);
Proc SQl;
create table Ref_Cover_&nb. AS
select distinct cover as covmd_cover_code, cover_name
from Tia_&nb..carto_tia;
quit;

DATA Ref_Cover_&nb.;
SET Ref_Cover_&nb.;
if covmd_cover_code ="DT" then cover_name ="Disability";
run;  
%MEND;

%cover_import(nb=&nb1.);
%cover_import(nb=&nb2.);
%cover_import(nb=&nb3.);
%cover_import(nb=&nb4.);

%let Import_00="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/01_Mappings/Mapping cover TIA.xlsx";
%let Import_01="~/NAS/X/08.Progammes/INTERNATIONAL/01_Equipe CLP-ALHIS/01_General/Taux de change/2026/Fx - Reel Mai 2026.xlsx"; 
%let Import_02="~/NAS/X/08.Progammes/INTERNATIONAL/10_TABLE_ID/Table_ID.xlsx";

%IMPORT_EXCEL(FILE=&Import_00.,OUT=Mappings,ONGLET="Feuil1");
%IMPORT_EXCEL(FILE=&Import_01.,OUT=exchange,ONGLET="DALI Reel Exercice");
%IMPORT_EXCEL(FILE=&Import_02.,OUT=TABLEID,ONGLET="Table ID");

data codes_devises;
    input COUNTRY $ DEVISE $;
    datalines;
    DE EUR
    AT EUR
    BE EUR
    BG BGN
    CY EUR
    HR HRK
    DK DKK
    ES EUR
    EE EUR
    FI EUR
    FR EUR
    GR EUR
    HU HUF
    IE EUR
    IT EUR
    LV EUR
    LT EUR
    LU EUR
    MT EUR
    CO COP
    UK GBP
    TR TRY
    NO NOK
    NI NIO
    NL EUR
    PL PLN
    PT EUR
    CZ CZK
    RO RON
    SK EUR
    SI EUR
    SE SEK
    CH CHF
    MX MXN
    CA CAD
    ;
run;

proc sql;
create table tauxdechange as
select a.COUNTRY, a.devise, b.YTD_VALUE
from codes_devises a
left join EXCHANGE b
on a.DEVISE = b.CURRENCY2;
quit;


/*####################################################################################################################
     ########################################QUARTERLY RESERVES SUMMARY################################################
########################################################################################################################*/
%macro reserves_summary(output=,quarter=, yr=, month=, day=,nb=,vision=);

data wps_daap_case_reserves_&vision.;
set &Output..wps_daap_case_reserves_&yr.&month.&day.;
Year=YEAR(Incident_date);
if month(Incident_date) in (1, 2, 3) then quarter = cats(Year, 'Q1');
if month(Incident_date) in (4, 5, 6) then quarter = cats(Year, 'Q2');
if month(Incident_date) in (7, 8, 9) then quarter = cats(Year, 'Q3');
if month(Incident_date) in (10, 11, 12) then quarter = cats(Year, 'Q4');
run;

proc sql ; 
create table wps_daap_case_reserves_&vision. as
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from wps_daap_case_reserves_&vision.  t1 
left join FLAG_LEGACY_&nb. t8 on (t1.country=t8.country AND t1.scheme=t8.scheme and t1.Cover=t8.Cover) ;
quit ;

Data wps_daap_case_reserves_&vision.;
set wps_daap_case_reserves_&vision. ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

Data wps_daap_case_reserves_&vision.;
set wps_daap_case_reserves_&vision. ;
drop  RPP Flag_Macao;
run ;

Data wps_daap_case_reserves_&vision.;
set wps_daap_case_reserves_&vision. ;
where country not in ("CH") and LEGACY_SCHEME_BOOK="TIA" ; /*la DAAP n'est pas responsable du calcul de la suisse, pour les autres c'est encore du off-system et nous n'avons pas le sign-off de l'IT (donn�es non fiables)*/
IF   Country="" then delete ;
run ;

proc sql ; 
create table  CR_IBNR_&vision. as 
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from &Output..WPS_DAAP_IBNR_&yr.&month.&day.  t1 
left join FLAG_LEGACY_&nb. t8 on (t1.country=t8.country AND t1.SCHEME=t8.scheme and t1.cover=t8.Cover) ;
quit ; 

DATA CR_IBNR_&vision. ;
set CR_IBNR_&vision.  ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

DATA CR_IBNR_&vision. ;
set CR_IBNR_&vision.  ;
drop RPP Flag_Macao;
run ;

data CR_IBNR_&vision. ;
set CR_IBNR_&vision. ;
where country not in ("CH") and LEGACY_SCHEME_BOOK="TIA" ; /*la DAAP n'est pas responsable du calcul de la suisse, pour les autres c'est encore du off-system et nous n'avons pas le sign-off de l'IT (donn�es non fiables)*/
IF   Country="" then delete ;
run;

data CR_IBNR_&vision.;
set CR_IBNR_&vision. ;
/*quarter=substr(Incident_Quarter,6,1)*1;*/
quarter=Incident_Quarter;
run ;

%macro claims_extraction (Country=,) ; 

/* La partie Claims Paid  */

data CR_PAID_&Country.;
KEEP Country SCHEME cover Year quarter GL_TYPE_NO Entity Totl_Amnt_Pd_Gross ;
set wps_daap_case_reserves_&vision.;
where Country="&Country." ;
GL_TYPE_NO= Entity_CD*1 ;
run ;

Proc sql; 
create table CR_PAID_&Country._2 AS
select country, cover,Scheme, Year,quarter, GL_TYPE_NO,Entity, "PAID" as POSTE ,sum(Totl_Amnt_Pd_Gross) AS MONTANT
from CR_PAID_&Country.
group by country, cover,Scheme, Year, GL_TYPE_NO,Entity, POSTE,Year,quarter;
quit;

Proc SQL; Create Table CR_PAID_&Country._3 As
Select distinct a.*,b.partner_sales_name as Agent_Name,c.cover_name 
From CR_PAID_&Country._2 a 
Left Join TIA_&nb..CARTO_TIA b On (a.country=b.Country and a.SCHEME=b.scheme)
Left Join Ref_Cover_&nb. c On (a.cover=c.covmd_cover_code);
Quit;

/* La partie  ICOP , RBNP ,IBNR  */

data CR_&Country.;
KEEP Country SCHEME cover Year quarter Rsrv_Typ GL_TYPE_NO Entity Rsrv_Amt_Gross ;
set wps_daap_case_reserves_&vision.;
where Country="&Country." AND Rsrv_Typ IN ("ICOP","RBNP");
Year=YEAR(Incident_date); 
GL_TYPE_NO= Entity_CD*1 ;
run ;

/* IBNR */

%if &quarter.=2025_04_V2 and &country.=GR %then %do;
PROC IMPORT 
DATAFILE="~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/2025_04_V2/02_Elements_Techniques/TIA/Arrete reel/RESERVES/REPORTING/Datalake/GR/WPS_DAAP_IBNR_20250328_GR.xlsx"
OUT=GR_IBNR_IMPOR
DBMS=XLSX
REPLACE;
RUN;
DATA CR_IBNR_&Country.;
SET GR_IBNR_IMPOR;
WHERE Country="&Country.";
Year = input(substr(Incident_Quarter,1,4), 4.);
GL_TYPE_NO = input(Entity_CD, best.);
KEEP Country SCHEME cover Year quarter GL_TYPE_NO Entity Rsrv_Typ Rsrv_Amt_Gross;
RUN;
%end;
%else %do; 
data CR_IBNR_&Country.;
KEEP Country SCHEME cover Year quarter GL_TYPE_NO Entity Rsrv_Typ Rsrv_Amt_Gross  ;
set CR_IBNR_&vision. ;
where Country="&Country." ;
Year=substr(Incident_Quarter,1,4)*1; 
GL_TYPE_NO= Entity_CD*1 ;
run ;
%end;

data CR_RESERVES_&Country.; SET CR_&Country. CR_IBNR_&Country. ; run ;

Proc sql; 
create table CR_RESERVES_&Country._2 AS
select country, cover,Scheme, Year,quarter, GL_TYPE_NO,Entity, Rsrv_Typ as POSTE ,sum(Rsrv_Amt_Gross) AS MONTANT
from CR_RESERVES_&Country.
group by country, cover,Scheme, Year,quarter, GL_TYPE_NO, POSTE,Entity,Year;
quit;

Proc SQL; Create Table CR_RESERVES_&Country._3 As
Select distinct a.*,b.partner_sales_name as Agent_Name,c.cover_name 
From CR_RESERVES_&Country._2 a 
Left Join TIA_&nb..CARTO_TIA b On (a.country=b.Country and a.SCHEME=b.scheme)
Left Join Ref_Cover_&nb. c On (a.cover=c.covmd_cover_code);
Quit;

data Reserve_Flux_&Country. ; 
set CR_PAID_&Country._3 CR_RESERVES_&Country._3   ; 
run ;

proc sort data = Reserve_Flux_&Country. nodupkey ; by country cover cover_name Scheme Agent_Name Year quarter GL_TYPE_NO Entity POSTE ; run;

proc transpose data=Reserve_Flux_&Country. out=Reserve_Flux_&Country. (drop=_NAME_ _LABEL_) ;
var MONTANT;
id POSTE;
by country cover cover_name Scheme Agent_Name Year quarter GL_TYPE_NO Entity;
run; 

Data Reserve_Flux_&Country._&nb.;
set Reserve_Flux_&Country. ;
if PAID = . then PAID = 0;
if IBNR = . then IBNR = 0;
if ICOP = . then ICOP = 0;
if RBNP = . then RBNP = 0;
Charge_clot = PAID + IBNR + ICOP + RBNP ;
drop POSTE ;
if cover in ("DU","ZH","DZ","DY") THEN cover_name="Disability" ;
if cover in ("TR","TS") THEN cover_name="Pecuniary Loss" ;
if cover in ("RV") THEN cover_name="Unemployment" ;
if cover in ("FF") THEN cover_name="Death" ;
run;

Data Reserve_Flux_&Country._&nb.;
set Reserve_Flux_&Country._&nb. ;
RENAME
PAID = PAID_&vision.
IBNR = IBNR_&vision.
ICOP = ICOP_&vision.
RBNP = RBNP_&vision.
Charge_clot = Charge_clot_&vision;
run;

%mend ;

%claims_extraction(Country=GR);
%claims_extraction(Country=CH);
%claims_extraction(Country=DK);
%claims_extraction(Country=ES);
%claims_extraction(Country=IE); 
%claims_extraction(Country=NI);
%claims_extraction(Country=NL);
%claims_extraction(Country=NO);
%claims_extraction(Country=PT);
%claims_extraction(Country=TR);
%claims_extraction(Country=UK);
%claims_extraction(Country=FI);
%claims_extraction(Country=BE);
%claims_extraction(Country=MX);
%claims_extraction(Country=CO);
%claims_extraction(Country=AT); 
%claims_extraction(Country=IT); 
%claims_extraction(Country=DE);
%claims_extraction(Country=PL);
%claims_extraction(Country=SE);
%claims_extraction(Country=FR);

data Reserves_&quarter.;
set  Reserve_Flux_AT_&nb.
     Reserve_Flux_SE_&nb.
     Reserve_Flux_IT_&nb.
     Reserve_Flux_PL_&nb.
     Reserve_Flux_FR_&nb.
     Reserve_Flux_DE_&nb.
     Reserve_Flux_CH_&nb.
     Reserve_Flux_DK_&nb.
     Reserve_Flux_FI_&nb.
     Reserve_Flux_ES_&nb.
     Reserve_Flux_GR_&nb.
     Reserve_Flux_IE_&nb.
     Reserve_Flux_NI_&nb.
     Reserve_Flux_NL_&nb.
     Reserve_Flux_NO_&nb.
     Reserve_Flux_PT_&nb.
     Reserve_Flux_TR_&nb.
     Reserve_Flux_UK_&nb.
     Reserve_Flux_BE_&nb.
     Reserve_Flux_CO_&nb.
     Reserve_Flux_MX_&nb.;
run ;
%Mend;

%reserves_summary(output=&output1.,quarter=&quarter1., yr=&yr1., month=&month1., day=&day1.,nb=&nb1.,vision=&vision1.);
%reserves_summary(output=&output2.,quarter=&quarter2., yr=&yr2., month=&month2., day=&day2.,nb=&nb2.,vision=&vision2.);
%reserves_summary(output=&output3.,quarter=&quarter3., yr=&yr3., month=&month3., day=&day3.,nb=&nb3.,vision=&vision3.);
%reserves_summary(output=&output4.,quarter=&quarter4., yr=&yr4., month=&month4., day=&day4.,nb=&nb4.,vision=&vision4.);

proc sql;
    create table FLUX_ALL_QUARTERS as
    select 
        coalesce(a.Country, b.Country, c.Country, d.Country) as Country ,
        coalesce(a.cover, b.cover, c.cover, d.cover) as cover,
        coalesce(a.cover_name, b.cover_name, c.cover_name, d.cover_name) as cover_name,
        coalesce(a.SCHEME, b.SCHEME, c.SCHEME, d.SCHEME) as SCHEME,
        coalesce(a.Agent_Name, b.Agent_Name, c.Agent_Name, d.Agent_Name) as Agent_Name,
        coalesce(a.Year, b.Year, c.Year, d.Year) as Year,
        coalesce(a.quarter, b.quarter, c.quarter, d.quarter) as quarter,
        coalesce(a.GL_TYPE_NO, b.GL_TYPE_NO, c.GL_TYPE_NO, d.GL_TYPE_NO) as GL_TYPE_NO,
        coalesce(a.Entity, b.Entity, c.Entity, d.Entity) as Entity,
        a.PAID_&vision1., b.PAID_&vision2., c.PAID_&vision3., d.PAID_&vision4.,
        a.ICOP_&vision1., b.ICOP_&vision2., c.ICOP_&vision3., d.ICOP_&vision4.,
        a.RBNP_&vision1., b.RBNP_&vision2., c.RBNP_&vision3., d.RBNP_&vision4.,
        a.IBNR_&vision1., b.IBNR_&vision2., c.IBNR_&vision3., d.IBNR_&vision4.,
        a.Charge_clot_&vision1., b.Charge_clot_&vision2., c.Charge_clot_&vision3., d.Charge_clot_&vision4.
    from 
        Reserves_&quarter1. as a
    full join 
        Reserves_&quarter2. as b on a.Country = b.Country and a.cover = b.cover and a.cover_name = b.cover_name and a.SCHEME = b.SCHEME 
        and a.Agent_Name = b.Agent_Name and a.Year = b.Year and a.quarter = b.quarter and a.GL_TYPE_NO = b.GL_TYPE_NO
        and a.Entity=b.Entity
    full join 
        Reserves_&quarter3. as c on a.Country = c.Country and a.cover = c.cover and a.cover_name = c.cover_name and a.SCHEME = c.SCHEME 
        and a.Agent_Name = c.Agent_Name and a.Year = c.Year and a.quarter = c.quarter and a.GL_TYPE_NO = c.GL_TYPE_NO
        and a.Entity=c.Entity
    full join 
        Reserves_&quarter4. as d on a.Country = d.Country and a.cover = d.cover and a.cover_name = d.cover_name and a.SCHEME = d.SCHEME 
        and a.Agent_Name = d.Agent_Name and a.Year = d.Year and a.quarter = d.quarter and a.GL_TYPE_NO = d.GL_TYPE_NO
        and a.Entity=d.Entity;
quit;

Data FLUX_ALL_QUARTERS;
set FLUX_ALL_QUARTERS ;
if PAID_&vision1. = . then PAID_&vision1. = 0;
if PAID_&vision2. = . then PAID_&vision2. = 0;
if PAID_&vision3. = . then PAID_&vision3. = 0;
if PAID_&vision4. = . then PAID_&vision4. = 0;
if ICOP_&vision1. = . then ICOP_&vision1. = 0;
if ICOP_&vision2. = . then ICOP_&vision2. = 0;
if ICOP_&vision3. = . then ICOP_&vision3. = 0;
if ICOP_&vision4. = . then ICOP_&vision4. = 0;
if RBNP_&vision1. = . then RBNP_&vision1. = 0;
if RBNP_&vision2. = . then RBNP_&vision2. = 0;
if RBNP_&vision3. = . then RBNP_&vision3. = 0;
if RBNP_&vision4. = . then RBNP_&vision4. = 0;
if IBNR_&vision1. = . then IBNR_&vision1. = 0;
if IBNR_&vision2. = . then IBNR_&vision2. = 0;
if IBNR_&vision3. = . then IBNR_&vision3. = 0;
if IBNR_&vision4. = . then IBNR_&vision4. = 0;
if Charge_clot_&vision1. = . then Charge_clot_&vision1. = 0;
if Charge_clot_&vision2. = . then Charge_clot_&vision2. = 0;
if Charge_clot_&vision3. = . then Charge_clot_&vision3. = 0;
if Charge_clot_&vision4. = . then Charge_clot_&vision4. = 0;
run;

proc sql;
create table FLUX_ALL_QUARTERS as
select a.*, b.YTD_VALUE
from FLUX_ALL_QUARTERS a
left join tauxdechange b
on a.COUNTRY = b.COUNTRY;
quit;

Data FLUX_ALL_QUARTERS;
SET FLUX_ALL_QUARTERS;
PAID_&vision1.=PAID_&vision1.*YTD_VALUE;
PAID_&vision2.=PAID_&vision2.*YTD_VALUE;
PAID_&vision3.=PAID_&vision3.*YTD_VALUE;
PAID_&vision4.=PAID_&vision4.*YTD_VALUE;
ICOP_&vision1.=ICOP_&vision1.*YTD_VALUE;
ICOP_&vision2.=ICOP_&vision2.*YTD_VALUE;
ICOP_&vision3.=ICOP_&vision3.*YTD_VALUE;
ICOP_&vision4.=ICOP_&vision4.*YTD_VALUE;
RBNP_&vision1.=RBNP_&vision1.*YTD_VALUE;
RBNP_&vision2.=RBNP_&vision2.*YTD_VALUE;
RBNP_&vision3.=RBNP_&vision3.*YTD_VALUE;
RBNP_&vision4.=RBNP_&vision4.*YTD_VALUE;
IBNR_&vision1.=IBNR_&vision1.*YTD_VALUE;
IBNR_&vision2.=IBNR_&vision2.*YTD_VALUE;
IBNR_&vision3.=IBNR_&vision3.*YTD_VALUE;
IBNR_&vision4.=IBNR_&vision4.*YTD_VALUE;
Charge_clot_&vision1.=Charge_clot_&vision1.*YTD_VALUE;
Charge_clot_&vision2.=Charge_clot_&vision2.*YTD_VALUE;
Charge_clot_&vision3.=Charge_clot_&vision3.*YTD_VALUE;
Charge_clot_&vision4.=Charge_clot_&vision4.*YTD_VALUE;
run;

/*####################################################################################################################
     ########################################SINISTRES PAYES ACCOUNTING################################################
########################################################################################################################*/

%MACRO ACCOUNTING_payment(nb=,q=,quarter=,vision=);

%MACRO recuperation_claims (country=);
DATA &country._clmhdr;
SET Sin_&nb..&country._clmhdr;
KEEP Country cla_case_no cover scheme incident_date uw_company Legal_Entity;
RUN;

DATA &country._clmhdr;
SET &country._clmhdr;
Occurence_month = month(incident_date);
Occurence_year = year(incident_date);
if Occurence_month in (1,2,3) then quarter_occurrence = cats(Occurence_year, 'Q1');
if Occurence_month in (4,5,6) then quarter_occurrence = cats(Occurence_year, 'Q2');
if Occurence_month in (7,8,9) then quarter_occurrence = cats(Occurence_year, 'Q3');
if Occurence_month in (10,11,12) then quarter_occurrence = cats(Occurence_year, 'Q4');
RUN;

DATA &country._clmtrns;
SET Sin_&nb..&country._clmtrns;
KEEP Country cla_case_no TRANS_DATE currency_amt gross_amt;
RUN;

DATA &country._clmtrns;
SET &country._clmtrns;
GL_TYPE_NO=uw_company;
Transaction_month = month(TRANS_DATE);
Transaction_year = year(TRANS_DATE);
gross_amt=-gross_amt;
currency_amt=-currency_amt;
if Transaction_month in (1,2,3) then quarter_transaction = cats(Transaction_year, 'Q1');
if Transaction_month in (4,5,6) then quarter_transaction = cats(Transaction_year, 'Q2');
if Transaction_month in (7,8,9) then quarter_transaction= cats(Transaction_year, 'Q3');
if Transaction_month in (10,11,12) then quarter_transaction = cats(Transaction_year, 'Q4');
RUN;

Proc SQL;
    Create Table &country._aggregated_clmtrns As
    Select distinct a.Country, a.cla_case_no as claim_number, a.Transaction_year, a.quarter_transaction, sum(a.gross_amt) AS Claim_paid
    From &country._clmtrns a
    Group by a.Country, a.cla_case_no, a.Transaction_year, a.quarter_transaction;
Quit;

PROC SQL;
CREATE TABLE &country._final_clmhdr AS
SELECT a.*, b.Transaction_year, b.quarter_transaction, b.Claim_paid
FROM &country._clmhdr AS a
LEFT JOIN &country._aggregated_clmtrns AS b
ON a.cla_case_no = b.claim_number;
QUIT;

DATA &country._final_clmhdr;
    SET &country._final_clmhdr;
    IF NOT MISSING(Claim_paid) THEN OUTPUT;
RUN;

Proc SQL; Create Table &country._final_clmhdr As
Select distinct a.*,b.partner_sales_name as Agent_name,c.cover_name 
From &country._final_clmhdr a 
Left Join TIA_&nb..CARTO_TIA b On (a.country=b.Country and a.SCHEME=b.scheme)
Left Join Ref_Cover_&nb. c On (a.cover=c.covmd_cover_code);
Quit;

DATA &country._final_clmhdr;
SET &country._final_clmhdr;
if cover in ("DU","ZH","DZ","DY") THEN cover_name="Disability" ;
if cover in ("TR","TS") THEN cover_name="Pecuniary Loss" ;
if cover in ("RV") THEN cover_name="Unemployment" ;
if cover in ("FF") THEN cover_name="Death" ;
RUN;

DATA &country._final_clmhdr;
SET &country._final_clmhdr;
if quarter_transaction="&Q."; 
Run;

proc sql ; 
create table  &country._final_clmhdr as 
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from &country._final_clmhdr  t1 
left join FLAG_LEGACY_&nb. t8 on (t1.country=t8.country AND t1.SCHEME=t8.scheme and t1.cover=t8.Cover) ;
quit ; 

DATA &country._final_clmhdr ;
set &country._final_clmhdr  ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

DATA &country._final_clmhdr ;
set &country._final_clmhdr  ;
drop RPP Flag_Macao;
run ;

data &country._final_clmhdr ;
set &country._final_clmhdr ;
where country not in ("CH") and LEGACY_SCHEME_BOOK="TIA" ; /*la DAAP n'est pas responsable du calcul de la suisse, pour les autres c'est encore du off-system et nous n'avons pas le sign-off de l'IT (donn�es non fiables)*/
IF   Country="" then delete ;
run;

DATA &country._final_clmhdr;
SET &country._final_clmhdr;
GL_TYPE_NO=uw_company;
Entity=Legal_Entity;
Run;

Proc sql; 
create table &country._final_clmhdr_&nb. AS
select country, cover, cover_name, Scheme,Agent_Name,Occurence_year,quarter_occurrence,Transaction_year ,quarter_transaction,GL_TYPE_NO,Entity,LEGACY_SCHEME_BOOK,sum(Claim_paid) AS Claim_paid
from &country._final_clmhdr
group by country, cover, cover_name, Scheme,Agent_Name,Occurence_year,quarter_occurrence,Transaction_year ,quarter_transaction,GL_TYPE_NO,Entity,LEGACY_SCHEME_BOOK;
quit;
%MEND;
%recuperation_claims(Country=GR);
%recuperation_claims(Country=CH);
%recuperation_claims(Country=DK);
%recuperation_claims(Country=ES);
%recuperation_claims(Country=IE); 
%recuperation_claims(Country=NI);
%recuperation_claims(Country=NL);
%recuperation_claims(Country=NO);
%recuperation_claims(Country=PT);
%recuperation_claims(Country=TR);
%recuperation_claims(Country=UK);
%recuperation_claims(Country=FI);
%recuperation_claims(Country=BE);
%recuperation_claims(Country=MX);
%recuperation_claims(Country=CO);
%recuperation_claims(Country=AT); 
%recuperation_claims(Country=IT); 
%recuperation_claims(Country=DE);
%recuperation_claims(Country=PL);
%recuperation_claims(Country=SE);
%recuperation_claims(Country=FR);


/* �tape 1 : Cr�ation de la nouvelle variable Entity_New */

DATA Claims_&quarter._all;
SET GR_final_clmhdr_&nb. 
    CH_final_clmhdr_&nb. 
    DK_final_clmhdr_&nb.
    ES_final_clmhdr_&nb.
    IE_final_clmhdr_&nb.
    NI_final_clmhdr_&nb.
    NL_final_clmhdr_&nb.
    NO_final_clmhdr_&nb.
    PT_final_clmhdr_&nb.
    TR_final_clmhdr_&nb.
    UK_final_clmhdr_&nb.
    FI_final_clmhdr_&nb.
    BE_final_clmhdr_&nb.
    MX_final_clmhdr_&nb.
    CO_final_clmhdr_&nb.
    AT_final_clmhdr_&nb.
    IT_final_clmhdr_&nb. 
    DE_final_clmhdr_&nb. 
    PL_final_clmhdr_&nb.
    SE_final_clmhdr_&nb.
    FR_final_clmhdr_&nb. ;
RUN;

DATA Claims_&quarter._all;
SET Claims_&quarter._all ;
RENAME Claim_paid=Claim_paid_&vision.;
RUN;

%MEND;

%ACCOUNTING_payment(nb=&nb1.,q=&Q1.,quarter=&quarter1.,vision=&vision1.);
%ACCOUNTING_payment(nb=&nb2.,q=&Q2.,quarter=&quarter2.,vision=&vision2.);
%ACCOUNTING_payment(nb=&nb3.,q=&Q3.,quarter=&quarter3.,vision=&vision3.);
%ACCOUNTING_payment(nb=&nb4.,q=&Q4.,quarter=&quarter4.,vision=&vision4.);

proc sql;
    create table CLAIMS_PAID_ALL_QUARTERS as
    select 
        coalesce(a.Country, b.Country, c.Country, d.Country) as Country ,
        coalesce(a.cover, b.cover, c.cover, d.cover) as cover,
        coalesce(a.cover_name, b.cover_name, c.cover_name, d.cover_name) as cover_name,
        coalesce(a.SCHEME, b.SCHEME, c.SCHEME, d.SCHEME) as SCHEME,
        coalesce(a.Agent_Name, b.Agent_Name, c.Agent_Name, d.Agent_Name) as Agent_Name,
        coalesce(a.Occurence_year, b.Occurence_year, c.Occurence_year, d.Occurence_year) as Occurence_year,
        coalesce(a.quarter_occurrence, b.quarter_occurrence, c.quarter_occurrence, d.quarter_occurrence) as quarter_occurrence,
        coalesce(a.Transaction_year, b.Transaction_year, c.Transaction_year, d.Transaction_year) as Transaction_year,
        coalesce(a.quarter_transaction, b.quarter_transaction, c.quarter_transaction, d.quarter_transaction) as quarter_transaction,
        coalesce(a.GL_TYPE_NO, b.GL_TYPE_NO, c.GL_TYPE_NO, d.GL_TYPE_NO) as GL_TYPE_NO,
        coalesce(a.Entity, b.Entity, c.Entity, d.Entity) as Entity,
        a.Claim_paid_&vision1., b.Claim_paid_&vision2., c.Claim_paid_&vision3., d.Claim_paid_&vision4.
    from 
        Claims_&quarter1._all as a
    full join 
        Claims_&quarter2._all as b on a.Country = b.Country and a.cover = b.cover and a.cover_name = b.cover_name and a.SCHEME = b.SCHEME 
        and a.Agent_Name = b.Agent_Name and a.Occurence_year=b.Occurence_year and a.quarter_occurrence = b.quarter_occurrence and a.Transaction_year = b.Transaction_year and a.quarter_transaction = b.quarter_transaction and a.GL_TYPE_NO = b.GL_TYPE_NO
        and a.Entity=b.Entity
    full join 
        Claims_&quarter3._all as c on a.Country = c.Country and a.cover = c.cover and a.cover_name = c.cover_name and a.SCHEME = c.SCHEME 
        and a.Agent_Name = c.Agent_Name and a.Occurence_year=c.Occurence_year and a.quarter_occurrence = c.quarter_occurrence and a.Transaction_year = c.Transaction_year and a.quarter_transaction = c.quarter_transaction and a.GL_TYPE_NO = c.GL_TYPE_NO
        and a.Entity=c.Entity
    full join 
        Claims_&quarter4._all as d on a.Country = d.Country and a.cover = d.cover and a.cover_name = d.cover_name and a.SCHEME = d.SCHEME 
        and a.Agent_Name = d.Agent_Name and a.Occurence_year=d.Occurence_year and a.quarter_occurrence = d.quarter_occurrence and a.Transaction_year = d.Transaction_year and a.quarter_transaction = d.quarter_transaction and a.GL_TYPE_NO = d.GL_TYPE_NO
        and a.Entity=d.Entity;
quit;

Data CLAIMS_PAID_ALL_QUARTERS;
set CLAIMS_PAID_ALL_QUARTERS ;
if Claim_paid_&vision1. = . then Claim_paid_&vision1. = 0;
if Claim_paid_&vision2. = . then Claim_paid_&vision2. = 0;
if Claim_paid_&vision3. = . then Claim_paid_&vision3. = 0;
if Claim_paid_&vision4. = . then Claim_paid_&vision4. = 0;
run;

proc sql;
create table CLAIMS_PAID_ALL_QUARTERS as
select a.*, b.YTD_VALUE
from CLAIMS_PAID_ALL_QUARTERS a
left join tauxdechange b
on a.COUNTRY = b.COUNTRY;
quit;

Data CLAIMS_PAID_ALL_QUARTERS;
SET CLAIMS_PAID_ALL_QUARTERS;
Claim_paid_&vision1.=Claim_paid_&vision1.*YTD_VALUE;
Claim_paid_&vision2.=Claim_paid_&vision2.*YTD_VALUE;
Claim_paid_&vision3.=Claim_paid_&vision3.*YTD_VALUE;
Claim_paid_&vision4.=Claim_paid_&vision4.*YTD_VALUE;
run;

/*####################################################################################################################
     ########################################Focus on ICOP and RBNP################################################
########################################################################################################################*/
%Macro categorisation(pays=,Output_f=,Output_i=,nb=);
proc sql;
create table liste_&pays._&Output_i. as
select distinct Clm_Nmbr
from &Output_i..CLMHDR_ALL_&pays.;
quit;

proc sql;
create table CLMHDR_ALL_&pays._&nb. as
select distinct a.*, 
case when b.Clm_Nmbr is not null then "Stock"
else "New" 
end as claims_type
from &Output_f..CLMHDR_ALL_&pays. as a
left join liste_&pays._&Output_i. as b
on a.Clm_Nmbr = b.Clm_Nmbr;
quit;
%MEND;

%categorisation(pays=GR,Output_f=&Output2.,Output_i=&Output1.,nb=&nb2.);
%categorisation(pays=CH,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=DK,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=ES,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=IE,Output_f=&Output2.,Output_i=&Output1.,nb=2); 
%categorisation(pays=NI,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=NL,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=NO,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=PT,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=TR,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=UK,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=FI,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=BE,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=MX,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=CO,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=AT,Output_f=&Output2.,Output_i=&Output1.,nb=2); 
%categorisation(pays=IT,Output_f=&Output2.,Output_i=&Output1.,nb=2); 
%categorisation(pays=DE,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=PL,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=SE,Output_f=&Output2.,Output_i=&Output1.,nb=2);
%categorisation(pays=FR,Output_f=&Output2.,Output_i=&Output1.,nb=2);


%categorisation(pays=GR,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=CH,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=DK,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=ES,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=IE,Output_f=&Output3.,Output_i=&Output2.,nb=3); 
%categorisation(pays=NI,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=NL,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=NO,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=PT,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=TR,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=UK,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=FI,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=BE,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=MX,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=CO,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=AT,Output_f=&Output3.,Output_i=&Output2.,nb=3); 
%categorisation(pays=IT,Output_f=&Output3.,Output_i=&Output2.,nb=3); 
%categorisation(pays=DE,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=PL,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=SE,Output_f=&Output3.,Output_i=&Output2.,nb=3);
%categorisation(pays=FR,Output_f=&Output3.,Output_i=&Output2.,nb=3);

%categorisation(pays=GR,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=CH,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=DK,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=ES,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=IE,Output_f=&Output4.,Output_i=&Output3.,nb=4); 
%categorisation(pays=NI,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=NL,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=NO,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=PT,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=TR,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=UK,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=FI,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=BE,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=MX,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=CO,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=AT,Output_f=&Output4.,Output_i=&Output3.,nb=4); 
%categorisation(pays=IT,Output_f=&Output4.,Output_i=&Output3.,nb=4); 
%categorisation(pays=DE,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=PL,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=SE,Output_f=&Output4.,Output_i=&Output3.,nb=4);
%categorisation(pays=FR,Output_f=&Output4.,Output_i=&Output3.,nb=4);

%MACRO regroupement(quarter=,nb=);
DATA  CLMHDR_&quarter._all;
SET CLMHDR_ALL_GR_&nb. 
    CLMHDR_ALL_CH_&nb.
    CLMHDR_ALL_DK_&nb.
    CLMHDR_ALL_ES_&nb.
    CLMHDR_ALL_IE_&nb.
    CLMHDR_ALL_NI_&nb.
    CLMHDR_ALL_NL_&nb.
    CLMHDR_ALL_NO_&nb.
    CLMHDR_ALL_PT_&nb.
    CLMHDR_ALL_TR_&nb.
    CLMHDR_ALL_UK_&nb.
    CLMHDR_ALL_FI_&nb.
    CLMHDR_ALL_BE_&nb.
    CLMHDR_ALL_MX_&nb.
    CLMHDR_ALL_CO_&nb.
    CLMHDR_ALL_AT_&nb.
    CLMHDR_ALL_IT_&nb.
    CLMHDR_ALL_DE_&nb.
    CLMHDR_ALL_PL_&nb.
    CLMHDR_ALL_SE_&nb.
    CLMHDR_ALL_FR_&nb. ;
RUN;

DATA  CLMHDR_&quarter._all;
SET  CLMHDR_&quarter._all;
IF Rsrv_Typ in ("ICOP","RBNP");
RUN;

proc sql ; 
create table  CLMHDR_&quarter._all as 
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from CLMHDR_&quarter._all  t1 
left join FLAG_LEGACY_&nb. t8 on (t1.country=t8.country AND t1.Schm=t8.Scheme and t1.Cvr_Typ=t8.Cover) ;
quit ; 

DATA CLMHDR_&quarter._all ;
set CLMHDR_&quarter._all  ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

DATA CLMHDR_&quarter._all;
set CLMHDR_&quarter._all;
drop RPP Flag_Macao;
run ;

DATA  CLMHDR_&quarter._all;
SET  CLMHDR_&quarter._all;
IF LEGACY_SCHEME_BOOK="TIA";
RUN;

DATA  CLMHDR_&quarter._all;
SET  CLMHDR_&quarter._all;
DROP SCHEME;
RUN;
%mend;

%regroupement(quarter=&quarter2.,nb=&nb2.);
%regroupement(quarter=&quarter3.,nb=&nb3.);
%regroupement(quarter=&quarter4.,nb=&nb4.);

DATA  CLMHDR_&quarter1._all;
SET &Output1..CLMHDR_ALL_GR 
    &Output1..CLMHDR_ALL_CH
    &Output1..CLMHDR_ALL_DK
    &Output1..CLMHDR_ALL_ES
    &Output1..CLMHDR_ALL_IE
    &Output1..CLMHDR_ALL_NI
    &Output1..CLMHDR_ALL_NL
    &Output1..CLMHDR_ALL_NO
    &Output1..CLMHDR_ALL_PT
    &Output1..CLMHDR_ALL_TR
    &Output1..CLMHDR_ALL_UK
    &Output1..CLMHDR_ALL_FI
    &Output1..CLMHDR_ALL_BE
    &Output1..CLMHDR_ALL_MX
    &Output1..CLMHDR_ALL_CO
    &Output1..CLMHDR_ALL_AT
    &Output1..CLMHDR_ALL_IT
    &Output1..CLMHDR_ALL_DE
    &Output1..CLMHDR_ALL_PL
    &Output1..CLMHDR_ALL_SE
    &Output1..CLMHDR_ALL_FR ;
RUN;

DATA  CLMHDR_&quarter1._all;
SET  CLMHDR_&quarter1._all;
IF Rsrv_Typ in ("ICOP","RBNP");
RUN;

proc sql ; 
create table  CLMHDR_&quarter1._all as 
select distinct
t1.*,
t8.RPP AS RPP,
t8.Flag_Macao AS Flag_Macao
from CLMHDR_&quarter1._all  t1 
left join FLAG_LEGACY_&nb1. t8 on (t1.country=t8.country AND t1.Schm=t8.scheme and t1.Cvr_Typ=t8.Cover) ;
quit ; 

DATA CLMHDR_&quarter1._all;
set CLMHDR_&quarter1._all ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

DATA CLMHDR_&quarter1._all;
set CLMHDR_&quarter1._all;
drop RPP Flag_Macao;
run ;

DATA  CLMHDR_&quarter1._all;
SET  CLMHDR_&quarter1._all;
IF LEGACY_SCHEME_BOOK="TIA";
RUN;

DATA  CLMHDR_&quarter1._all;
SET  CLMHDR_&quarter1._all;
DROP SCHEME;
RUN;

%Macro Partner_added(quarter=,nb=);
Proc SQL; Create Table CLMHDR_&quarter._all As
Select distinct a.*,b.partner_sales_name as Agent_Name,c.cover_name 
From CLMHDR_&quarter._all a 
Left Join TIA_&nb..CARTO_TIA b On (a.country=b.Country and a.Schm=b.scheme)
Left Join Ref_Cover_&nb. c On (a.Cvr_Typ=c.covmd_cover_code);
Quit;

Data CLMHDR_&quarter._all;
SET CLMHDR_&quarter._all;
if Cvr_Typ in ("DU","ZH","DZ","DY") THEN cover_name="Disability" ;
if Cvr_Typ in ("TR","TS") THEN cover_name="Pecuniary Loss" ;
if Cvr_Typ in ("RV") THEN cover_name="Unemployment" ;
if Cvr_Typ in ("FF") THEN cover_name="Death" ;
run;

proc sql;
create table CLMHDR_&quarter._all as
select a.*, b.YTD_VALUE
from CLMHDR_&quarter._all a
left join tauxdechange b
on a.COUNTRY = b.COUNTRY;
quit;

Data CLMHDR_&quarter._all;
SET CLMHDR_&quarter._all;
Totl_Amnt_Pd=Totl_Amnt_Pd*YTD_VALUE;
Totl_Bnfts_Amnt_Pd=Totl_Bnfts_Amnt_Pd*YTD_VALUE;
Mnthly_Bnft=Mnthly_Bnft*YTD_VALUE;
Rsrv_Amt=Rsrv_Amt*YTD_VALUE;
Otstndng_Balnc=Otstndng_Balnc*YTD_VALUE;
POTENTIAL_CLM_AMT=POTENTIAL_CLM_AMT*YTD_VALUE;
run;

%mend;

%Partner_added(quarter=&quarter1,nb=&nb1.);
%Partner_added(quarter=&quarter2,nb=&nb2.);
%Partner_added(quarter=&quarter3,nb=&nb3.);
%Partner_added(quarter=&quarter4,nb=&nb4.);



/*####################################################################################################################
     ########################################GEP  SIDE################################################
########################################################################################################################*/
%MACRO recuperation_GEP(quarter=, nb=, YM_SUP=, YM_INF=, vision=);

DATA GEP_FLUX_&quarter._all;
SET GEP_&nb..HISTO_FLUX_GR
    GEP_&nb..HISTO_FLUX_CH 
    GEP_&nb..HISTO_FLUX_DK
    GEP_&nb..HISTO_FLUX_ES
    GEP_&nb..HISTO_FLUX_IE
    GEP_&nb..HISTO_FLUX_NI
    GEP_&nb..HISTO_FLUX_NL
    GEP_&nb..HISTO_FLUX_NO
    GEP_&nb..HISTO_FLUX_PT
    GEP_&nb..HISTO_FLUX_TR
    GEP_&nb..HISTO_FLUX_UK
    GEP_&nb..HISTO_FLUX_FI
    GEP_&nb..HISTO_FLUX_BE
    GEP_&nb..HISTO_FLUX_MX
    GEP_&nb..HISTO_FLUX_CO
    GEP_&nb..HISTO_FLUX_AT
    GEP_&nb..HISTO_FLUX_IT 
    GEP_&nb..HISTO_FLUX_DE 
    GEP_&nb..HISTO_FLUX_PL
    GEP_&nb..HISTO_FLUX_SE
    GEP_&nb..HISTO_FLUX_FR ;
RUN;

proc sql ; 
create table  GEP_FLUX_&quarter._all as 
select distinct
t1.*,
/*t8.RPP AS RPP,*/
t8.Flag_Macao AS Flag_Macao
from GEP_FLUX_&quarter._all  t1 
left join FLAG_LEGACY_&nb. t8 on (t1.country=t8.country AND t1.scheme=t8.scheme and t1.cover=t8.Cover) ;
quit ; 

DATA GEP_FLUX_&quarter._all;
set GEP_FLUX_&quarter._all  ;
if Flag_Macao="MACAO" then LEGACY_SCHEME_BOOK="MACAO";
if Flag_Macao in ("TIA","") then LEGACY_SCHEME_BOOK="TIA";
run ;

DATA GEP_FLUX_&quarter._all;
set GEP_FLUX_&quarter._all;
drop Flag_Macao;
run ;

DATA GEP_FLUX_&quarter._all;
SET GEP_FLUX_&quarter._all ;
where  Month >="&YM_INF." and Month <="&YM_SUP." and LEGACY_SCHEME_BOOK="TIA" ;
RUN;

/*Proc SQL; Create Table GEP_FLUX_&quarter._all As
Select distinct a.*,c.cover_name 
From GEP_FLUX_&quarter._all a 
Left Join TIA_&nb..CARTO_TIA b On (a.country=b.Country and a.scheme=b.scheme)
Left Join Ref_Cover_&nb. c 
On (a.Cover=c.covmd_cover_code);
Quit;*/

Proc SQL; Create Table GEP_FLUX_&quarter._all As
Select distinct a.*,b.partner_sales_name as Agent_Name,c.cover_name 
From GEP_FLUX_&quarter._all a 
Left Join TIA_&nb..CARTO_TIA b On (a.country=b.Country and a.scheme=b.scheme)
Left Join Ref_Cover_&nb. c On (a.cover=c.covmd_cover_code);
Quit;


Data GEP_FLUX_&quarter._all;
SET GEP_FLUX_&quarter._all;
if Cover in ("DU","ZH","DZ","DY") THEN cover_name="Disability" ;
if Cover in ("TR","TS") THEN cover_name="Pecuniary Loss" ;
if Cover in ("RV") THEN cover_name="Unemployment" ;
if Cover in ("FF") THEN cover_name="Death" ;
run;

DATA GEP_FLUX_&quarter._all;
SET GEP_FLUX_&quarter._all;
RENAME 
Claim_paid=Claim_paid_&vision.
GEP=GEP_&vision.
REP=REP_&vision.;
RUN;

%MEND;

%recuperation_GEP(quarter=&quarter1.,nb=&nb1., YM_SUP=&YM_SUP1., YM_INF=&YM_INF1.,vision=&vision1.);
%recuperation_GEP(quarter=&quarter2.,nb=&nb2., YM_SUP=&YM_SUP2., YM_INF=&YM_INF2.,vision=&vision2.);
%recuperation_GEP(quarter=&quarter3.,nb=&nb3., YM_SUP=&YM_SUP3., YM_INF=&YM_INF3.,vision=&vision3.);
%recuperation_GEP(quarter=&quarter4.,nb=&nb4., YM_SUP=&YM_SUP4., YM_INF=&YM_INF4.,vision=&vision4.);

proc sql;
    create table GEP_FLUX_ALL_QUARTERS as
    select 
        coalesce(a.Country, b.Country, c.Country, d.Country) as Country ,
        coalesce(a.Rsrv_Grp, b.Rsrv_Grp, c.Rsrv_Grp, d.Rsrv_Grp) as Rsrv_Grp,
        coalesce(a.SCHEME, b.SCHEME, c.SCHEME, d.SCHEME) as SCHEME,
        coalesce(a.cover, b.cover, c.cover, d.cover) as cover,
        coalesce(a.cover_name, b.cover_name, c.cover_name, d.cover_name) as cover_name,
        coalesce(a.Entity_CD, b.Entity_CD, c.Entity_CD, d.Entity_CD) as Entity_CD,
        coalesce(a.Cohort, b.Cohort, c.Cohort, d.Cohort) as Cohort,
        coalesce(a.Quarter, b.Quarter, c.Quarter, d.Quarter) as Quarter,
        coalesce(a.Month, b.Month, c.Month, d.Month) as Month,
        coalesce(a.Product, b.Product, c.Product, d.Product) as Product,
        coalesce(a.RPP, b.RPP, c.RPP, d.RPP) as RPP,
        coalesce(a.Agent, b.Agent, c.Agent, d.Agent) as Agent,
        coalesce(a.Agent_Name, b.Agent_Name, c.Agent_Name, d.Agent_Name) as Agent_Name,
        a.Claim_paid_&vision1., b.Claim_paid_&vision2., c.Claim_paid_&vision3., d.Claim_paid_&vision4.,
        a.GEP_&vision1., b.GEP_&vision2., c.GEP_&vision3., d.GEP_&vision4.,
        a.REP_&vision1., b.REP_&vision2., c.REP_&vision3., d.REP_&vision4.
    from 
        GEP_FLUX_&quarter1._all as a
    full join 
       GEP_FLUX_&quarter2._all as b on a.Country = b.Country and a.cover = b.cover and a.cohort=b.cohort and a.Rsrv_Grp=b.Rsrv_Grp and a.cover_name = b.cover_name and a.SCHEME = b.SCHEME 
        and a.Quarter=b.Quarter and a.Month=b.Month and a.Agent=b.Agent and a.Agent_Name = b.Agent_Name and a.Entity_CD=b.Entity_CD and a.RPP=b.RPP and a.Product=b.Product
    full join 
        GEP_FLUX_&quarter3._all as c on a.Country = c.Country and a.cover = c.cover and a.cohort=c.cohort and a.Rsrv_Grp=c.Rsrv_Grp and a.cover_name = c.cover_name and a.SCHEME = c.SCHEME 
        and a.Quarter=c.Quarter and a.Month=c.Month and a.Agent=c.Agent and a.Agent_Name = c.Agent_Name and a.Entity_CD=c.Entity_CD and a.RPP=c.RPP and a.Product=c.Product
    full join 
        GEP_FLUX_&quarter4._all as d on a.Country = d.Country and a.cover = d.cover and a.cohort=d.cohort and a.Rsrv_Grp=d.Rsrv_Grp and a.cover_name = d.cover_name and a.SCHEME = d.SCHEME 
        and a.Quarter=d.Quarter and a.Month=d.Month and a.Agent=d.Agent and a.Agent_Name = d.Agent_Name and a.Entity_CD=d.Entity_CD and a.RPP=d.RPP and a.Product=d.Product;
quit;

Data GEP_FLUX_ALL_QUARTERS;
set GEP_FLUX_ALL_QUARTERS ;
if Claim_paid_&vision1. = . then Claim_paid_&vision1. = 0;
if Claim_paid_&vision2. = . then Claim_paid_&vision2. = 0;
if Claim_paid_&vision3. = . then Claim_paid_&vision3. = 0;
if Claim_paid_&vision4. = . then Claim_paid_&vision4. = 0;
if GEP_&vision1. = . then GEP_&vision1. = 0;
if GEP_&vision2. = . then GEP_&vision2. = 0;
if GEP_&vision3. = . then GEP_&vision3. = 0;
if GEP_&vision4. = . then GEP_&vision4. = 0;
if REP_&vision1. = . then REP_&vision1. = 0;
if REP_&vision2. = . then REP_&vision2. = 0;
if REP_&vision3. = . then REP_&vision3. = 0;
if REP_&vision4. = . then REP_&vision4. = 0;
run;

proc sql;
create table GEP_FLUX_ALL_QUARTERS as
select a.*, b.YTD_VALUE
from GEP_FLUX_ALL_QUARTERS a
left join tauxdechange b
on a.COUNTRY = b.COUNTRY;
quit;

Data GEP_FLUX_ALL_QUARTERS;
SET GEP_FLUX_ALL_QUARTERS;
Claim_paid_&vision1.=Claim_paid_&vision1.*YTD_VALUE;
Claim_paid_&vision2.=Claim_paid_&vision2.*YTD_VALUE;
Claim_paid_&vision3.=Claim_paid_&vision3.*YTD_VALUE;
Claim_paid_&vision4.=Claim_paid_&vision4.*YTD_VALUE;
GEP_&vision1.=GEP_&vision1.*YTD_VALUE;
GEP_&vision2.=GEP_&vision2.*YTD_VALUE;
GEP_&vision3.=GEP_&vision3.*YTD_VALUE;
GEP_&vision4.=GEP_&vision4.*YTD_VALUE;
REP_&vision1.=REP_&vision1.*YTD_VALUE;
REP_&vision2.=REP_&vision2.*YTD_VALUE;
REP_&vision3.=REP_&vision3.*YTD_VALUE;
REP_&vision4.=REP_&vision4.*YTD_VALUE;
run;

%macro EXPORT_EXCEL(DATA=, OUTFILE=, SHEET=);
	PROC EXPORT DATA = &DATA.
		OUTFILE = &OUTFILE.
		DBMS = XLSX REPLACE ;
		SHEET = &SHEET. ;
	RUN;
%mend;
%let EXPORT="~/NAS/X/08.Progammes/INTERNATIONAL/99_Travaux et Personnel/Gnanisso/Reserving TIA/Reportings TIA/Output/GEP_FLUX_Reports_Q226.xlsx";
%EXPORT_EXCEL(DATA=GEP_FLUX_&quarter1._all,OUTFILE=&EXPORT.,SHEET=GEP_FLUX__&quarter1._all);
%EXPORT_EXCEL(DATA=GEP_FLUX_&quarter2._all,OUTFILE=&EXPORT.,SHEET=GEP_FLUX__&quarter2._all);
%EXPORT_EXCEL(DATA=GEP_FLUX_&quarter3._all,OUTFILE=&EXPORT.,SHEET=GEP_FLUX__&quarter3._all);
%EXPORT_EXCEL(DATA=GEP_FLUX_&quarter4._all,OUTFILE=&EXPORT.,SHEET=GEP_FLUX__&quarter4._all);
%EXPORT_EXCEL(DATA=GEP_FLUX_ALL_QUARTERS,OUTFILE=&EXPORT.,SHEET=GEP_FLUX_ALL_QUARTERS);

/*####################################################################################################################
     ########################################EXPORT RESULTS################################################
########################################################################################################################*/
%macro EXPORT_EXCEL(DATA=, OUTFILE=, SHEET=);
	PROC EXPORT DATA = &DATA.
		OUTFILE = &OUTFILE.
		DBMS = XLSX REPLACE ;
		SHEET = &SHEET. ;
	RUN;
%mend;
%let EXPORT="~/NAS/X/08.Progammes/INTERNATIONAL/99_Travaux et Personnel/Gnanisso/Reserving TIA/Reportings TIA/Output/Reservings_reports_Q226.xlsx";

%EXPORT_EXCEL(DATA=CLMHDR_&quarter1._all,OUTFILE=&EXPORT.,SHEET=CLMHDR_&quarter1._all);
%EXPORT_EXCEL(DATA=CLMHDR_&quarter2._all,OUTFILE=&EXPORT.,SHEET=CLMHDR_&quarter2._all);
%EXPORT_EXCEL(DATA=CLMHDR_&quarter3._all,OUTFILE=&EXPORT.,SHEET=CLMHDR_&quarter3._all);
%EXPORT_EXCEL(DATA=CLMHDR_&quarter4._all,OUTFILE=&EXPORT.,SHEET=CLMHDR_&quarter4._all);
%EXPORT_EXCEL(DATA=FLUX_ALL_QUARTERS,OUTFILE=&EXPORT.,SHEET=FLUX_ALL_QUARTERS);
%EXPORT_EXCEL(DATA=CLAIMS_PAID_ALL_QUARTERS,OUTFILE=&EXPORT.,SHEET=CLAIMS_PAID_ALL_QUARTERS);


/***Test***/
*LIBNAME AUD "~/NAS/X/08.Progammes/INTERNATIONAL/06_Inventaire CLP/2021_Q4_Prov/02_Elements_Techniques/TIA/Arrete reel/RESERVES/ON-SYSTEM/CASES RESERVES/Output";